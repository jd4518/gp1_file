USE [OTMM]
GO

/****** Object:  Table [otmm].[ASSEMBLY_LOG]    Script Date: 2018-06-01 ���� 2:56:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [otmm].[USER_MANAGERMENT](	
	[USER_ID] 	[nvarchar](80) NOT NULL,
	[LOGIN_ID] 	[nvarchar](80)   NULL,
	[NAME] 	    [nvarchar](80)   NULL,
	[EMAIL_ADDR][nvarchar](80)   NULL,
	[COMPANY] 	[nvarchar](80)	 NULL,
	[DEPARTMENT][nvarchar](80)	 NULL,	
	[WORK_PHONE][nvarchar](80)	 NULL,	
    [CREATE_DT] [datetime] 		 NULL,
	[EXPIRE_DT] [datetime]		 NULL,
	[TYPE]      [nvarchar](10)	 NULL,
	[REG_ID] 	[nvarchar](80)   NULL,
	[REG_DT] 	[datetime]       NULL,
	
)

GO