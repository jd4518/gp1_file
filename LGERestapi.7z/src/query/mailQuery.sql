<!--그룹ID SEQ생성-->
USE OTMM
GO
CREATE SEQUENCE OTMM.GROUP_SEQ
START WITH 1
INCREMENT BY 1
GO

/****** 메일그룹생성 ******/
USE [OTMM]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [otmm].[EMAIL_GROUP](
	[GROUP_ID] 	[nvarchar](80) NOT NULL,
	[GROUP_NM] 	[nvarchar](80) NOT NULL,
	[REG_ID] 	[nvarchar](80)	 NULL,
	[REG_DT] 	[datetime]       NULL,
)

GO


/****** 메일사용자생성  ******/
USE [OTMM]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [otmm].[EMAIL_USER](
	[GROUP_ID] 	[nvarchar](80) NOT NULL,
	[LOGIN_ID] 	[nvarchar](80)   NULL,
	[USER_ID] 	[nvarchar](80)   NULL,
	[USER_NM] 	[nvarchar](80)   NULL,
	[USER_ADDR] [nvarchar](255)	 NULL,
	[REG_DT] 	[datetime]       NULL,
)

GO

