package fileUpload;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class fileUtils {
	
	private static fileUtils instance = new fileUtils();
	
	public static fileUtils getInstance() {
        return instance;
    }

	public boolean createFolderIfNotExists(String dirName)
			throws SecurityException {
		boolean flag = true;
		File theDir = new File(dirName);
		if (!theDir.exists()) {
			if(!theDir.mkdir()) {
				flag = false;
			}
		}
		return flag;
	}
	
	public void deleteFile(String filePath) {
		
		File file = new File(filePath);
		
		if(file.exists()) {
			file.delete();
		}
	}
	
	public void saveToFile(InputStream inStream, String target)
			throws IOException {
		OutputStream out = null;
		int read = 0;
		byte[] bytes = new byte[1024];
		out = new FileOutputStream(target);
		while ((read = inStream.read(bytes)) != -1) {
			out.write(bytes, 0, read);
		}
		out.flush();
		out.close();
	}
	
	public String getRandomString(){
        return UUID.randomUUID().toString().replaceAll("-", "");
    }
}
