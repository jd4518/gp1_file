package com.opentext.mediamanager.restapi.mailManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.dto.CPUnitLookupDto;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.representation.CPUnitLookupCollection;

import ttsg_teams.admin.db.DBMgr;
import utils.Utils;


/*
* ---------------------------------------------------------------------------------------
* PROJ    :   New Marketing Product Information_LGE
* NAME    :   CPUnitLookupServices.java
* DESC    :   Asset Metadata Cpunit APi
* Author  :   양창덕
* VER     :   v1.0
* Copyright 2019 LG CNS All right reserved
* ---------------------------------------------------------------------------------------
*                       변             경           사          항
* ---------------------------------------------------------------------------------------
*       DATE       AUTHOR                                  DESCRIPTION
*  ------------ -----------  ------------------------------------------------------------
*   2019 10.01    양창덕           API DB조회 정보 변경
* ---------------------------------------------------------------------------------------
*/
@Path(BaseResource.SUPPORTED_VERSIONS + "/CPUnitLookupServices")
public class CPUnitLookupServices extends BaseResource {

	public static final Log logger = LogFactory.getLog(CPUnitLookupServices.class);

	@GET
	@Path("/{LookupValue}/{Spec}")
	@Produces({ "application/json" })
	public Response selectDivisionLookup(@PathParam("LookupValue") String LookupValue, @PathParam("Spec") String Spec) {
		if (Utils.blackListCheck(LookupValue)) {
			return Response.status(400).entity("security policy").build();
		}

		if (Utils.blackListCheck(Spec)) {
			return Response.status(400).entity("security policy").build();
		}
		ArrayList<CPUnitLookupDto> resultList = new ArrayList<>();
		String query = "SELECT DISTINCT CP_UNIT_SPEC" + Spec + " AS CPUNIT FROM OTMM.LGE_MPIS_CPUNIT_CT "
				+ "WHERE DIVISION_CODE = '" + LookupValue + "' AND CP_UNIT_SPEC" + Spec
				+ " is not null AND CP_UNIT_SPEC" + Spec + " != ''";
		try {
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			ResultSet list = null;
			try {
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);
				list = preparedStatement.executeQuery();
				while (list.next()) {
					CPUnitLookupDto cpunitLookupDto = new CPUnitLookupDto();
					cpunitLookupDto.setValue(list.getString(1));
					cpunitLookupDto.setText(list.getString(1));

					resultList.add(cpunitLookupDto);
				}

			} finally {
				if (connection != null)
					connection.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (list != null)
					list.close();
			}
		} catch (WebApplicationException e) {
			throw e;
		} catch (Throwable t) {
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}

		CPUnitLookupCollection cpunitLookupCollection = new CPUnitLookupCollection();
		cpunitLookupCollection.setCpunitLookupName(resultList);

		return Response.ok(cpunitLookupCollection).type(checkMediaType()).build();
	}

	@POST
	@Path("/{LookupValue}/cascade")
	@Consumes({ "application/x-www-form-urlencoded" })
	public Response CPUnitLookup(@PathParam("LookupValue") String LookupValue, @FormParam("whichcp") int whichcp,
			@FormParam("cpunit1") String cpunit1, @FormParam("cpunit2") String cpunit2,
			@FormParam("cpunit3") String cpunit3, @FormParam("cpunit4") String cpunit4,
			@FormParam("cpunit5") String cpunit5, @FormParam("cpunit6") String cpunit6,
			@FormParam("cpunit7") String cpunit7) {
		if (Utils.blackListCheck(LookupValue)) {
			return Response.status(400).entity("security policy").build();
		}

		ArrayList<CPUnitLookupDto> resultList = new ArrayList<>();
		if (cpunit2 != null)
			if (cpunit2.equals("*"))
				cpunit2 = "";
		if (cpunit3 != null)
			if (cpunit3.equals("*"))
				cpunit3 = "";
		if (cpunit4 != null)
			if (cpunit4.equals("*"))
				cpunit4 = "";
		if (cpunit5 != null)
			if (cpunit5.equals("*"))
				cpunit5 = "";
		if (cpunit6 != null)
			if (cpunit6.equals("*"))
				cpunit6 = "";
		if (cpunit7 != null)
			if (cpunit7.equals("*"))
				cpunit7 = "";
		String query = "SELECT CP_UNIT_SPEC" + (whichcp+1) + " FROM ";
		query += "(SELECT DISTINCT ";
		 
		if (whichcp == 0) {
			query += "CP_UNIT_SPEC1";
		} 
		if (whichcp == 1) {
			query += "ISNULL(NULLIF(CP_UNIT_SPEC2, ''),'*') AS CP_UNIT_SPEC2 ";
		}
		if (whichcp == 2) {
			query += "ISNULL(NULLIF(CP_UNIT_SPEC3, ''),'*') AS CP_UNIT_SPEC3 ";
		}
		if (whichcp == 3) {
			query += "ISNULL(NULLIF(CP_UNIT_SPEC4, ''),'*') AS CP_UNIT_SPEC4 ";
		}
		if (whichcp == 4) {
			query += "ISNULL(NULLIF(CP_UNIT_SPEC5, ''),'*') AS CP_UNIT_SPEC5 ";
		}
		if (whichcp == 5) {
			query += "ISNULL(NULLIF(CP_UNIT_SPEC6, ''),'*') AS CP_UNIT_SPEC6 ";
		}
		if (whichcp == 6) {
			query += "ISNULL(NULLIF(CP_UNIT_SPEC7, ''),'*') AS CP_UNIT_SPEC7 ";
		}
		if (whichcp == 7) {
			query += "ISNULL(NULLIF(CP_UNIT_SPEC8, ''),'*') AS CP_UNIT_SPEC8 ";
		}
		
		query += ", CASE WHEN (CP_UNIT_SPEC" + (whichcp+1) + " = 'Others') THEN 1 ELSE 0 END AS A ";
		query += "FROM OTMM.LGE_MPIS_CPUNIT_CT ";
		query += "WHERE DIVISION_CODE = ? ";// LookupValue

//		query += "AND CP_UNIT_SPEC" + cpunit1 + " is not null"; 
		switch (whichcp) {
		case 7:
			query += "AND CP_UNIT_SPEC7 = ? ";// cpunit7
		case 6:
			query += "AND CP_UNIT_SPEC6 = ? ";
		case 5:
			query += "AND CP_UNIT_SPEC5 = ? ";
		case 4:
			query += "AND CP_UNIT_SPEC4 = ? ";
		case 3:
			query += "AND CP_UNIT_SPEC3 = ? ";
		case 2:
			query += "AND CP_UNIT_SPEC2 = ? ";
		case 1:
			query += "AND CP_UNIT_SPEC1 = ? ";

			break;

		default:
			
			break;
		}
		query += ") as A 	ORDER BY CASE WHEN (CP_UNIT_SPEC" + (whichcp+1) + " = 'Others') THEN 1 ELSE 0 END, CP_UNIT_SPEC"+(whichcp+1);
		try {
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			ResultSet list = null;
			System.out.println(query);
//			System.out.println("CPUNIT 1" + cpunit1);
//			System.out.println("CPUNIT 2" + cpunit2);
//			System.out.println("CPUNIT 3" + cpunit3);
//			System.out.println("CPUNIT 4" + cpunit4);
//			System.out.println("CPUNIT 5" + cpunit5);
//			System.out.println("CPUNIT 6" + cpunit6);
//			System.out.println("CPUNIT 7" + cpunit7);

			try {
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);

				preparedStatement.setString(1, LookupValue);
				// dfasdklfj
				int intindex = 1;
				switch (whichcp) {
				case 7:
					preparedStatement.setString(++intindex, cpunit7);
				case 6:
					preparedStatement.setString(++intindex, cpunit6);
				case 5:
					preparedStatement.setString(++intindex, cpunit5);
				case 4:
					preparedStatement.setString(++intindex, cpunit4);
				case 3:
					preparedStatement.setString(++intindex, cpunit3);
				case 2:
					preparedStatement.setString(++intindex, cpunit2);
				case 1:
					preparedStatement.setString(++intindex, cpunit1);

					break;

				default:
					break;
				}

				// asd

				list = preparedStatement.executeQuery();
				while (list.next()) {
					CPUnitLookupDto cpunitLookupDto = new CPUnitLookupDto();
					cpunitLookupDto.setValue(list.getString(1));
					cpunitLookupDto.setText(list.getString(1));

					resultList.add(cpunitLookupDto);
				}

			} finally {
				if (connection != null)
					connection.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (list != null)
					list.close();
			}
		} catch (WebApplicationException e) {
			throw e;
		} catch (Throwable t) {
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}

		CPUnitLookupCollection cpunitLookupCollection = new CPUnitLookupCollection();
		cpunitLookupCollection.setCpunitLookupName(resultList);
		cpunitLookupCollection.setCpnumber(whichcp);

		return Response.ok(cpunitLookupCollection).type(checkMediaType()).build();
	}
}
