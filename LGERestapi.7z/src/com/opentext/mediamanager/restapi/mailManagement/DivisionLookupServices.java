package com.opentext.mediamanager.restapi.mailManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.dto.DivisionLookupDto;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.representation.DivisionLookupCollection;

import ttsg_teams.admin.db.DBMgr;
import utils.Utils;

@Path(BaseResource.SUPPORTED_VERSIONS + "/DivisionLookupServices")
public class DivisionLookupServices extends BaseResource {

	public static final Log logger = LogFactory.getLog(DivisionLookupServices.class);
	
	@GET
	@Path("/{bu}")
	@Produces({"application/json"})
	public Response selectDivisionLookup(@PathParam ("bu") String bu){
		if(Utils.blackListCheck(bu)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		ArrayList<DivisionLookupDto> resultList = new ArrayList<>();
//		String query = "SELECT ID, VALUE FROM OTMM.LGE_MPIS_DIVISION_LDT WHERE DESCRIPTION = '" + bu + "'";		
		String query = "SELECT DIVISION.ID, DIVISION.VALUE " + 
				"  FROM [OTMM].[OTMM_SYS_CONFIG_COMPONENTS] AS COMPONENTS " + 
				"  INNER JOIN OTMM.OTMM_SYS_CONFIG_SETTINGS AS SETTINGS " + 
				"  ON COMPONENTS.ID = SETTINGS.COMPONENT_ID " + 
				"  INNER JOIN OTMM.LGE_MPIS_DIVISION_LDT AS DIVISION " + 
				"  ON DIVISION.ID = SETTINGS.NAME " + 
				"  WHERE COMPONENTS.COMPONENT_NAME LIKE 'LGE'  " + 
				"  AND COMPONENTS.KEY_NAME LIKE 'CPUNIT' " + 
				"  AND DIVISION.DESCRIPTION LIKE '" + bu + "'";
		try 
		{
			
			Connection connection = null;
			PreparedStatement preparedStatement = null;	
			ResultSet list = null;
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);
				list = preparedStatement.executeQuery();	
				while(list.next())
				{
					DivisionLookupDto divisionLookupDto = new DivisionLookupDto();
					divisionLookupDto.setValue(list.getString("id"));
					divisionLookupDto.setText(list.getString("value"));
					resultList.add(divisionLookupDto);
				}

			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
				if(list != null) list.close();
			}
//			ResultSet list = DbConfig.selectQuery(query, null);	
//			while(list.next()) {
//				DivisionLookupDto divisionLookupDto = new DivisionLookupDto();
//				divisionLookupDto.setValue(list.getString("id"));
//				divisionLookupDto.setText(list.getString("value"));
//				resultList.add(divisionLookupDto);
//			}
		} 
		catch (WebApplicationException e) 
		{
			throw e;
		} 
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}

				
		
		DivisionLookupCollection divisionLookupCollection = new DivisionLookupCollection();
		divisionLookupCollection.setDivisionLookupName(resultList);
		
		return Response.ok(divisionLookupCollection).type(checkMediaType()).build();
	}
}
