package com.opentext.mediamanager.restapi.mailManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.dto.GroupListDto;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.representation.GroupListCollection;
import com.wordnik.swagger.annotations.ApiParam;

import ttsg_teams.admin.db.DBMgr;
import ttsg_teams.common.common.TeamsException;
import utils.Utils;

@Path(BaseResource.SUPPORTED_VERSIONS+"/mailGroup")
public class GroupListServices extends BaseResource{

	public static final Log logger = LogFactory.getLog(GroupListServices.class);
	
	
	
	/**
	 * �윜諛몄굡塋딆닂彛뽭겫�슦逾ч댖怨뚰�э옙�뤂
	 * @param groupId
	 * @return
	 */
	@GET
	@Path("/list")
	@Produces({"application/json"})
	public Response selectMailUser(@ApiParam(value="the group id", required=false) @QueryParam ("groupId") String groupId) {
		if(Utils.blackListCheck(groupId)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		ArrayList<GroupListDto> resultList = new ArrayList<>();
		String query="";
		if(groupId == null) {
			query = "SELECT GROUP_ID, GROUP_NM, REG_ID, REG_DT FROM OTMM.LGE_MPIS_EMAIL_GROUP_CT";
		}else {
			query = "SELECT GROUP_ID, GROUP_NM, REG_ID, REG_DT FROM OTMM.LGE_MPIS_EMAIL_GROUP_CT WHERE GROUP_ID ="+groupId;
		}
					
		try 
		{
			Connection connection = null;
			PreparedStatement preparedStatement = null;	
			ResultSet list = null;
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);
				list = preparedStatement.executeQuery();	
				while(list.next())
				{
					GroupListDto groupList = new GroupListDto();
					groupList.setGroupId(list.getString("group_id"));
					groupList.setGroupNm(list.getString("group_nm"));
					resultList.add(groupList);	
				}

			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
				if(list != null) list.close();
			}
			
//			ResultSet list = DbConfig.selectQuery(query, null);		
//			while(list.next())
//			{
//				GroupListDto groupList = new GroupListDto();
//				groupList.setGroupId(list.getString("group_id"));
//				groupList.setGroupNm(list.getString("group_nm"));
//				resultList.add(groupList);	
//			}
		} 
		catch (WebApplicationException e) 
		{
			throw e;
		} 
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}

				
		GroupListCollection groupList = new GroupListCollection();
		groupList.setGroupUserList(resultList);
		
		return Response.ok(groupList).type(checkMediaType()).build();
	}
	
	/**
	 * �윜諛몄굡塋딉옙 �뜝�럡臾멨뜝�럡�뎽
	 * @param regid
	 * @return
	 */
	
	@GET
	@Path("/plist")
	@Produces({"application/json"})
	public Response selectpMailUser(@QueryParam ("regid") String regid) {
		if(Utils.blackListCheck(regid)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		ArrayList<GroupListDto> resultList = new ArrayList<>();
		
		
		String query = "SELECT GROUP_ID, GROUP_NM, REG_ID, REG_DT FROM OTMM.LGE_MPIS_EMAIL_GROUP_CT WHERE REG_ID = " + regid;
		
					
		try 
		{
			Connection connection = null;
			PreparedStatement preparedStatement = null;	
			ResultSet list = null;
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);
				list = preparedStatement.executeQuery();	
				while(list.next())
				{
					GroupListDto groupList = new GroupListDto();
					groupList.setGroupId(list.getString("group_id"));
					groupList.setGroupNm(list.getString("group_nm"));
					resultList.add(groupList);		
				}

			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
				if(list != null) list.close();
			}
			
//			ResultSet list = DbConfig.selectQuery(query, null);		
//			while(list.next())
//			{
//				GroupListDto groupList = new GroupListDto();
//				groupList.setGroupId(list.getString("group_id"));
//				groupList.setGroupNm(list.getString("group_nm"));
//				resultList.add(groupList);	
//			}
		} 
		catch (WebApplicationException e) 
		{
			throw e;
		} 
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}
	
		GroupListCollection groupList = new GroupListCollection();
		groupList.setGroupUserList(resultList);
		
		return Response.ok(groupList).type(checkMediaType()).build();
	}
	
	
	/**
	 * �윜諛몄굡塋딉옙 �뜝�럡臾멨뜝�럡�뎽
	 * @param groupNm
	 * @param request
	 * @return
	 * @throws SQLException 
	 */
	@POST
	@Path("/createGrp")
	@Consumes({"application/x-www-form-urlencoded"})
	public Response insertGroup(@FormParam("groupNm") String groupNm, @Context HttpServletRequest request) throws SQLException {
		String query = "INSERT INTO OTMM.LGE_MPIS_EMAIL_GROUP_CT(GROUP_ID, GROUP_NM, REG_ID, REG_DT)VALUES(NEXT VALUE FOR OTMM.LGE_MPIS_GROUP_SEQ, N'"+groupNm+"', '"+getOTMMSession(request).getUserId().toString()+"', GETDATE())";
//		LinkedHashMap<String, String> params = new LinkedHashMap<String, String>();		
//		params.put("groupNm", groupNm);
//		params.put("regId",   getOTMMSession(request).getUserId().toString());	
//		
		
		if(Utils.blackListCheck(groupNm)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		
		
		try {
//			DbConfig.updateQuery(query, params);
			Connection connection = null;
			PreparedStatement preparedStatement = null;				
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.executeUpdate();	
			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
			}
		} catch (TeamsException e) {
			e.printStackTrace();
		}

		return Response.status(Response.Status.OK).build();
	}
	
	/**
	 * �윜諛몄굡塋딆닂�삕亦낆꼻�삕占쎌젷
	 * @param groupId
	 * @param re
	 * @return
	 * @throws SQLException 
	 */
	@POST
	@Path("/delGrp")
	@Consumes({"application/x-www-form-urlencoded"})
	public Response deleteGroup(@FormParam ("groupId") String  groupId) throws SQLException {
		String [] groupIds = groupId.split(",");
		
		for(int i=0;i<groupIds.length;i++) 
		{		
			String query = "DELETE FROM  OTMM.LGE_MPIS_EMAIL_GROUP_CT WHERE GROUP_ID = "+groupIds[i];
			try 
			{
				Connection connection = null;
				PreparedStatement preparedStatement = null;	
				int result;
				try
				{
					DBMgr db = new DBMgr();
					connection = db.openDatabase();
					preparedStatement = connection.prepareStatement(query);
					result = preparedStatement.executeUpdate();	
				}
				finally
				{
					if(connection != null)  connection.close();
					if(preparedStatement != null) preparedStatement.close();
				}
				
//				int result = DbConfig.updateQuery(query, null);
				
				if(result==1) 
				{
					String query1 = "DELETE FROM OTMM.LGE_MPIS_EMAIL_USER_CT WHERE GROUP_ID ="+groupIds[i];
					try
					{
						DBMgr db = new DBMgr();
						connection = db.openDatabase();
						preparedStatement = connection.prepareStatement(query1);
						preparedStatement.executeUpdate();	
					}
					finally
					{
						if(connection != null)  connection.close();
						if(preparedStatement != null) preparedStatement.close();
					}
					
//					 DbConfig.updateQuery(query1, null);
				}			
			} 
			catch (TeamsException e) 
			{
				e.printStackTrace();
			}

		}		
		return Response.status(Response.Status.OK).build();
	}
	/**
	 * �윜諛몄굡塋딆닂�삕亦낆꼻�삕占쎌젷
	 * @param groupId
	 * @param groupName
	 * @return
	 * @throws SQLException 
	 */
	@POST
	@Path("/updateGrp")
	@Consumes({"application/x-www-form-urlencoded"})
	public Response updateGroup(@FormParam ("groupId") String  groupId, @FormParam ("groupName") String  groupName) throws SQLException {
		if(Utils.blackListCheck(groupName)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		String query = "UPDATE OTMM.LGE_MPIS_EMAIL_GROUP_CT SET GROUP_NM = N'"+ groupName +"' WHERE GROUP_ID = " + groupId;
		try 
		{
//			int result = DbConfig.updateQuery(query, null);
			Connection connection = null;
			PreparedStatement preparedStatement = null;				
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.executeUpdate();	
			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
			}
						
		} 
		catch (TeamsException e) 
		{
			e.printStackTrace();
		}

		
		return Response.status(Response.Status.OK).build();
	}
}
