package com.opentext.mediamanager.restapi.mailManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.dto.JobFolderMappingDto;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.representation.JobFolderMappingCollection;

import ttsg_teams.admin.db.DBMgr;
import utils.Utils;

@Path(BaseResource.SUPPORTED_VERSIONS + "/JobFolderMappingServices")
public class JobFolderMappingServices extends BaseResource {

	public static final Log logger = LogFactory.getLog(CPUnitLookupServices.class);

	@GET
	@Path("/{job_id}")
	@Produces({ "application/json" })
	public Response selectJobFolderMapping(@PathParam("job_id") String job_id) {
		if (Utils.blackListCheck(job_id)) {
			return Response.status(400).entity("security policy").build();
		}
		ArrayList<JobFolderMappingDto> resultList = new ArrayList<>();
		StringBuffer query = new StringBuffer();
		StringBuffer query2 = new StringBuffer();
		// Read Data for Job Folder
		query.append("SELECT CT.ID, CT.FOLDER_ID, UOIS.NAME ");
		query.append("FROM OTMM.OTMM.LGE_MPIS_RVJOBS_CT AS CT ");
		query.append("JOIN OTMM.OTMM.UOIS AS UOIS ");
		query.append("ON UOIS.UOI_ID = CT.FOLDER_ID ");
		query.append("WHERE CT.ID LIKE '" + job_id + "' ");
		
		// update Folder Mapping
		query2.append("UPDATE [OTMM].[OTMM_RVJOB_JOBS]");
		query2.append("   SET [FOLDER_ID] = (SELECT [FOLDER_ID] ");
		query2.append("					  FROM [OTMM].[LGE_MPIS_RVJOBS_CT]");
		query2.append("					  WHERE ID LIKE '" + job_id + "')");
		query2.append(" WHERE ID LIKE '" + job_id + "'");
		
		
		// Read Data for Job Folder
		try {
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			PreparedStatement preparedStatement2 = null;
			
			ResultSet list = null;
			try {
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement2 = connection.prepareStatement(query2.toString());
				preparedStatement2.executeUpdate();
				

				preparedStatement = connection.prepareStatement(query.toString());
				list = preparedStatement.executeQuery();
				
				
				while (list.next()) {
					JobFolderMappingDto jobFolderMappingDto = new JobFolderMappingDto();
					jobFolderMappingDto.setJob_id(list.getString(1));
					jobFolderMappingDto.setFolder_id(list.getString(2));
					jobFolderMappingDto.setFolder_name(list.getString(3));

					resultList.add(jobFolderMappingDto);
				}

			} finally {
				if (connection != null)
					connection.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (list != null)
					list.close();
				if (preparedStatement2 != null)
					preparedStatement2.close();
			}

		} catch (WebApplicationException e) {
			throw e;
		} catch (Throwable t) {
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}

		JobFolderMappingCollection jobFolderMappingCollection = new JobFolderMappingCollection();
		jobFolderMappingCollection.setJobFolderMappingData(resultList);

		return Response.ok(jobFolderMappingCollection).type(checkMediaType()).build();
	}
}
