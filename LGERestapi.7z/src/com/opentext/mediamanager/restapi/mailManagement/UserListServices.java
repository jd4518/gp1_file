package com.opentext.mediamanager.restapi.mailManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.artesia.common.exception.BaseTeamsException;
import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.dto.UserListDto;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.representation.UserListCollection;

import ttsg_teams.admin.db.DBMgr;
import utils.Utils;

@Path(BaseResource.SUPPORTED_VERSIONS+"/mailUser")
public class UserListServices extends BaseResource{
	
public static final Log logger = LogFactory.getLog(UserListServices.class);

	/**
	 * 硫붿씪洹몃９�궗�슜�옄 議고쉶
	 * @param groupId
	 * @return
	 */
	@GET
	@Path("/list/{groupId}")
	@Produces({"application/json"})
	public Response selectMailUser(@PathParam ("groupId") String groupId) {
		if(Utils.blackListCheck(groupId)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		ArrayList<UserListDto> resultList = new ArrayList<>();
		String query = "SELECT GROUP_ID, USER_ID, USER_NM, USER_ADDR FROM OTMM.LGE_MPIS_EMAIL_USER_CT WHERE GROUP_ID ="+groupId;			
		try 
		{
			Connection connection = null;
			PreparedStatement preparedStatement = null;	
			ResultSet list = null;
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);
				list = preparedStatement.executeQuery();	
				while(list.next())
				{
					UserListDto userList = new UserListDto();
					userList.setGroupId(groupId);
					userList.setUserId(list.getString("user_id"));
					userList.setUserNm(list.getString("user_nm"));
					userList.setUserAddr(list.getString("user_addr"));
					userList.setCompany("");
					userList.setDep("");
					userList.setWorkPhone("");				
					resultList.add(userList);	
				}

			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
				if(list != null) list.close();
			}
			
//			ResultSet list = DbConfig.selectQuery(query, null);		
//			while(list.next())
//			{
//				UserListDto userList = new UserListDto();
//				userList.setGroupId(groupId);
//				userList.setUserId(list.getString("user_id"));
//				userList.setUserNm(list.getString("user_nm"));
//				userList.setUserAddr(list.getString("user_addr"));
//				userList.setCompany("");
//				userList.setDep("");
//				userList.setWorkPhone("");				
//				resultList.add(userList);	
//			}
		} 
		catch (WebApplicationException e) 
		{
			throw e;
		} 
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}
	
		UserListCollection userList = new UserListCollection();
		userList.setUserList(resultList);
		
		return Response.ok(userList).type(checkMediaType()).build();
	}
	
	@POST  
	@Path("/list/{groupId}")  
	@Produces(MediaType.APPLICATION_JSON)
	public Response insertMailUser(@PathParam("groupId") String groupId, @FormParam("resultData") String result) throws BaseTeamsException{
               		JSONParser parser = new JSONParser();
		Object obj = null;
		try {
			obj = parser.parse(result);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONArray json = (JSONArray) obj;
		try {
			String deleteQuery = "DELETE FROM OTMM.LGE_MPIS_EMAIL_USER_CT WHERE GROUP_ID = " + groupId;
			Connection connection = null;
			PreparedStatement preparedStatement = null;				
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(deleteQuery);
				preparedStatement.executeUpdate();	
			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
			}
			
//			DbConfig.updateQuery(deleteQuery, null);
		}catch (Exception e) {
			
		}

		for (int i = 0; i < json.size(); i++){
			JSONObject returnSubject = (JSONObject) json.get(i);
//			LinkedHashMap<String, String> params = new LinkedHashMap<String, String>();
//			params.put("groupId", 	groupId);
//			params.put("loginId", 	returnSubject.get("loginId").toString());
//			params.put("userId", 	returnSubject.get("userId").toString());
//			params.put("name", 		returnSubject.get("name").toString());
//			params.put("email", 	returnSubject.get("email").toString());
			
//			String loginId 	=  returnSubject.get("loginId").toString();
//			String userId  	=  returnSubject.get("userId").toString();
//			String name 	=  returnSubject.get("name").toString();
//			String email 	=  returnSubject.get("email").toString();
//			String query = "INSERT INTO OTMM.LGE_MPIS_EMAIL_USER_DT (GROUP_ID, LOGIN_ID, USER_ID, USER_NM, USER_ADDR, REG_DT)"
//						 + "VALUES("+groupId+","+loginId+","+userId+","+name+","+email+", GETDATE())";	
//			
			String query = "INSERT INTO OTMM.LGE_MPIS_EMAIL_USER_CT (GROUP_ID, LOGIN_ID, USER_ID, USER_NM, USER_ADDR, REG_DT)"
					 + "VALUES('"+groupId+"' ,'"+returnSubject.get("loginId").toString()+"','"+returnSubject.get("userId").toString()+"', N'"+returnSubject.get("name").toString()+"','"+returnSubject.get("email").toString()+"', GETDATE())";
			
			
			
			try {
				
//				DbConfig.updateQuery(query, params);
				Connection connection = null;
				PreparedStatement preparedStatement = null;				
				try
				{
					DBMgr db = new DBMgr();
					connection = db.openDatabase();
					preparedStatement = connection.prepareStatement(query);
					preparedStatement.executeUpdate();	
				}
				finally
				{
					if(connection != null)  connection.close();
					if(preparedStatement != null) preparedStatement.close();
				}
			} catch (WebApplicationException e) 
			{
				throw e;
			} 
			catch (Throwable t) 
			{
				throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
			}

		   }
		

		
		
		return Response.status(Response.Status.OK).build();	
	}
	


}
