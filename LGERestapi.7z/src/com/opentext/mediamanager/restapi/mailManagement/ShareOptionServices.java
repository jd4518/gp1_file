package com.opentext.mediamanager.restapi.mailManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.artesia.common.exception.BaseTeamsException;
import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.dto.JobAddressListDto;
import com.opentext.mediamanager.restapi.dto.JobFolderNameDto;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.representation.JobAddressListCollection;
import com.opentext.mediamanager.restapi.representation.JobFolderNameCollection;

import ttsg_teams.admin.db.DBMgr;
import utils.Utils;

@Path(BaseResource.SUPPORTED_VERSIONS + "/ShareOptionServices")
public class ShareOptionServices extends BaseResource {

	public static final Log logger = LogFactory.getLog(UserListServices.class);

	@GET
	@Path("/AD/{jobId}")
	@Produces({ "application/json" })
	public Response selectJobAddress(@PathParam("jobId") String jobId) {
		if(Utils.blackListCheck(jobId)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		ArrayList<JobAddressListDto> resultList = new ArrayList<>();
		String query = "SELECT EMAIL, NAME, REG_ID, REG_DT FROM OTMM.LGE_MPIS_JOB_EMAIL_LIST_CT WHERE JOB_ID = '" + jobId + "'";
		try {
			Connection connection = null;
			PreparedStatement preparedStatement = null;	
			ResultSet list = null;
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);
				list = preparedStatement.executeQuery();	
				while(list.next())
				{
					JobAddressListDto jobAddressListDto = new JobAddressListDto();
					jobAddressListDto.setJobId(jobId);
					jobAddressListDto.setEmail(list.getString("email"));
					jobAddressListDto.setName(list.getString("name"));
					jobAddressListDto.setRegId(list.getString("reg_id"));
					resultList.add(jobAddressListDto);	
				}

			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
				if(list != null) list.close();
			}
		} catch (WebApplicationException e) {
			throw e;
		} catch (Throwable t) {
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}
		JobAddressListCollection jobAddressListCollection = new JobAddressListCollection();
		jobAddressListCollection.setJobAddressList(resultList);

		return Response.ok(jobAddressListCollection).type(checkMediaType()).build();
	}

	@POST
	@Path("/AD/{jobId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response insertJobAddress(@PathParam("jobId") String jobId, @FormParam("resultData") String result)
			throws BaseTeamsException {
		JSONParser parser = new JSONParser();
		Object obj = null; 
		try {
			obj = parser.parse(result);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONArray json = (JSONArray) obj;
		try {
			String deleteQuery = "DELETE FROM OTMM.LGE_MPIS_JOB_EMAIL_LIST_CT WHERE JOB_ID = '" + jobId +"'";
			Connection connection = null;
			PreparedStatement preparedStatement = null;				
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(deleteQuery);
				preparedStatement.executeUpdate();	
			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
			}
		}catch (Exception e) {
			
		}


		for (int i = 0; i < json.size(); i++) {
			JSONObject returnSubject = (JSONObject) json.get(i);
			LinkedHashMap<String, String> params = new LinkedHashMap<String, String>();
			params.put("jobId", jobId);
			params.put("email", returnSubject.get("email").toString());
			System.out.println(params);
			String query = "INSERT INTO OTMM.LGE_MPIS_JOB_EMAIL_LIST_CT (JOB_ID, EMAIL, REG_DT) "
					+ "VALUES('"+jobId+"','"+returnSubject.get("email").toString()+"', GETDATE())";
			System.out.println(query);
			try {
//				DbConfig.updateQuery(query, params);
				Connection connection = null;
				PreparedStatement preparedStatement = null;				
				try
				{
					DBMgr db = new DBMgr();
					connection = db.openDatabase();
					preparedStatement = connection.prepareStatement(query);
					preparedStatement.executeUpdate();	
				}
				finally
				{
					if(connection != null)  connection.close();
					if(preparedStatement != null) preparedStatement.close();
				}
			} catch (WebApplicationException e) {
				throw e;
			} catch (Throwable t) {
				throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
			}

		}

		return Response.status(Response.Status.OK).build();
	}

	@GET
	@Path("/FD/{jobId}")
	@Produces({ "application/json" })
	public Response selectJobFolderName(@PathParam("jobId") String jobId) {
		ArrayList<JobFolderNameDto> resultList = new ArrayList<>();
		String query = "SELECT FOLDERNAME FROM OTMM.LGE_MPIS_JOB_FOLDER_NAME_CT WHERE JOB_ID = '" + jobId + "'";
		try {

			Connection connection = null;
			PreparedStatement preparedStatement = null;	
			ResultSet list = null;
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);
				list = preparedStatement.executeQuery();	
				while(list.next())
				{
					JobFolderNameDto jobFolderNameDto = new JobFolderNameDto();
					jobFolderNameDto.setFolderName(list.getString("foldername"));
					resultList.add(jobFolderNameDto);
				}

			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
				if(list != null) list.close();
			}
		} catch (WebApplicationException e) {
			throw e;
		} catch (Throwable t) {
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}


		JobFolderNameCollection jobFolderNameCollection = new JobFolderNameCollection();
		jobFolderNameCollection.setJobFolderName(resultList);

		return Response.ok(jobFolderNameCollection).type(checkMediaType()).build();
	}

	@POST
	@Path("/FD/{jobId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response insertJobFolderName(@PathParam("jobId") String jobId, @FormParam("fileName") String fileName)
			throws BaseTeamsException {
		
		if(Utils.blackListCheck(fileName)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		
		if(Utils.blackListCheck(jobId)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		if(fileName == null) fileName = "";

		String query2 = "MERGE OTMM.LGE_MPIS_JOB_FOLDER_NAME_CT USING (SELECT 'X' AS DUAL) AS B " + "ON JOB_ID = '" + jobId
				+ "' WHEN MATCHED THEN " + "UPDATE SET FOLDERNAME = N'" + fileName + "' "
				+ ", REG_DT = GETDATE() WHEN NOT MATCHED THEN INSERT (JOB_ID, FOLDERNAME, REG_DT) VALUES ('" + jobId + "', N'"
				+ fileName + "', GETDATE());";
		try {
			Connection connection = null;
			PreparedStatement preparedStatement = null;				
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query2);
				preparedStatement.executeUpdate();	
			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
			}
		} catch (WebApplicationException e) {
			throw e;
		} catch (Throwable t) {
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}


		return Response.status(Response.Status.OK).build();
	}

}
