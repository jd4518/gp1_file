package com.opentext.mediamanager.restapi.mailManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.dto.AddAttributeLookupDto;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.representation.AddAttributeLookupCollection;

import ttsg_teams.admin.db.DBMgr;
import utils.Utils;

@Path(BaseResource.SUPPORTED_VERSIONS + "/AddAttributeLookupServices")
public class AddAttributeLookupServices extends BaseResource {

	public static final Log logger = LogFactory.getLog(AddAttributeLookupServices.class);
	
	@GET
	@Path("/{Spec}")
	@Produces({"application/json"})
	public Response selectDivisionLookupOP1(@PathParam ("Spec") String Spec){
		if(Utils.blackListCheck(Spec)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		ArrayList<AddAttributeLookupDto> resultList = new ArrayList<>();
		String query = "SELECT ID, VALUE FROM OTMM.LGE_MPIS_ADDATTR" + Spec + "_LDT ";
		try 
		{
			Connection connection = null;
			PreparedStatement preparedStatement = null;	
			ResultSet list = null;
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);
				list = preparedStatement.executeQuery();	
				while(list.next())
				{
					AddAttributeLookupDto addAttributeLookupDto = new AddAttributeLookupDto();
					addAttributeLookupDto.setValue(list.getString(1));
					addAttributeLookupDto.setText(list.getString(2));
					
					resultList.add(addAttributeLookupDto);
				}

			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
				if(list != null) list.close();
			}
			
//			ResultSet list = DbConfig.selectQuery(query, null);		
//			while(list.next()) {
//				AddAttributeLookupDto addAttributeLookupDto = new AddAttributeLookupDto();
//				addAttributeLookupDto.setValue(list.getString(1));
//				addAttributeLookupDto.setText(list.getString(2));
//				
//				resultList.add(addAttributeLookupDto);
//			}
		} 
		catch (WebApplicationException e) 
		{
			throw e;
		} 
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}

				
		
		AddAttributeLookupCollection addAttributeLookupCollection = new AddAttributeLookupCollection();
		addAttributeLookupCollection.setAddAttributeLookupName(resultList);
		
		return Response.ok(addAttributeLookupCollection).type(checkMediaType()).build();
	}
	
	@GET
	@Path("/{Spec}/{LookupValue}")
	@Produces({"application/json"})
	public Response selectDivisionLookupOP2(@PathParam ("Spec") String Spec, @PathParam ("LookupValue") String LookupValue){
		if(Utils.blackListCheck(Spec)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		if(Utils.blackListCheck(LookupValue)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		ArrayList<AddAttributeLookupDto> resultList = new ArrayList<>();
		String query = "SELECT ID, VALUE FROM OTMM.LGE_MPIS_ADDATTR" + Spec + "_LDT "+
		"WHERE DESCRIPTION = '" + LookupValue + "' ";
		try 
		{
			Connection connection = null;
			PreparedStatement preparedStatement = null;	
			ResultSet list = null;
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);
				list = preparedStatement.executeQuery();	
				while(list.next())
				{
					AddAttributeLookupDto addAttributeLookupDto = new AddAttributeLookupDto();
					addAttributeLookupDto.setValue(list.getString(1));
					addAttributeLookupDto.setText(list.getString(2));
					
					resultList.add(addAttributeLookupDto);	
				}

			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
				if(list != null) list.close();
			}
			
//			ResultSet list = DbConfig.selectQuery(query, null);		
//			while(list.next()) {
//				AddAttributeLookupDto addAttributeLookupDto = new AddAttributeLookupDto();
//				addAttributeLookupDto.setValue(list.getString(1));
//				addAttributeLookupDto.setText(list.getString(2));
//				
//				resultList.add(addAttributeLookupDto);
//			}
		} 
		catch (WebApplicationException e) 
		{
			throw e;
		} 
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}
				
		
		AddAttributeLookupCollection addAttributeLookupCollection = new AddAttributeLookupCollection();
		addAttributeLookupCollection.setAddAttributeLookupName(resultList);
		
		return Response.ok(addAttributeLookupCollection).type(checkMediaType()).build();
	}

}
