package com.opentext.mediamanager.restapi.mailManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.dto.ModelNameLookupDto;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.representation.ModelNameLookupCollection;

import ttsg_teams.admin.db.DBMgr;
import utils.Utils;

@Path(BaseResource.SUPPORTED_VERSIONS + "/ModelNameLookupServices")
public class ModelNameLookupServices extends BaseResource {

	public static final Log logger = LogFactory.getLog(ModelNameLookupServices.class);
	//@QueryParam("where") String word, @QueryParam("type") String type, @QueryParam("before") String before, @QueryParam("after") String after, @QueryParam("sort") String sort
	@GET
	@Path("/{LookupValue}")
	@Produces({"application/json"})
	public Response selectModelNameLookup(@PathParam ("LookupValue") String LookupValue, @QueryParam("where") String word, @QueryParam("before") String before, @QueryParam("after") String after){
		
		if(Utils.blackListCheck(word)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		
		if(Utils.blackListCheck(before)) 
		{
			return Response.status(400).entity("security policy").build();
		}
		
		if(Utils.blackListCheck(after)) 
		{
			return Response.status(400).entity("security policy").build();
		}
	
		
		ArrayList<ModelNameLookupDto> resultList = new ArrayList<>();
		int total = 0;
		String query ="SELECT MODEL_NAME FROM(" + 
				"SELECT DISTINCT ROW_NUMBER() OVER(ORDER BY MODEL_NAME) AS ROWNUM, MODEL_NAME FROM OTMM.LGE_MPIS_CPUNIT_MODEL_NAME_CT " +
				"WHERE DIVISION_CODE = '" + LookupValue + "' AND MODEL_NAME is not null AND MODEL_NAME != ''";
		if(word != null && word != "") {
			query += " AND MODEL_NAME LIKE N'%" + word + "%'";
		}
		query += ")A WHERE ROWNUM >= " + before + " AND ROWNUM < " + after + " ORDER BY ROWNUM";
		
		String totalquery ="SELECT DISTINCT COUNT(1) FROM OTMM.LGE_MPIS_CPUNIT_MODEL_NAME_CT " +
				"WHERE DIVISION_CODE = '" + LookupValue + "' AND MODEL_NAME is not null AND MODEL_NAME != ''";
		if(word != null && word != "") {
			totalquery += " AND MODEL_NAME LIKE N'%" + word + "%'";
		}
		
		
		try 
		{
			Connection connection = null;
			PreparedStatement preparedStatement = null;	
			ResultSet list = null;
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);
				list = preparedStatement.executeQuery();	
				while(list.next())
				{
					ModelNameLookupDto modelNameLookupDto = new ModelNameLookupDto();
					modelNameLookupDto.setModel_name(list.getString(1));
					
					resultList.add(modelNameLookupDto);	
				}

			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
				if(list != null) list.close();
			}
			
//			ResultSet list = DbConfig.selectQuery(query, null);		
//			while(list.next()) {
//				
//				ModelNameLookupDto modelNameLookupDto = new ModelNameLookupDto();
//				modelNameLookupDto.setModel_name(list.getString(1));
//				
//				resultList.add(modelNameLookupDto);
//			}
		} 
		catch (WebApplicationException e) 
		{
			throw e;
		} 
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}
		
		try 
		{
			Connection connection = null;
			PreparedStatement preparedStatement = null;	
			ResultSet list = null;
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(totalquery);
				list = preparedStatement.executeQuery();	
				while(list.next())
				{
					total = list.getInt(1);
				}

			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
				if(list != null) list.close();
			}
			
//			ResultSet list = DbConfig.selectQuery(totalquery, null);		
//			while(list.next()) {
//				
//				total = list.getInt(1);
//			}
		} 
		catch (WebApplicationException e) 
		{
			throw e;
		} 
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}

		
		ModelNameLookupCollection modelNameLookupCollection = new ModelNameLookupCollection();
		modelNameLookupCollection.setModelNameLookupName(resultList);
		modelNameLookupCollection.setTotal(total);
		
		return Response.ok(modelNameLookupCollection).type(checkMediaType()).build();
	}
}
