package com.opentext.mediamanager.restapi.file;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.role.RoleIdentifier;
import com.artesia.security.SecuritySession;
import com.artesia.security.UserCriteria;
import com.artesia.user.TeamsUser;
import com.artesia.user.services.UserServices;
import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;

import contants.FileDownloadConstants;
import contants.FilePathContants;
import excel.ExcelRead;
import excel.ExcelReadOption;
import file.FileUtils;
import ttsg_teams.admin.db.DBMgr;
import utils.Utils;


@Path(BaseResource.SUPPORTED_VERSIONS+"/file")
public class FileServices extends BaseResource {
	private static final String COMPONENT 				= contants.AuthorityConstants.COMPONENT_NAME;
	
	private static final String KEY 					= contants.AuthorityConstants.KEY_NAME;
	
	private static final String EX_DOMAIN_ID 			= contants.AuthorityConstants.EX_DOMAIN_ID;
	
	private static final String VALUE_EXTERNAL_ID 		= contants.AuthorityConstants.VALUE_EXTERNAL_ID;
	
	private static final String MPIS_EXTERNAL_ROLE_ID 	= contants.AuthorityConstants.MPIS_EXTERNAL_ROLE_ID;
	
	private static final String MPIS_EXTERNAL_TEMP_ID 	= contants.AuthorityConstants.MPIS_EXTERNAL_TEMP_ID;
	
	private static final String SUCCESS				 	= "Your excel upload is complete";
	
	//private static final String FAILED				 	= "You failed to save";
	
	
	@GET
	@Path("/download/{eventId}")
	public Response  fileDown(@PathParam("eventId") String eventId) {
		String fileName = "";
		if(eventId.equals("1")) 
		{
			fileName = FileDownloadConstants.EXPIRE;
		}
	    
	    File file = new File(contants.FilePathContants.FILE_DOWNLOAD_PATH+fileName);
	    ResponseBuilder resBuilder = Response.ok((Object) file, MediaType.APPLICATION_OCTET_STREAM)
	    		.header("content-disposition", "attachment; filename = "+ fileName);
	    return resBuilder.build();
	    		
	}
	
	@POST
	@Path("/upload/{eventId}")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response  fileUpload(@FormDataParam("file") InputStream inputStream, @FormDataParam("file") FormDataContentDisposition fileDetail, @PathParam("eventId") String eventId, @Context HttpServletRequest request) {
		if (inputStream == null || fileDetail == null)
			return Response.status(400).entity("Invalid form data").build();
		
		try {
			FileUtils.getInstance().createFolderIfNotExists(FilePathContants.EXCEL_U_FILE_PATH);			
		} catch (SecurityException se) {
			return Response.status(500)
					.entity("create folder failed")
					.build();
		}
		
		String originalFileExtension = fileDetail.getFileName().substring(fileDetail.getFileName().lastIndexOf("."));
        String storedFileName = FileUtils.getInstance().getRandomString() + originalFileExtension;
        String uploadedFileLocation  = FilePathContants.EXCEL_U_FILE_PATH + storedFileName;

        
        try {
			FileUtils.getInstance().saveToFile(inputStream, uploadedFileLocation);
		} catch (IOException e) {
			return Response.status(500).entity("Can not save file").build();
		}
        
        //�ܺλ���� �Ⱓ����
        if(eventId.equals("1")) 
        {
        	userExpireUpdate(uploadedFileLocation);
        }
        //�ܺλ���� ����
        else if(eventId.equals("2")) 
        {
        	userInsert(uploadedFileLocation, request);
        }
        		        
        FileUtils.getInstance().deleteFile(uploadedFileLocation);
	    return Response.status(200).entity(SUCCESS).build();	    	
	}
	
	private void userInsert(String uploadedFileLocation, HttpServletRequest request) {		
		SecuritySession session = getOTMMSession(request);
		
		String otdsExDomain 	= Utils.getSystemSetting(COMPONENT, KEY, EX_DOMAIN_ID, session);
		String groupId 			= Utils.getSystemSetting(COMPONENT, KEY, VALUE_EXTERNAL_ID, session);
		String roleId 			= Utils.getSystemSetting(COMPONENT, KEY, MPIS_EXTERNAL_ROLE_ID, session);
		String userTemplateId	= Utils.getSystemSetting(COMPONENT, KEY, MPIS_EXTERNAL_TEMP_ID, session);
		
		
		ExcelReadOption excelReadOption = new ExcelReadOption();
        excelReadOption.setFilePath(uploadedFileLocation);
        excelReadOption.setOutputColumns("A","B","C");
        excelReadOption.setStartRow(2);
        
        List<Map<String, String>> excelContent = ExcelRead.read(excelReadOption);
        
        int index = 1;   
        String lines = null;
        for(Map<String, String> paramsData :  excelContent)
        {
        	if(!paramsData.get("A").trim().isEmpty())
        	{
        		index++;
            	UserCriteria criteria = new UserCriteria();
            	System.out.println("userInsert : " + paramsData.get("A").trim());
    			criteria.setLoginName(paramsData.get("A").trim());
    			try {
    				TeamsUser [] teamUser = UserServices.getInstance().retrieveUsers(criteria, session);
    				if(teamUser.length != 0) 
    				{   
    					if(lines == null)
    					{
    						lines = Integer.toString(index);
    					}
    					else
    					{
    						lines += "," + Integer.toString(index);
    					}					
    				}
    				
    			} catch (BaseTeamsException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
        	}        	
        }
        
        if(lines != null)
        {
        	throw new  OTMMRestException("At line "+lines+", your email is duplicated.", "restapi.error.unknown.error");
        }
        	
        
        for(Map<String, String> param: excelContent){
        	if(!param.get("A").trim().isEmpty())
        	{
        		index++;
            	String email 		= param.get("A").trim();
            	String company 		= param.get("B").trim();
            	String description 	= param.get("C").trim();
            	String loginNm      = email.split("@")[0];
            	String firstNm	    = loginNm;
            	String lastNm       = company;
            	System.out.println("email : " + email + " company : " + company + " description :  " + lastNm);
            	String desc = "E-EXTENAL USER"+","+company+","+description;
            	
            	TeamsUser user = new TeamsUser();
        		user.setLoginName(email);
        		user.setFirstName(firstNm);
        		user.setLastName(lastNm);  
        		user.setPassword(loginNm+"@nMPIS2");
        		user.setEmailAddress(email);
        		user.setDescription(desc);
        		user.setDomainName(otdsExDomain);
        		user.setUserPrefTemplateId(new TeamsNumberIdentifier(Long.parseLong(userTemplateId)));
        		user.setRoleId(new RoleIdentifier(Long.parseLong(roleId)));

        		try {    			
    				UserServices.getInstance().createUser(user,  new TeamsNumberIdentifier[]{new TeamsNumberIdentifier(Long.parseLong(groupId))}, false, false, null, session);
    			} catch (NumberFormatException | BaseTeamsException e) {
    				System.out.println("======================= error");
    				throw new  OTMMRestException(e.getMessage(), "restapi.error.unknown.error");
    			} 
        	}        	
        }
	}
	
	private void userExpireUpdate(String uploadedFileLocation) {
		
		ExcelReadOption excelReadOption = new ExcelReadOption();
        excelReadOption.setFilePath(uploadedFileLocation);
        excelReadOption.setOutputColumns("A");
        excelReadOption.setStartRow(2);
		
        List<Map<String, String>> excelContent = ExcelRead.read(excelReadOption);
        
        for(Map<String, String> param: excelContent){
        	if(!param.get("A").trim().isEmpty())
        	{
        		String loginId = param.get("A").trim();
            	String query = "UPDATE OTMM.LGE_MPIS_USER_MANAGERMENT_CT "
            			+ "SET EXPIRE_DT = CAST(getdate()+90 AS DATE)"
            			+ "WHERE LOGIN_ID =  "+"'"+loginId+"'";        	
            	try {
            		Connection connection = null;
        			PreparedStatement preparedStatement = null;				
        			try
        			{
        				DBMgr db = new DBMgr();
        				connection = db.openDatabase();
        				preparedStatement = connection.prepareStatement(query);
        				preparedStatement.executeUpdate();	
        			}
        			finally
        			{
        				if(connection != null)  connection.close();
        				if(preparedStatement != null) preparedStatement.close();
        			}
    			} 
            	catch (WebApplicationException e) 
        		{
        			throw e;
        		} 
        		catch (Throwable t) 
        		{
        			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
        		}
        	}        	
        }
	}
}

