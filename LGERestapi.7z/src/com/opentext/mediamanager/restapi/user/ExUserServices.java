package com.opentext.mediamanager.restapi.user;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.role.RoleIdentifier;
import com.artesia.security.SecuritySession;
import com.artesia.user.TeamsUser;
import com.artesia.user.services.UserServices;
import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.dto.UserMngDto;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.representation.userMngListCollection;

import ttsg_teams.admin.db.DBMgr;
import utils.Utils;



/*
* ---------------------------------------------------------------------------------------
* PROJ    :   New Marketing Product Information_LGE
* NAME    :   ExUserServices.java
* DESC    :   �ܺλ���� ����
* Author  :   ��â��
* VER     :   v1.0
* Copyright 2019 LG CNS All right reserved
* ---------------------------------------------------------------------------------------
*                       ��             ��           ��          ��
* ---------------------------------------------------------------------------------------
*       DATE       AUTHOR                                  DESCRIPTION
*  ------------ -----------  ------------------------------------------------------------
*   2019.04.25    ��â��            �ܺλ���� ����Ʈ ������� ��� �߰�
*   2019.05.02    ��â��            �ܺλ���� ���� �α��ξ��̵�->�̸��� ����
*   2019.07.25    ��â��            �ܺλ���� ���� OTP�ʱ�ȭ ��� �߰�
* ---------------------------------------------------------------------------------------
*/

@Path(BaseResource.SUPPORTED_VERSIONS+"/ex")
public class ExUserServices extends BaseResource{
	
	public static final Log logger = LogFactory.getLog(ExUserServices.class);
	
	private static final String COMPONENT 				= contants.AuthorityConstants.COMPONENT_NAME;
	
	private static final String KEY 					= contants.AuthorityConstants.KEY_NAME;
	
	private static final String EX_DOMAIN_ID 			= contants.AuthorityConstants.EX_DOMAIN_ID;
	
	private static final String VALUE_EXTERNAL_ID 		= contants.AuthorityConstants.VALUE_EXTERNAL_ID;
	
	private static final String MPIS_EXTERNAL_ROLE_ID 	= contants.AuthorityConstants.MPIS_EXTERNAL_ROLE_ID;
	
	private static final String MPIS_EXTERNAL_TEMP_ID 	= contants.AuthorityConstants.MPIS_EXTERNAL_TEMP_ID;
	
	/**
	 * �ܺλ���� ��ȸ
	 * @param word
	 * @param type
	 * @param before
	 * @param after
	 * @return
	 * @throws BaseTeamsException
	 */
	@GET
	@Path("/user")
	public Response selectExternalUser(@QueryParam("where") String word, @QueryParam("type") String type, @QueryParam("before") String before, @QueryParam("after") String after, @QueryParam("sort") String sort) throws BaseTeamsException{
	
 		ArrayList<UserMngDto> resultList = new ArrayList<>();
		int count = 0;

		StringBuffer sql1 = new StringBuffer();
		sql1.append("SELECT COUNT(*) AS TOTAL \n");
		sql1.append("  FROM OTMM.OTMM.LGE_MPIS_USER_MANAGERMENT_CT \n");
		sql1.append(" WHERE 1 = 1 \n");		
		if(type != null) {
			sql1.append("          AND TYPE = ?  \n");
		}
		if(word != null) { 
			sql1.append(" AND (LOGIN_ID LIKE '%' +? +'%' OR NAME LIKE '%' +? +'%' OR EMAIL_ADDR LIKE '%' +? +'%' OR COMPANY LIKE '%' +? +'%' OR DESCRIPTION LIKE '%' +? +'%')");
		}
		
		logger.info("============= selectExternalUser query1" + sql1.toString());
		
		StringBuffer sql2 = new StringBuffer();
		if(type != null) {
			if(type.equals("S")) {
				sql2.append("SELECT RANK, USER_ID, LOGIN_ID, NAME, EMAIL_ADDR, COMPANY, CASE WHEN LEN(DESCRIPTION) > 20 THEN SUBSTRING(DESCRIPTION, 1, 22)+'...' ELSE DESCRIPTION  END AS DESCRIPTION, IS_DISABLED, CREATE_DT, EXPIRE_DT  \n");
			} else {
				sql2.append("SELECT RANK, USER_ID, LOGIN_ID, NAME, EMAIL_ADDR, COMPANY, DESCRIPTION, IS_DISABLED, CREATE_DT, EXPIRE_DT \n");
			}
		} else {
			sql2.append("SELECT RANK, USER_ID, LOGIN_ID, NAME, EMAIL_ADDR, COMPANY, DESCRIPTION, IS_DISABLED, CREATE_DT, EXPIRE_DT \n");
		}
			
		sql2.append("FROM (  \n");
		if(sort.contains("login_id") || sort.contains("name") || sort.contains("is_disabled"))
		{
			sql2.append("       SELECT ROW_NUMBER() OVER(ORDER BY USERS."+sort+") AS RANK, USERS.USER_ID, USERS.LOGIN_ID, USERS.NAME, CT.EMAIL_ADDR, USERS.IS_DISABLED , CT.COMPANY, CT.DESCRIPTION, CAST(CT.CREATE_DT AS DATE) AS CREATE_DT, CAST(CT.EXPIRE_DT AS DATE) AS EXPIRE_DT   \n");
		}
		else
		{
			sql2.append("       SELECT ROW_NUMBER() OVER(ORDER BY CT."+sort+") AS RANK, USERS.USER_ID, USERS.LOGIN_ID, USERS.NAME, CT.EMAIL_ADDR, USERS.IS_DISABLED, CT.COMPANY, CT.DESCRIPTION, CAST(CT.CREATE_DT AS DATE) AS CREATE_DT, CAST(CT.EXPIRE_DT AS DATE) AS EXPIRE_DT   \n");
		}
		
		sql2.append("         FROM OTMM.OTMM.USERS AS USERS  \n");
		sql2.append("   INNER JOIN OTMM.OTMM.LGE_MPIS_USER_MANAGERMENT_CT AS CT  \n");
		sql2.append("           ON USERS.USER_ID  = CT.USER_ID   \n");
		sql2.append("        WHERE 1 = 1 \n");
		if(type != null) {
			sql2.append("          AND TYPE = ?  \n");			
		}

		if(word != null) {
			sql2.append("      AND (USERS.LOGIN_ID LIKE '%' +? +'%' OR USERS.NAME LIKE '%' +? +'%' OR CT.EMAIL_ADDR LIKE '%' +? +'%' OR CT.COMPANY LIKE '%' +? +'%' OR CT.DESCRIPTION LIKE '%' +? +'%') \n");
		}
		sql2.append("    ) T1  \n");
		sql2.append("WHERE  1 = 1  \n");
		sql2.append("  AND RANK BETWEEN ? AND ? \n");
				
		logger.info("============= selectExternalUser query2" + sql2.toString());
		ResultSet list1 = null;
		ResultSet list2 = null;
		try {
			
				Connection connection = null;
				PreparedStatement preparedStatement = null;				
				try
				{
					DBMgr db = new DBMgr();
					connection = db.openDatabase();
					preparedStatement = connection.prepareStatement(sql1.toString());
					if(type != null && word != null) {
						preparedStatement.setString(1, type);
						preparedStatement.setString(2, word);
						preparedStatement.setString(3, word);
						preparedStatement.setString(4, word);
						preparedStatement.setString(5, word);
						preparedStatement.setString(6, word);
					}
					else if(type != null && word == null)
					{
						preparedStatement.setString(1, type);
					}
					else if(type == null && word != null)
					{
						preparedStatement.setString(1, word);
						preparedStatement.setString(2, word);
						preparedStatement.setString(3, word);
						preparedStatement.setString(4, word);
						preparedStatement.setString(5, word);
					}
					
					list1 = preparedStatement.executeQuery();	
					while(list1.next())
					{
						count = list1.getInt("total");
					}
				}
				finally
				{
					if(connection != null)  connection.close();
					if(preparedStatement != null) preparedStatement.close();
					if(list1 != null) list1.close();
				}							
				try
				{
					DBMgr db = new DBMgr();
					connection = db.openDatabase();
					preparedStatement = connection.prepareStatement(sql2.toString());
					if(type != null && word != null) {
						preparedStatement.setString(1, type);
						preparedStatement.setString(2, word);
						preparedStatement.setString(3, word);
						preparedStatement.setString(4, word);
						preparedStatement.setString(5, word);
						preparedStatement.setString(6, word);
						preparedStatement.setString(7, before);
						preparedStatement.setString(8, after);
					}
					else if(type != null && word == null)
					{
						preparedStatement.setString(1, type);
						preparedStatement.setString(2, before);
						preparedStatement.setString(3, after);
					}
					else if(type == null && word != null)
					{
						preparedStatement.setString(1, word);
						preparedStatement.setString(2, word);
						preparedStatement.setString(3, word);
						preparedStatement.setString(4, word);
						preparedStatement.setString(5, word);
						preparedStatement.setString(6, before);
						preparedStatement.setString(7, after);
					}
					else
					{
						preparedStatement.setString(1, before);
						preparedStatement.setString(2, after);
					}
					list2 = preparedStatement.executeQuery();	
					while(list2.next())
					{
						UserMngDto userDto = new UserMngDto();
						userDto.setUserId(list2.getString("user_id"));
						userDto.setLoginId(list2.getString("login_id"));
						userDto.setName(list2.getString("name"));
						userDto.setEmailAddr(list2.getString("email_addr"));
						userDto.setCompany(list2.getString("company"));
						userDto.setIsDisabled(list2.getString("is_disabled"));
						userDto.setDescription(list2.getString("description"));
						userDto.setCreateDt(list2.getString("create_dt"));
						userDto.setExpireDt(list2.getString("expire_dt"));														
						resultList.add(userDto);
					}
				}
				finally
				{
					if(connection != null)  connection.close();
					if(preparedStatement != null) preparedStatement.close();
					if(list2 != null) list1.close();
				}
		}
		catch (WebApplicationException e) 
		{
			throw e;
		} 
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}
		
		userMngListCollection userList = new userMngListCollection();		
		userList.setUserList(resultList);		
		userList.setTotal(count);
		
		return Response.ok(userList, MediaType.APPLICATION_JSON_TYPE).build();		
	}
	
	/**
	 * �ܺλ���� ����
	 * @param loginNm
	 * @param email
	 * @param firstNm
	 * @param lastNm
	 * @param groupId
	 * @param request
	 * @return
	 * @throws BaseTeamsException
	 */
	@POST
	@Path("/user")
	@Consumes({"application/x-www-form-urlencoded"})
	public Response createUser(@FormParam("loginNm") String loginNm, 		@FormParam("loginEmail") String email, 
							   @FormParam("firstNm") String firstNm, 		@FormParam("lastNm") String lastNm, 
							   @FormParam("company") String company,        @FormParam("description") String description,		
							   @Context HttpServletRequest request) throws BaseTeamsException{
		System.out.println("==================================================");
		SecuritySession session = getOTMMSession(request);
		
		String otdsExDomain 	= Utils.getSystemSetting(COMPONENT, KEY, EX_DOMAIN_ID, session);
		String groupId 			= Utils.getSystemSetting(COMPONENT, KEY, VALUE_EXTERNAL_ID, session);
		String roleId 			= Utils.getSystemSetting(COMPONENT, KEY, MPIS_EXTERNAL_ROLE_ID, session);
		String userTemplateId	= Utils.getSystemSetting(COMPONENT, KEY, MPIS_EXTERNAL_TEMP_ID, session);
		
		String desc = "E-EXTENAL USER"+","+company+","+description;
		
		//2019-04-29 �ܺ� ����� ���� ���̵� �̸��Ϸ� ����
		TeamsUser user = new TeamsUser();
		user.setLoginName(email);
		user.setFirstName(firstNm);
		user.setLastName(lastNm);  
		user.setPassword(loginNm+"@nMPIS2");  
		user.setEmailAddress(email);
		user.setDescription(desc);
		user.setDomainName(otdsExDomain);
		user.setUserPrefTemplateId(new TeamsNumberIdentifier(Long.parseLong(userTemplateId)));
		user.setRoleId(new RoleIdentifier(Long.parseLong(roleId)));

		
		try {
			UserServices.getInstance().createUser(user,  new TeamsNumberIdentifier[]{new TeamsNumberIdentifier(Long.parseLong(groupId))}, false, false, null, session);
		} catch (Exception e) 
		{
			throw e;
		} 
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}
		return Response.status(200).build();
	}
	
	@PUT  
	@Path("/user")
	@Consumes({"application/x-www-form-urlencoded"})
	public Response updateUser(@FormParam("loginNm") String loginNm, 		@FormParam("expritDt") String expritDt, 
							   @FormParam("company") String company,        @FormParam("description") String description,	
							   @FormParam("isDisabled") String useYn,
							   @Context HttpServletRequest request) throws BaseTeamsException{
		
//		if(Utils.blackListCheck(company) || Utils.blackListCheck(description) ) 
//		{
//			return Response.status(400).entity("security policy").build();
//			//return Response.status(Response.Status.OK).build();
//		}
		SecuritySession session = getOTMMSession(request); 
		TeamsUser userInfo = Utils.getUserInfo(session, loginNm);
		String query = null;
		String com = company;
		String desc = description;

		//����� ��ݻ��� Ȯ��
		if(userInfo.getDisabled())
		{
			boolean useFlag = false;
			if(useYn.equals("Y")) useFlag  = true; 
			else useFlag = false;
			//����� ���°��� �Ķ���Ͱ��� �ٸ� ���
			System.out.println("userInfo.getDisabled() : " + userInfo.getDisabled() + "    useFlag : " + useFlag );
			if(userInfo.getDisabled() != useFlag)
			{
				userInfo.setDisabled(useFlag);
				UserServices.getInstance().updateUser(userInfo, null, false, false, "", session);
				System.out.println("userInfo.getDisabled() : " + userInfo.getDisabled() + "    useFlag : " + useFlag );
				//��������� �����Ѵٸ� ���糯¥ +90�� ����
				if(useFlag == false)
				{
					query =  "UPDATE OTMM.LGE_MPIS_USER_MANAGERMENT_CT " + 
							"  SET COMPANY 		= ?" + 
							"     ,DESCRIPTION 	= ? " +   
							"     ,EXPIRE_DT 	= CONVERT(DATETIME, ?)" + 
							" WHERE LOGIN_ID 	= ?";
				}
				//��������� ����Ȱ� ���ٸ� �ܼ� ������Ʈ
				else
				{
					query =  "UPDATE OTMM.LGE_MPIS_USER_MANAGERMENT_CT " + 
							"  SET COMPANY 		= ?" + 
							"     ,DESCRIPTION 	= ? " +   
							"     ,EXPIRE_DT 	= CONVERT(DATETIME, ?)" + 
							" WHERE LOGIN_ID 	= ?";
				}				
			}else
			{
				query =  "UPDATE OTMM.LGE_MPIS_USER_MANAGERMENT_CT " + 
						"  SET COMPANY 		= ?" + 
						"     ,DESCRIPTION 	= ? " +   
						"     ,EXPIRE_DT 	= CONVERT(DATETIME, ?)" + 
						" WHERE LOGIN_ID 	= ?";
			}
		}
		//����ڰ� ��ݻ��°� �ƴϸ� �ܼ� ������Ʈ
		else
		{
			System.out.println("useYn : " +useYn );
			if(useYn.equals("Y"))
			{
				System.out.println("useYn true");
				userInfo.setDisabled(true);
				UserServices.getInstance().updateUser(userInfo, null, false, false, "", session);
			}
			
			query =  "UPDATE OTMM.LGE_MPIS_USER_MANAGERMENT_CT " + 
					"  SET COMPANY 		= ?" + 
					"     ,DESCRIPTION 	= ? " +   
					"     ,EXPIRE_DT 	= CONVERT(DATETIME, ?)" + 
					" WHERE LOGIN_ID 	= ?";
		}

		try {
			Connection connection = null;
			PreparedStatement preparedStatement = null;				
			try
			{
				
				System.out.println("com : " + com + " desc :" + desc + "loginNm :" + loginNm);
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(query);
				
				preparedStatement.setString(1, com);
				preparedStatement.setString(2, desc);
				preparedStatement.setString(3, expritDt);
				preparedStatement.setString(4, loginNm);
				preparedStatement.executeUpdate();
				
			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
			}			
		} catch (WebApplicationException e) 
		{
			throw e;
		} 
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}
		
		return Response.status(200).build();	
	}
	
	
	/**
	 * �ܺλ���� ���� ��ȿ�� üũ
	 * @param search
	 * @param type (L : loginId, E : emailAddr)
	 * @return
	 * @throws BaseTeamsException
	 */
	@GET
	@Path("/validation")
	@Produces(MediaType.TEXT_PLAIN)   
	public Response validation(@QueryParam("search") String search, @QueryParam("type") String type) throws BaseTeamsException{
		
		
		if(Utils.blackListCheck(search)) 
		{			
			return Response.status(400).entity("security policy").build();
		}
		
		if(Utils.blackListCheck(type)) 
		{			
			return Response.status(400).entity("security policy").build();
		}
		
		StringBuffer sql = new StringBuffer();
		String count = "0";
		sql.append("SELECT COUNT(1) AS CNT \n");
		sql.append("  FROM OTMM.LGE_MPIS_USER_MANAGERMENT_CT \n");
		if(type.equals("L")) {
			sql.append("WHERE LOGIN_ID = ?");
		}
		else if(type.equals("E")) {
			sql.append("WHERE EMAIL_ADDR = ?");
		}		
	
		try
		{  
			Connection connection = null;
			PreparedStatement preparedStatement = null;	
			ResultSet list = null;
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(sql.toString());
				preparedStatement.setString(1, search);
				list = preparedStatement.executeQuery();	
				while(list.next())
				{
					count = list.getString("cnt");		
				}

			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
				if(list != null) list.close();
			}
		}
				
		catch (WebApplicationException e) 
		{
			throw e;
		} 
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}
		return Response.status(200).entity(count).build();		
	}

	
	/**
	 * �ܺλ���� ���� OTP �ʱ�ȭ
	 * @param login_id(OTDS user_name)
	 * @return
	 * @throws BaseTeamsException
	 */
	@POST  
	@Consumes({"application/x-www-form-urlencoded"})
	@Path("/resetOtp")
	public Response resetGoogleOtp(@FormParam("login_id") String login_id, @Context HttpServletRequest request) throws BaseTeamsException{
		Properties properties = new Properties();
		String parameter = "";
		String authUrl = "";
		String resetUrl = "";

		try 
		{
			//������Ƽ���� �ε�
			properties.load(this.getClass().getResourceAsStream("otdsInfo.properties"));
			
			//ȯ�濡 ���� URL ����(DEV,QA,PROD)
			if(request.getRequestURL().toString().contains("nmpis.lge.com"))
			{
				parameter	= properties.getProperty("OTDS.PROD.ACCOUNT"); 
				authUrl 	= properties.getProperty("OTDS.PROD.AUTH.URL");		
				resetUrl 	= MessageFormat.format(properties.getProperty("OTDS.PROD.OTPRESET.URL"), login_id);
			}
			else if(request.getRequestURL().toString().contains("nmpisqa.lge.com"))
			{
				parameter	= properties.getProperty("OTDS.QA.ACCOUNT"); 
				authUrl 	= properties.getProperty("OTDS.QA.AUTH.URL");		
				resetUrl 	= MessageFormat.format(properties.getProperty("OTDS.QA.OTPRESET.URL"), login_id);
			}
			else
			{
				parameter	= properties.getProperty("OTDS.DEV.ACCOUNT"); 
				authUrl 	= properties.getProperty("OTDS.DEV.AUTH.URL");		
				resetUrl 	= MessageFormat.format(properties.getProperty("OTDS.DEV.OTPRESET.URL"), login_id);
			}
			
			HttpClient client = HttpClientBuilder.create().setDefaultRequestConfig(RequestConfig.custom().setCookieSpec(CookieSpecs.STANDARD).build()).build();

			HttpPost postRequest =  new HttpPost(authUrl);
			postRequest.setHeader("Accept", "application/json");
			postRequest.setHeader("Connection", "keep-alive");
			postRequest.setHeader("Content-Type", "application/json");
			postRequest.setEntity(new StringEntity(parameter)); //json �޽��� �Է� 

			HttpResponse response = client.execute(postRequest);
			//�����ڵ尡 200(����)�� ��� ����
			if (response.getStatusLine().getStatusCode() == 200) 
			{
				ResponseHandler<String> handler = new BasicResponseHandler();
				JSONParser parser = new JSONParser();
				try 
				{
					Object oj = parser.parse(handler.handleResponse(response));
					JSONObject json = (JSONObject) oj;
					
					//OTDS Ticket, Token�� header�� ����
					String code = (String)json.get("ticket");
					String token = (String)json.get("token");
					HttpClient client2 = HttpClientBuilder.create().setDefaultRequestConfig(RequestConfig.custom().setCookieSpec(CookieSpecs.STANDARD).build()).build();
					
					HttpPut putRequest =  new HttpPut(resetUrl);
					putRequest.setHeader("Accept", "*/*");
					putRequest.setHeader("Content-Type", "text/plain;charset=UTF-8");
					putRequest.setHeader("Connection", "keep-alive");					
					putRequest.setHeader("OTDSTicket", code);
					putRequest.setHeader("otdscsrf", token);					
					response = client2.execute(putRequest);
					
					//�����ڵ尡 204(����)�� �ƴ� ��� 
					if(response.getStatusLine().getStatusCode() != 204)
					{
						throw new OTMMRestException(response.getStatusLine().getReasonPhrase(), "restapi.error.otdsLogin.error");
					}
				} 
				catch (ParseException e) 
				{
					e.printStackTrace();
					logger.info("GOOGLE OTP RESET ERROR : " + e.getMessage());
					throw new OTMMRestException(e.getMessage(), e.getMessage());
				}
			}
			else
			{
				throw new OTMMRestException(response.getStatusLine().getReasonPhrase(), "restapi.error.fileNotFound.error");
			}
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
			logger.info("FileNotFoundException ERROR : " + e.getMessage());
			throw new OTMMRestException(e.getMessage(), "restapi.error.fileNotFound.error");
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			logger.info("IOException ERROR : " + e.getMessage());
			throw new OTMMRestException(e.getMessage(), "restapi.error.IO.error");
		} 
		return Response.ok(Utils.bodyMessage(Response.Status.OK.getStatusCode(), login_id + " Google otp reset is completed."), MediaType.APPLICATION_JSON_TYPE).build();
	}
}
