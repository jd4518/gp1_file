package com.opentext.mediamanager.restapi.session;

import javax.servlet.http.HttpServletRequest;

import com.opentext.mediamanager.restapi.common.sso.ISSOResolver;

public class CreateSsoResolver implements ISSOResolver{

	@Override
	public String resolveToUserName(HttpServletRequest httpServletRequest) {
		String userId = httpServletRequest.getHeader("user_id");
		return userId;
	}
}
