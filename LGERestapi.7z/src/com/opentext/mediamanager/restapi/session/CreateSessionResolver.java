package com.opentext.mediamanager.restapi.session;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.common.exception.BaseTeamsException;
import com.artesia.security.SecuritySession;
import com.artesia.security.session.services.LocalAuthenticationServices;
import com.opentext.mediamanager.restapi.common.sso.ISessionResolver;
/**
 * ����� �������� ���
 * @author chungkyu1.lee
 *
 */
public class CreateSessionResolver implements ISessionResolver{
	
	private static final Log log = LogFactory.getLog(CreateSessionResolver.class);
	
	public SecuritySession resolveSecuritySession(HttpServletRequest httpServletRequest)
	  {
	    SecuritySession securitySession = null;
	      try
	      {
	    	  log.debug("=== CreateSessionResolver === : "+ httpServletRequest.getHeader("user_id"));
	    	  String userId = httpServletRequest.getHeader("user_id");
	    	  if(null != userId)
	    	  {
	    		  securitySession = LocalAuthenticationServices.getInstance().createLocalSession(userId);
	    	  }	    	  
	      }
	      catch (BaseTeamsException e) 
	      {
	    	  log.debug("======= CreateSessionResolver Error : " + e.getMessage());
	      }
	   
	    return securitySession;
	  }
}
