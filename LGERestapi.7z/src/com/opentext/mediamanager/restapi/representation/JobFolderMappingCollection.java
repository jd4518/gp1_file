package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.common.BaseRepresentation;
import com.opentext.mediamanager.restapi.dto.JobFolderMappingDto;

@XmlRootElement(name = "JobFolder_Resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class JobFolderMappingCollection extends BaseRepresentation {

	@XmlElement(name = "Folder_Data")
	private List<JobFolderMappingDto> jobFolderMappingData;

	public List<JobFolderMappingDto> getJobFolderMappingData() {
		return jobFolderMappingData;
	}

	public void setJobFolderMappingData(List<JobFolderMappingDto> jobFolderMappingData) {
		this.jobFolderMappingData = jobFolderMappingData;
	}

}
