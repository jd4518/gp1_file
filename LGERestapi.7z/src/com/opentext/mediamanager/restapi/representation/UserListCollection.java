package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;



import com.opentext.mediamanager.restapi.common.BaseRepresentation;
import com.opentext.mediamanager.restapi.dto.UserListDto;

@XmlRootElement(name="user_list_resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserListCollection extends BaseRepresentation{
	
	@XmlElement(name="user_list")
	private List<UserListDto> userList;

	public List<UserListDto> getUserList() {
		return userList;
	}

	public void setUserList(List<UserListDto> userList) {
		this.userList = userList;
	}
}
