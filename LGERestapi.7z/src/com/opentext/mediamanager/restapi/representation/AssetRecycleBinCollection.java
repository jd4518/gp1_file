package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.common.BaseRepresentation;
import com.opentext.mediamanager.restapi.dto.AssetRecycleBinDto;

@XmlRootElement(name="asset_list_resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class AssetRecycleBinCollection extends BaseRepresentation {

	@XmlElement(name = "Asset_List")
	private List<AssetRecycleBinDto> assetList;
	
	@XmlElement(name = "Total_Count")
	private long totalCount;
	
	public List<AssetRecycleBinDto> getAssetList() {
		return assetList;
	}

	public void setAssetList(List<AssetRecycleBinDto> assetList) {
		this.assetList = assetList;
	}

	public long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}
}
