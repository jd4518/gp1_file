package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.common.BaseRepresentation;
import com.opentext.mediamanager.restapi.dto.AddAttributeLookupDto;

@XmlRootElement(name = "Attribute_Resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class AddAttributeLookupCollection extends BaseRepresentation {

	@XmlElement(name = "Attribute_List")
	private List<AddAttributeLookupDto> addAttributeLookupName;

	public List<AddAttributeLookupDto> getAddAttributeLookupName() {
		return addAttributeLookupName;
	}

	public void setAddAttributeLookupName(List<AddAttributeLookupDto> addAttributeLookupName) {
		this.addAttributeLookupName = addAttributeLookupName;
	}
}
