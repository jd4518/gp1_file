package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.common.BaseRepresentation;
import com.opentext.mediamanager.restapi.dto.SalesLookupDto;

@XmlRootElement(name = "Sales_Resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class SalesLookupCollection extends BaseRepresentation {

	@XmlElement(name = "Sales_List")
	private List<SalesLookupDto> salesLookupName;

	public List<SalesLookupDto> getSalesLookupName() {
		return salesLookupName;
	}

	public void setSalesLookupName(List<SalesLookupDto> salesLookupName) {
		this.salesLookupName = salesLookupName;
	}
}
