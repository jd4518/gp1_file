package com.opentext.mediamanager.restapi.representation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.dto.MessageBodyDto;

@XmlRootElement(name="messageBody")
@XmlAccessorType(XmlAccessType.FIELD)
public class MessageBodyCollection {
	@XmlElement(name="response")
	private MessageBodyDto body;

	public MessageBodyDto getBody() {
		return body;
	}

	public void setBody(MessageBodyDto body) {
		this.body = body;
	}	
}
