package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.common.BaseRepresentation;
import com.opentext.mediamanager.restapi.dto.GroupListDto;

@XmlRootElement(name="Group_list_resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class GroupListCollection extends BaseRepresentation{
	
	@XmlElement(name="Group_list")
	private List<GroupListDto> groupUserList;

	public List<GroupListDto> getGroupUserList() {
		return groupUserList;
	}

	public void setGroupUserList(List<GroupListDto> groupUserList) {
		this.groupUserList = groupUserList;
	}

		
}
