package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.common.BaseRepresentation;
import com.opentext.mediamanager.restapi.dto.JobAddressListDto;

@XmlRootElement(name = "Job_Adress_List_Resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class JobAddressListCollection extends BaseRepresentation {

	@XmlElement(name = "Job_Adress_List")
	private List<JobAddressListDto> jobAddressList;

	public List<JobAddressListDto> getJobAddressList() {
		return jobAddressList;
	}

	public void setJobAddressList(List<JobAddressListDto> jobAddressList) {
		this.jobAddressList = jobAddressList;
	}


}
