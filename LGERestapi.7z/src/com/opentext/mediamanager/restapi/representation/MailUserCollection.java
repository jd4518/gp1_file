package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.dto.UserListDto;

@XmlRootElement(name="mail_user_resources")
@XmlAccessorType(XmlAccessType.FIELD)
public class MailUserCollection {
	
	@XmlElement(name="mail_user_list")
	private List<UserListDto> userList;

	public List<UserListDto> getUserList() {
		return userList;
	}

	public void setUserList(List<UserListDto> userList) {
		this.userList = userList;
	}

}
