package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.common.BaseRepresentation;
import com.opentext.mediamanager.restapi.dto.ContentTypeLookupDto;

@XmlRootElement(name = "Content_Type_Resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class ContentTypeLookupCollection extends BaseRepresentation {

	@XmlElement(name = "Content_Type_List")
	private List<ContentTypeLookupDto> contentTypeLookupName;

	public List<ContentTypeLookupDto> getContentTypeLookupName() {
		return contentTypeLookupName;
	}

	public void setContentTypeLookupName(List<ContentTypeLookupDto> contentTypeLookupName) {
		this.contentTypeLookupName = contentTypeLookupName;
	}




}
