package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.common.BaseRepresentation;
import com.opentext.mediamanager.restapi.dto.JobFolderNameDto;

@XmlRootElement(name = "Job_Folder_Name_Resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class JobFolderNameCollection extends BaseRepresentation {

	@XmlElement(name = "Job_Folder_Name")
	private List<JobFolderNameDto> jobFolderName;

	public List<JobFolderNameDto> getJobFolderName() {
		return jobFolderName;
	}

	public void setJobFolderName(List<JobFolderNameDto> jobFolderName) {
		this.jobFolderName = jobFolderName;
	}



}
