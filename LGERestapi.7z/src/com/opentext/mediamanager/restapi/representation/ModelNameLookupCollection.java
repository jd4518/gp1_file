package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.common.BaseRepresentation;
import com.opentext.mediamanager.restapi.dto.ModelNameLookupDto;

@XmlRootElement(name = "ModelName_Resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class ModelNameLookupCollection extends BaseRepresentation {

	@XmlElement(name = "ModelName_List")
	private List<ModelNameLookupDto> modelNameLookupName;
	
	@XmlElement(name = "total")
	private int total;

	public List<ModelNameLookupDto> getModelNameLookupName() {
		return modelNameLookupName;
	}

	public void setModelNameLookupName(List<ModelNameLookupDto> modelNameLookupName) {
		this.modelNameLookupName = modelNameLookupName;
	}

	public int getTotal() {
		return total;
	}
	
	public void setTotal(int total) {
		this.total = total;
	}

}
