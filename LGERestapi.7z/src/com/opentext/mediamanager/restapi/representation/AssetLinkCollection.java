package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.dto.AssetListDto;

@XmlRootElement(name="asset_list_resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class AssetLinkCollection {

public AssetLinkCollection () {}
	
	public AssetLinkCollection(int total, List<AssetListDto> assetList) {
		this.assetList = assetList;		
		this.total = total;
	} 
	
	public int getTotal() {
		return total;
	}

	public void setTotal(int total) { 
		this.total = total;
	}

	@XmlElement(name="asset_list")
	private List<AssetListDto> assetList;
	
	@XmlElement(name="total")
	private int total;
	
	public List<AssetListDto> getAssetList() {
		return assetList;
	}

	public void setAssetList(List<AssetListDto> assetList) {
		this.assetList = assetList;
	}
}
