package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.dto.AssetExpiredListDto;

@XmlRootElement(name="asset_list_resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class AssetExpiredCollection {

public AssetExpiredCollection () {}
	
	public AssetExpiredCollection(List<AssetExpiredListDto> assetList) {
		this.assetList = assetList;		
	} 

	@XmlElement(name="asset_list")
	private List<AssetExpiredListDto> assetList;

	public List<AssetExpiredListDto> getAssetList() {
		return assetList;
	}

	public void setAssetList(List<AssetExpiredListDto> assetList) {
		this.assetList = assetList;
	}

	

}
