package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.common.BaseRepresentation;
import com.opentext.mediamanager.restapi.dto.CPUnitLookupDto;

@XmlRootElement(name = "CPUnit_Resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class CPUnitLookupCollection extends BaseRepresentation {

	@XmlElement(name = "CPUnit_List")
	private List<CPUnitLookupDto> cpunitLookupName;
	
	@XmlElement(name = "CPUnit_which")
	private int cpnumber;

	public int getCpnumber() {
		return cpnumber;
	}

	public void setCpnumber(int cpnumber) {
		this.cpnumber = cpnumber;
	}

	public List<CPUnitLookupDto> getCpunitLookupName() {
		return cpunitLookupName;
	}

	public void setCpunitLookupName(List<CPUnitLookupDto> cpunitLookupName) {
		this.cpunitLookupName = cpunitLookupName;
	}





}
