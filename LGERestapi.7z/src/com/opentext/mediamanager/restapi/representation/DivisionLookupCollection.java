package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.common.BaseRepresentation;
import com.opentext.mediamanager.restapi.dto.DivisionLookupDto;

@XmlRootElement(name = "Division_Lookup_Resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class DivisionLookupCollection extends BaseRepresentation {

	@XmlElement(name = "Division_Lookup_Name")
	private List<DivisionLookupDto> divisionLookupName;

	public List<DivisionLookupDto> getDivisionLookupName() {
		return divisionLookupName;
	}

	public void setDivisionLookupName(List<DivisionLookupDto> divisionLookupName) {
		this.divisionLookupName = divisionLookupName;
	}

	


}
