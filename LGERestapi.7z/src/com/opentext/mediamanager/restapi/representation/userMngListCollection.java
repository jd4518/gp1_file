package com.opentext.mediamanager.restapi.representation;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.opentext.mediamanager.restapi.common.BaseRepresentation;
import com.opentext.mediamanager.restapi.dto.UserMngDto;

@XmlRootElement(name="user_mng_list_resource")
@XmlAccessorType(XmlAccessType.FIELD)
public class userMngListCollection extends BaseRepresentation{
	
	public userMngListCollection () {}
	
	public userMngListCollection(int total, List<UserMngDto> userList) {
		this.total = total;
		this.userList = userList;				
	}
	
	@XmlElement(name="user_list")
	private List<UserMngDto> userList;
	
	@XmlElement(name="total")
	private int total;
	

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public List<UserMngDto> getUserList() {
		return userList;
	}

	public void setUserList(List<UserMngDto> userList) {
		this.userList = userList;
	}

}
