package com.opentext.mediamanager.restapi.monitoring;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opentext.mediamanager.restapi.common.BaseResource;

import ttsg_teams.common.common.TForwardEmail;
import utils.Utils;


@Path(BaseResource.SUPPORTED_VERSIONS+"/monitoring")
public class OtmmMonitoringServices extends BaseResource{
	
	private static final Log LOGGER = LogFactory.getLog(OtmmMonitoringServices.class);

	@Path("/upload")
	@GET
	public Response updateAssetsState(@Context HttpServletRequest request)
	{
		
		LOGGER.info("========================= OtmmMonitoringServices START =========================");
		Map<String, String> map = new HashMap<>();
		StringBuffer returnValue = new StringBuffer();
		
		String toAddrs = Utils.getSystemSetting("MONITORING", "CONFIG", "ADDRS", getOTMMSession(request));
		
		InetAddress local;
		String OTMMServer = null;
		
		try {
		    local = InetAddress.getLocalHost();
		    String ip = local.getHostAddress();
		    
		    if(ip.equals("10.150.250.21"))		OTMMServer = "#OTMM1";
		    else if(ip.equals("10.150.250.81")) OTMMServer = "#OTMM2";
		    else OTMMServer = "#OTMM3";		    
		} catch (UnknownHostException e1) {
		    e1.printStackTrace();
		}
		
		
		returnValue.append("Dears,");
		returnValue.append("\n");
		returnValue.append("\n");
		returnValue.append(OTMMServer+" Server Upload Canceled.");
		returnValue.append("\n");
		returnValue.append("Please check it out soon.");         			
		returnValue.append("\n");
		returnValue.append("\n");
		returnValue.append("");
		returnValue.append("\n");
		returnValue.append("\n");
		returnValue.append("Thanks.");  
			
		map.put("fromAddress", 		"nmpis@lge.com");
		map.put("toAddress", 		toAddrs);
		map.put("ccAddress", 		"");
		map.put("replyToAddr", 		"");
		map.put("subject", 			"[New MPIS] OTMM Upload Canceled Error");     			   			
		map.put("body", 			returnValue.toString());
		map.put("serverName", 		Utils.getSystemSetting("COMMON", "SERVER", "EMAIL_SERVER", getOTMMSession(request)));     			
 
		
		TForwardEmail fEmail = new TForwardEmail();
		fEmail.setDestination(map.get("toAddress"));
//	    fEmail.setCCDestination(ccAddress);
//	    fEmail.setReplyToDestination(replyToAddr);
	    fEmail.setFrom(map.get("fromAddress"));
	    fEmail.setSubject(map.get("subject"));
	    fEmail.setBody(map.get("body"));
	    fEmail.setServer(map.get("serverName"));
	    fEmail.send();
	    
	    LOGGER.info("========================= OtmmMonitoringServices END =========================");
	    
	    
		return Response.ok().type(checkMediaType()).build();
  	}
	
	
}
