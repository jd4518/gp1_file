package com.opentext.mediamanager.restapi.asset;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.Asset;
import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.services.AssetDataLoadRequest;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.metadata.MetadataElement;
import com.artesia.metadata.MetadataField;
import com.artesia.search.Search;
import com.artesia.search.SearchCondition;
import com.artesia.search.SearchConstants;
import com.artesia.search.SearchPagedResult;
import com.artesia.search.SearchScalarCondition;
import com.artesia.search.services.AssetSearchServices;
import com.artesia.security.SecuritySession;
import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.dto.AssetExpiredListDto;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.representation.AssetExpiredCollection;
import com.opentext.mediamanager.restapi.util.ParamValidationUtils;

import ttsg_teams.admin.db.DBMgr;
import utils.Utils;

/*
* ---------------------------------------------------------------------------------------
* PROJ    :   New Marketing Product Information_LGE
* NAME    :   ExpiredAssetInfoServices.java
* DESC    :   ������ ������� ����� ��¥ Assets ���� ����
* Author  :   ��â��
* VER     :   v1.0
* Copyright 2019 LG CNS All right reserved
* ---------------------------------------------------------------------------------------
*                       ��             ��           ��          ��
* ---------------------------------------------------------------------------------------
*       DATE       AUTHOR                                  DESCRIPTION
*  ------------ -----------  ------------------------------------------------------------
*   2019.10.08    ��â��           ����� Assets�� ���� ��������. JsonŸ��
* ---------------------------------------------------------------------------------------
*/

@Path(BaseResource.SUPPORTED_VERSIONS+"/expire")
public class ExpiredAssetInfoServices extends BaseResource{
	
	
	private static final Log logger = LogFactory.getLog(ExpiredAssetInfoServices.class);
	// �˻��� Field
	public static final TeamsIdentifier META_UOI_ID = new TeamsIdentifier("ARTESIA.FIELD.ASSET ID");
	public static final TeamsIdentifier META_EXPIRATION_DT = new TeamsIdentifier("ARTESIA.FIELD.EXPIRATION DATE");
	public static final TeamsIdentifier META_SEC_POLICY_ID = new TeamsIdentifier("ARTESIA.FIELD.SECURITY POLICIES");
	public static final String leftParen = "(";
	public static final String rightParen = ")";

	@GET
	@Path("/assetList")
	public Response selectAssetList(@QueryParam("assetIds") String assetIds, @Context HttpServletRequest request) throws BaseTeamsException{ 
		
		SecuritySession session = Utils.getLocalSession2();
		List<String> search_Strs = ParamValidationUtils.splitCommaSeperatedParameter(assetIds);

		ArrayList<AssetExpiredListDto> resultList = new ArrayList<>();

		Search search = new Search();
		List<SearchCondition> idList = new ArrayList<SearchCondition>();
		// ���� ��¥ ���ؿ���
		SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
		String today = dateformat.format(Calendar.getInstance().getTime()).toString();

		AssetDataLoadRequest dataRequest = new AssetDataLoadRequest();
		dataRequest.setLoadAssetContentInfo(true);
		dataRequest.setLoadMetadataByModel(true);
		dataRequest.setLoadAssetContentWithText(true);
		dataRequest.setLoadMetadata(true);
		
		try {

			for (int i = 0; i < search_Strs.size(); i++) {

				String search_Str = search_Strs.get(i);
				SearchScalarCondition uoiid = new SearchScalarCondition(META_UOI_ID,SearchConstants.OPERATOR_ID__CHAR_IS, search_Str);
				uoiid.setRelationalOperator(SearchConstants.OPERATOR_OR);
				if (i == 0)
					uoiid.setLeftParen(leftParen);
				if (i == search_Strs.size() - 1)
					uoiid.setRightParen(rightParen);
				idList.add(uoiid);

				Asset retriveAsst = AssetServices.getInstance().retrieveAsset(new AssetIdentifier(search_Str), dataRequest, session);
				if (retriveAsst == null) {
					AssetExpiredListDto searchExpireAssetDto = new AssetExpiredListDto();
					searchExpireAssetDto.setAssetExpireDate(today + " 00:00:00.0");
					searchExpireAssetDto.setAssetId(search_Str);
					searchExpireAssetDto.setStatus("deleted");
					resultList.add(searchExpireAssetDto);
				}

			}

			SearchScalarCondition exDate = new SearchScalarCondition(META_EXPIRATION_DT,
					SearchConstants.OPERATOR_ID__DATE_IS_BEFORE, today);
			exDate.setRelationalOperator(SearchConstants.OPERATOR_AND);
			exDate.setLeftParen(leftParen);
			idList.add(exDate);
			// �����ϰ�� ������� ����
			
			String policyId = null;
			
			//Dev / QA / PROD ���̵� �� �ٸ�.
			if(request.getRequestURL().toString().contains("nmpisdev.lge.com")) policyId = "14";
			else policyId = "5";
			
			SearchScalarCondition secpolish = new SearchScalarCondition(META_SEC_POLICY_ID,
					SearchConstants.OPERATOR_ID__NUMBER_IS, policyId);
			secpolish.setRelationalOperator(SearchConstants.OPERATOR_OR);
			secpolish.setRightParen(rightParen);
			idList.add(secpolish);

			search.addConditions(idList);
			search.setPluginId(SearchConstants.DATABASE_SEARCH_PLUGIN_ID);
			SearchPagedResult result = AssetSearchServices.getInstance().runPagedAssetSearch(search, (long) 0, (long) 0, session);
			logger.info(result.getTotalHitCount());
			
			
			List<AssetIdentifier> assetIdList = result.getAssetIdList();
			for (AssetIdentifier assetIdentifier : assetIdList) {
				Asset asset = AssetServices.getInstance().retrieveAsset(assetIdentifier, dataRequest, session);
				MetadataElement metadataElement = asset.getMetadata().findElementById(META_EXPIRATION_DT);
				AssetExpiredListDto searchExpireAssetDto = new AssetExpiredListDto();
				String expireDate = ((MetadataField) metadataElement).getValue().getStringValue();
				
				Date day1 = dateformat.parse(today);
				Date day2 = dateformat.parse(expireDate);
				
				int compare = day1.compareTo(day2);
				if(compare > 0 )
				{
					searchExpireAssetDto.setStatus("expired");					
				}
				else  
				{
					searchExpireAssetDto.setStatus("dumy");
				}
				
				searchExpireAssetDto.setAssetExpireDate(((MetadataField) metadataElement).getValue().getStringValue());
				searchExpireAssetDto.setAssetId(asset.getAssetId().toString());
				resultList.add(searchExpireAssetDto);
			}
			AssetExpiredCollection searchExpireAssetCollection = new AssetExpiredCollection();
			searchExpireAssetCollection.setAssetList(resultList);
			
			// ��� �α� �ױ�
			StringBuffer query = new StringBuffer();
			query.append("INSERT INTO [otmm].[LGE_MPIS_PROCEDURE_LOG]");
			query.append("		([LOG_TARGET]");
			query.append("		,[LOG_TYPE]");
			query.append("		,[LOG_DATE]");
			query.append("		,[LOG_DESC])");
			query.append("VALUES (");
			query.append("		'NEWSROOM_EXPIRE'");
			query.append("		,'DONE'");
			query.append("		,getdate()");
			query.append("		,'Request ID :"+assetIds);
			query.append("')");

			try {
				Connection connection = null;
				PreparedStatement preparedStatement = null;
				
				try {
					DBMgr db = new DBMgr();
					connection = db.openDatabase();
	
					preparedStatement = connection.prepareStatement(query.toString());
					preparedStatement.executeUpdate();
	
				} finally {
					if (connection != null)
						connection.close();
					if (preparedStatement != null)
						preparedStatement.close();
				}
	
			} catch (WebApplicationException e) {
				throw e;
			} catch (Throwable t) {
				throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
			}

			return Response.ok(searchExpireAssetCollection).type(checkMediaType()).build();
		} catch (Exception e) {
			logger.error(e.getMessage());
			// ��� �α� �ױ�
			StringBuffer query = new StringBuffer();
			query.append("INSERT INTO [otmm].[LGE_MPIS_PROCEDURE_LOG]");
			query.append("		([LOG_TARGET]");
			query.append("		,[LOG_TYPE]");
			query.append("		,[LOG_DATE]");
			query.append("		,[LOG_DESC])");
			query.append("VALUES (");
			query.append("		'NEWSROOM_EXPIRE'");
			query.append("		,'FAIL'");
			query.append("		,getdate()");
			query.append("		,'Request ID :"+assetIds);
			query.append("')");

			try {
				Connection connection = null;
				PreparedStatement preparedStatement = null;
				
				try {
					DBMgr db = new DBMgr();
					connection = db.openDatabase();
	
					preparedStatement = connection.prepareStatement(query.toString());
					preparedStatement.executeUpdate();
	
				} finally {
					if (connection != null)
						connection.close();
					if (preparedStatement != null)
						preparedStatement.close();
				}
	
			} catch (WebApplicationException es) {
				throw es;
			} catch (Throwable t) {
				throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
			}
			return Response.status(500).type(checkMediaType()).build();
		}
	}
}
