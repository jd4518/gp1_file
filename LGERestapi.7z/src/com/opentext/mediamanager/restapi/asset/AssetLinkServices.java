package com.opentext.mediamanager.restapi.asset;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.Asset;
import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.services.AssetDataLoadRequest;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.MetadataFieldConstants;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.metadata.MetadataElement;
import com.artesia.metadata.MetadataField;
import com.artesia.search.Search;
import com.artesia.search.SearchCondition;
import com.artesia.search.SearchConstants;
import com.artesia.search.SearchPagedResult;
import com.artesia.search.SearchScalarCondition;
import com.artesia.search.SearchSortField;
import com.artesia.search.services.AssetSearchServices;
import com.artesia.security.SecuritySession;
import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.common.PageRequest;
import com.opentext.mediamanager.restapi.dto.AssetListDto;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.representation.AssetLinkCollection;


/*
* ---------------------------------------------------------------------------------------
* PROJ    :   New Marketing Product Information_LGE
* NAME    :   AssetLinkServices.java
* DESC    :   ������ ���� nmpis ��ȸ api
* Author  :   ��â��
* VER     :   v1.0
* Copyright 2019 LG CNS All right reserved
* ---------------------------------------------------------------------------------------
*                       ��             ��           ��          ��
* ---------------------------------------------------------------------------------------
*       DATE       AUTHOR                                  DESCRIPTION
*  ------------ -----------  ------------------------------------------------------------
*   2019.10.31    ��â��           ������ ���� nmpis ��ȸ api
* ---------------------------------------------------------------------------------------
*/
@Path(BaseResource.SUPPORTED_VERSIONS+"/assetLink")
public class AssetLinkServices extends BaseResource{
	/**
	 * �ܺλ���� ��ȸ
	 * @param word
	 * @param type
	 * @param before
	 * @param after 
	 * @return
	 * @throws BaseTeamsException
	 */
	
	public static final TeamsIdentifier META_EXPIRATION_DT = new TeamsIdentifier("ARTESIA.FIELD.EXPIRATION DATE");
	
	private static final Log logger = LogFactory.getLog(AssetLinkServices.class);
	@GET
	@Path("/list")
	public Response selectAssetList(@QueryParam("content1") String content1, @QueryParam("content2") String content2, @QueryParam("bu") String bu, @QueryParam("div") String division,
									@QueryParam("modelNm") String modelNm,@QueryParam("region") String region, @QueryParam("salesSub") String salesSub,@QueryParam("b2cb") String b2cb,
									@QueryParam("vertical") String vertical,@QueryParam("name") String name,@QueryParam("like") boolean like, @QueryParam("after") String after,
									@QueryParam("limit") String limit, @QueryParam("strDate") String strDate, @QueryParam("endDate") String endDate, @Context HttpServletRequest request) throws BaseTeamsException{ 
		
		if(limit != null)
		{
			if(Integer.parseInt(limit) > 200)
			{
				throw new OTMMRestException("200 MAX", "restapi.error.unknown.error");
			}
		}
		
		logger.info("strDate paramter : " + strDate);
		logger.info("endDate paramter : " + endDate);
			
		SecuritySession session = getOTMMSession(request);
		
		ArrayList<AssetListDto> resultList = new ArrayList<>();
		int totalCnt = 0;
		Search search = new Search();		
		List<SearchCondition> mcList = new ArrayList<SearchCondition>();
		//Ȯ���� ����
		SearchScalarCondition conExtension = null;
		//��������
		SearchScalarCondition conUnDeleted   = null;
		//�ֽŹ���
		SearchScalarCondition conLastVersion = null;		
		//content1 ����
		SearchScalarCondition conContent1 = null;
		//content2 ����
		SearchScalarCondition conContent2 = null;
		//Bu ����
		SearchScalarCondition conBu = null;
		//Div ����
		SearchScalarCondition conDiv = null;
		//ModelName ����
		SearchScalarCondition conModelNm = null;
		//Region ����
		SearchScalarCondition conRegion = null;
		//SalesSub ����
		SearchScalarCondition conSalesSub = null;
		//B2B/B2c ����
		SearchScalarCondition conB2cb = null;
		//Vertical ����
		SearchScalarCondition conVertical = null;
		//FileName ����
		SearchScalarCondition conFileName = null;

		SearchScalarCondition strDatToendDate = null;
		String paramBetween = strDate+" AND "+endDate;
		
		
		// �̸����Ⱑ �ִ� ���ϵ�.
		conExtension = new SearchScalarCondition(new TeamsIdentifier("ARTESIA.FIELD.CONTENT TYPE"), new TeamsIdentifier("ARTESIA.OPERATOR.CHAR.IS"), "BITMAP");
		conExtension.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		conUnDeleted = new SearchScalarCondition(MetadataFieldConstants.METADATA_FIELD_ID__CONTENT_STATUS, SearchConstants.OPERATOR_ID__CHAR_IS_NOT, "DELETED");
		conUnDeleted.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		conLastVersion = new SearchScalarCondition(MetadataFieldConstants.METADATA_FIELD_ID__IS_LATEST_VERSION, SearchConstants.OPERATOR_ID__CHAR_CONTAINS, "Y");
		conLastVersion.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		conContent1 = new SearchScalarCondition( new TeamsIdentifier("CONTENTTYPE1"), SearchConstants.OPERATOR_ID__CHAR_CONTAINS, content1);
		conContent1.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		conContent2 = new SearchScalarCondition( new TeamsIdentifier("CONTENTTYPE2"), SearchConstants.OPERATOR_ID__CHAR_CONTAINS, content2);
		conContent2.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		conBu = new SearchScalarCondition(new TeamsIdentifier("BU"), SearchConstants.OPERATOR_ID__CHAR_CONTAINS, bu);
		conBu.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		conDiv = new SearchScalarCondition(new TeamsIdentifier("Division"), SearchConstants.OPERATOR_ID__CHAR_CONTAINS, division);
		conDiv.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		conModelNm = new SearchScalarCondition(new TeamsIdentifier("ModelName"), SearchConstants.OPERATOR_ID__CHAR_CONTAINS, modelNm);
		conModelNm.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		conRegion = new SearchScalarCondition(new TeamsIdentifier("Region"), SearchConstants.OPERATOR_ID__CHAR_CONTAINS, region);
		conRegion.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		conSalesSub = new SearchScalarCondition(new TeamsIdentifier("Sales Subsidiary"), SearchConstants.OPERATOR_ID__CHAR_CONTAINS, salesSub);
		conSalesSub.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		conB2cb = new SearchScalarCondition(new TeamsIdentifier("B2CB2B"), SearchConstants.OPERATOR_ID__CHAR_CONTAINS, b2cb);
		conB2cb.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		conVertical = new SearchScalarCondition(new TeamsIdentifier("VERTICAL"), SearchConstants.OPERATOR_ID__CHAR_CONTAINS, vertical);
		conVertical.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		conFileName = new SearchScalarCondition(new TeamsIdentifier("ARTESIA.FIELD.ASSET NAME"), SearchConstants.OPERATOR_ID__CHAR_CONTAINS, name);	
		conFileName.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		strDatToendDate = new SearchScalarCondition(
				MetadataFieldConstants.METADATA_FIELD_ID__DATE_IMPORTED, SearchConstants.OPERATOR_ID__DATE_IS_BETWEEN, paramBetween);
		strDatToendDate.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
		SearchScalarCondition defaultDate = new SearchScalarCondition(MetadataFieldConstants.METADATA_FIELD_ID__DATE_IMPORTED,SearchConstants.OPERATOR_ID__DATE_IS_IN_LAST_30_DAYS, null);
		defaultDate.setRelationalOperator(SearchConstants.OPERATOR_AND);
		
	
		SearchSortField sortField = new SearchSortField(new TeamsIdentifier("ARTESIA.FIELD.DATE IMPORTED"),
	               SearchConstants.SORT_DESCENDING);
		mcList.add(conExtension);
		mcList.add(conUnDeleted);
		mcList.add(conLastVersion);
		
		if(strDate != null && endDate != null)
		{
			mcList.add(strDatToendDate);
		}
		else
		{
			mcList.add(defaultDate);
		}
		
		if(content1 != null)
		{
			mcList.add(conContent1);
		}
		if(content2 != null)
		{
			mcList.add(conContent2);
		}
		if(bu != null)
		{
			mcList.add(conBu);
		}
		if(division != null)
		{
			mcList.add(conDiv);
		}
		if(modelNm != null)
		{
			mcList.add(conModelNm);
		}
		if(region != null)
		{
			mcList.add(conRegion);
		}
		if(salesSub != null)
		{
			mcList.add(conSalesSub);
		}
		if(b2cb != null)
		{
			mcList.add(conB2cb);
		}
		if(vertical != null)
		{
			mcList.add(conVertical);
		}
		if(name != null)
		{
			mcList.add(conFileName);
		}
		
		search.addConditions(mcList);

		search.addSortField(sortField);
		
		search.setPluginId(SearchConstants.DATABASE_SEARCH_PLUGIN_ID);
		
		SearchPagedResult searchPagedResult = null;
		SearchPagedResult totalResult 		= null;
		PageRequest pageRequest = new PageRequest(after, null, limit);
		
		Long offset = new Long(pageRequest.getOffset());
	    Long pageSize = new Long(pageRequest.getLimit());
	    //String admId = "";
	    //String ADM_URL = "https://amd.nmpis.lge.com/adaptivemedia/rendition?id="+admId+"&clid=mpisamd";
		try 
		{
			totalResult = AssetSearchServices.getInstance().runPagedAssetSearch(search, (long) 0, (long) 0, session);
			searchPagedResult = AssetSearchServices.getInstance().runPagedAssetSearch(search, offset,pageSize, session);
			
			List<AssetIdentifier> assetIdList = searchPagedResult.getAssetIdList();
			AssetDataLoadRequest dataRequest = new AssetDataLoadRequest();
			dataRequest.setLoadAssetContentInfo(true);
			dataRequest.setLoadMetadataByModel(true);
			dataRequest.setLoadAssetContentWithText(true);
			dataRequest.setLoadMetadata(true);
			totalCnt = totalResult.getAssetIdList().size();
			
			for(AssetIdentifier assetId : assetIdList) 
			{				
				try 
				{					
					AssetListDto assetDto = new AssetListDto();
					Asset asset = AssetServices.getInstance().retrieveAsset(assetId, dataRequest, session);
					MetadataElement metadataElement = asset.getMetadata().findElementById(META_EXPIRATION_DT);
					String expireDate = ((MetadataField) metadataElement).getValue().getStringValue();
					assetDto.setAssetId(asset.getAssetId().toString());
					assetDto.setAssetName(asset.getName());
					assetDto.setAssetSize(asset.getContentSize());
					assetDto.setMineType(asset.getMimeType());
					assetDto.setAssetCreatorId(asset.getImportUserName());
					assetDto.setAssetImportDt(asset.getDateImported().toString());
					assetDto.setAssetExpireDt(expireDate);
					
					
					String serviceURL = request.getScheme()+"://"+request.getServerName()+"/otmmapi/v4";
					String downloadURL = serviceURL + "/assetDownload/"+asset.getMasterContentInfo().getId().toString() +  "/?disposition=attachment";
					String thumbnailUrl = serviceURL + "/renditions/"+asset.getThumbnailContentId().toString();
					assetDto.setAssetUrl(downloadURL);
					assetDto.setThumbnailUrl(thumbnailUrl);
					resultList.add(assetDto);
				} 
				catch (BaseTeamsException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}			
		} 
		catch (BaseTeamsException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (WebApplicationException e) 
		{
			throw e;
		} 
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}
		AssetLinkCollection assetList = new AssetLinkCollection();
		assetList.setAssetList(resultList);
		assetList.setTotal(totalCnt);
		return Response.ok(assetList, MediaType.APPLICATION_JSON_TYPE).build();		
	}
}
