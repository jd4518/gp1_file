package com.opentext.mediamanager.restapi.asset;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import com.opentext.mediamanager.restapi.assets.models.AssetsManager;
import com.opentext.mediamanager.restapi.assets.representations.BulkAssetResultRepresentation;
import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.params.AssetStateOptionsParam;
import com.opentext.mediamanager.restapi.params.SelectionContextParam;
import com.opentext.mediamanager.restapi.util.ParamValidationUtils;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponses;

import utils.Utils;

@Path(BaseResource.SUPPORTED_VERSIONS+"/assetCusState")
public class AssetStateServices extends BaseResource
{
	  @Path("/cusState")
	  @PUT
	  @Consumes({"application/x-www-form-urlencoded"})
	  @ApiOperation(value="Lock or unlock or check-out or cancel check-out or delete or un-delete of an asset", notes="Lock or unlock or check-out or cancel check-out or delete or un-delete of an asset<p>While using selection context to filter the assets based on permissions, pass permissions_filter paramater in selection context. The valid permission filters are {ASSETVIEW_PERM,SUMMARYVIEW_PERM,PREVIEWVIEW_PERM,EXPORT_PERM,SUBSCRIBE_PERM,COMMENTS_PERM,METAEDIT_PERM,CONTENTEDIT_PERM,MEMBERSHIPEDIT_PERM, DELETEASSET_PERM,EDITPARENTS_PERM,CUSTOM01_PERM,CUSTOM02_PERM,CUSTOM03_PERM,CUSTOM04_PERM}", response=BulkAssetResultRepresentation.class, position=30)
	  @ApiResponses({@com.wordnik.swagger.annotations.ApiResponse(code=200, message="The request has been completed successfully"), @com.wordnik.swagger.annotations.ApiResponse(code=400, message="A required parameter is not specified or has null or invalid value"), @com.wordnik.swagger.annotations.ApiResponse(code=401, message="Unauthorized access to the resource"), @com.wordnik.swagger.annotations.ApiResponse(code=500, message="An internal server error occurred, refer to the response for more information")})
	  public Response updateAssetsState(@ApiParam(value="The selection context for the assets. ", required=true) @FormParam("selection_context") SelectionContextParam selectionContext, @ApiParam(value="Folder/Assets options are not applicable for all the operations", required=false) @FormParam("asset_state_options") AssetStateOptionsParam assetStateOptionsParam, @ApiParam(value="Asset 'state change' action; allowed values are check_out, cancel_check_out, lock, unlock, delete, un_delete", allowableValues="check_out, cancel_check_out, lock, unlock, delete, un_delete", required=true) @FormParam("action") String action, @Context HttpServletRequest request)
	  {
	    String validatedAction = ParamValidationUtils.validatedCaseInsensitiveStringParameter("action", action, AssetsManager.VALID_ASSET_STATE_TRANSITION_ACTIONS);
	    
	    ParamValidationUtils.assertParameterNotNull("selection_context", selectionContext);
	    if (selectionContext.getSelectionContext() == null) {
	      throw new OTMMRestException(Response.Status.BAD_REQUEST, "The selection context passed in request is either null or invalid", "restapi.error.invalid-selection-context");
	    }
	    if (assetStateOptionsParam != null)
	    {
	      BulkAssetResultRepresentation bulkAssetResultRepresentation = new AssetsManager().changeAssetsState(selectionContext.getSelectionContext(), assetStateOptionsParam.getAssetStateOptions(), validatedAction, Utils.getLocalSession2());
	      
	      return Response.ok(bulkAssetResultRepresentation).type(checkMediaType()).build();
	    }
	    BulkAssetResultRepresentation bulkAssetResultRepresentation = new AssetsManager().changeAssetsState(selectionContext.getSelectionContext(), null, validatedAction, Utils.getLocalSession2());
	    
	    return Response.ok(bulkAssetResultRepresentation).type(checkMediaType()).build();
	  }
	  
	  
	  @Path("/{id}/cusState")
	  @PUT
	  @Consumes({"application/x-www-form-urlencoded"})
	  @ApiOperation(value="Lock or unlock or check-out or cancel check-out or delete or un-delete of an asset", notes="Lock or unlock or check-out or cancel check-out or delete or un-delete of an asset", response=BulkAssetResultRepresentation.class, position=75)
	  @ApiResponses({@com.wordnik.swagger.annotations.ApiResponse(code=200, message="The request has been completed successfully"), @com.wordnik.swagger.annotations.ApiResponse(code=400, message="A required parameter is not specified or has null or invalid value"), @com.wordnik.swagger.annotations.ApiResponse(code=401, message="Unauthorized access to the resource"), @com.wordnik.swagger.annotations.ApiResponse(code=500, message="An internal server error occurred, refer to the response for more information")})
	  public Response updateAssetState(@PathParam("id") String assetId, @ApiParam(value="Asset 'state change' action; allowed values are check_out, cancel_check_out, lock, unlock, delete, un_delete", allowableValues="check_out, cancel_check_out, lock, unlock, delete, un_delete", required=true) @FormParam("action") String action, @ApiParam(value="Folder/Assets options are not applicable for all the operations", required=false) @FormParam("asset_state_options") AssetStateOptionsParam assetStateOptionsParam, @Context HttpServletRequest request)
	  {
	    String validatedAction = ParamValidationUtils.validatedCaseInsensitiveStringParameter("action", action, AssetsManager.VALID_ASSET_STATE_TRANSITION_ACTIONS);
	    
	    BulkAssetResultRepresentation bulkAssetResultRepresentation = new AssetsManager().changeAssetState(assetId, validatedAction, assetStateOptionsParam != null ? assetStateOptionsParam.getAssetStateOptions() : null, Utils.getLocalSession2());
	    
	    return Response.ok(bulkAssetResultRepresentation).type(checkMediaType()).build();
	  }
}
