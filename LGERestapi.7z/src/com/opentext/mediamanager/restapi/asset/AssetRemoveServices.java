package com.opentext.mediamanager.restapi.asset;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.Asset;
import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.services.AssetDataLoadRequest;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.reviewjob.services.ReviewJobServices;
import com.artesia.security.SecuritySession;
import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.extensions.PATCH;
import com.opentext.mediamanager.restapi.reviewjobs.representations.ReviewJobResultRepresentation;
import com.opentext.mediamanager.restapi.util.ParamValidationUtils;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiResponses;

import utils.Utils;

/*
* ---------------------------------------------------------------------------------------
* PROJ    :   New Marketing Product Information_LGE
* NAME    :   AssetRemoveServices.java
* DESC    :   reviewToJob -> remove Asset �̺�Ʈ
* Author  :   ��â��
* VER     :   v1.0
* Copyright 2019 LG CNS All right reserved
* ---------------------------------------------------------------------------------------
*                       ��             ��           ��          ��
* ---------------------------------------------------------------------------------------
*       DATE       AUTHOR                                  DESCRIPTION
*  ------------ -----------  ------------------------------------------------------------
*   2019.09.18    ��â��           reviewjob���� asset ���� ���� ��ü
* ---------------------------------------------------------------------------------------
*/
@Path(BaseResource.SUPPORTED_VERSIONS+"/removeAssets")
public class AssetRemoveServices extends BaseResource{
	
	private static final Log logger = LogFactory.getLog(AssetRemoveServices.class);
	 
	@PATCH
	@Path("/reviewjobToAssets")
	@Consumes({"application/x-www-form-urlencoded"})
	@Produces({"application/json"})
	@ApiOperation(position=300, value="remove Assets from a Review Job", notes="remove Assets from a Review Job. Only a participant with the Job Manager role can perform this action.<p>The add operation requires the asset Selection Context selection_context parameter as input.<p>The remove operation supports a selection_context or the asset_ids list.Both asset representations are not supported in a single remove operation.<p><b>Note:</b></br>1. The Swagger model schema shows the schema for a complex type without the type name. Therefore you must set the type name in the JSON representation enclosing the model schema representation when passing complex type as a parameter.</br>2. You should specify a 'type' discriminator for sub-types with the fully qualified name of the sub-types. Refer to the model representation for the fully qualified names of the sub-types.", response=ReviewJobResultRepresentation.class)
	@ApiResponses({@com.wordnik.swagger.annotations.ApiResponse(code=200, message="The request has been completed successfully"), @com.wordnik.swagger.annotations.ApiResponse(code=400, message="A required parameter is not specified or has null or invalid value"), @com.wordnik.swagger.annotations.ApiResponse(code=401, message="Unauthorized access to the resource"), @com.wordnik.swagger.annotations.ApiResponse(code=500, message="An internal server error occurred, refer to the response for more information")})
	public Response removeAssetsFromRvjob(@FormParam("reviewjobId") String reviewJobId, @FormParam("commaSeparatedAssetIds") String commaSeparatedAssetIds, @Context HttpServletRequest request) throws BaseTeamsException{
		
		logger.info("Remove API Call [reviewjobToAssets] START & reviewjobId : " + reviewJobId);
		
 		SecuritySession session = Utils.getLocalSession2();
		AssetDataLoadRequest dataRequest = new AssetDataLoadRequest();
		dataRequest.setLoadMetadata(true);
		
		List<String> assetIds = null;
		if (commaSeparatedAssetIds != null) {
			assetIds = ParamValidationUtils.splitCommaSeperatedParameter(commaSeparatedAssetIds);
		}
				
		try
		{
			List<AssetIdentifier> assetList = new ArrayList<AssetIdentifier>();
			if (assetIds != null) 
			{
				for (String assetId : assetIds) 
				{
					Asset asset = AssetServices.getInstance().retrieveAsset(new AssetIdentifier(assetId), dataRequest, session);
					assetList.add(new AssetIdentifier(asset.getOriginalAssetId().toString()));
					logger.info("asset id : " + assetId);
					logger.info("asset.getOriginalAssetId : " + asset.getOriginalAssetId().toString());
				}
			}
			ReviewJobServices.getInstance().removeAssetsFromReviewJob(new TeamsIdentifier(reviewJobId), assetList, session);
		}
		catch (Exception e) 
		{
			logger.info("removeAssetsFromReviewJob ErrorMsg : " + e.getMessage());
			e.printStackTrace();			
		}
		catch (Throwable t) 
		{
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}
		
		logger.info("Remove API Call [reviewjobToAssets] END");
		return Response.status(Response.Status.OK).build();
	}
}
