package com.opentext.mediamanager.restapi.asset;

import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.content.services.AssetContentServices;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.common.exception.InvalidSecuritySessionException;
import com.artesia.content.ContentData;
import com.artesia.content.ContentDataRequest;
import com.artesia.content.ContentInfo;
import com.artesia.content.ContentInfoUtil;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.security.SecuritySession;
import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.common.ContentConstants;
import com.opentext.mediamanager.restapi.common.ResponseBuilderUtils;
import com.opentext.mediamanager.restapi.exceptions.OTMMRestException;
import com.opentext.mediamanager.restapi.util.ParamValidationUtils;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponses;


/*
* ---------------------------------------------------------------------------------------
* PROJ    :   New Marketing Product Information_LGE
* NAME    :   AssetDownloadServices.java
* DESC    :   ������ ���� �� �ٿ�ε� api ����
* Author  :   ��â��
* VER     :   v1.0
* Copyright 2019 LG CNS All right reserved
* ---------------------------------------------------------------------------------------
*                       ��             ��           ��          ��
* ---------------------------------------------------------------------------------------
*       DATE       AUTHOR                                  DESCRIPTION
*  ------------ -----------  ------------------------------------------------------------
*   2019.10.31    ��â��           ������ ���� �� �ٿ�ε� api ����
* ---------------------------------------------------------------------------------------
*/

@Path(BaseResource.SUPPORTED_VERSIONS+"/assetDownload")
public class AssetDownloadServices extends BaseResource{
	
	private static final Log log = LogFactory.getLog(AssetDownloadServices.class);
	
	@Path("/{id}")
	@GET
	@ApiOperation(value="Retrieve a Rendition", notes="Retrieve a Rendition associated with an Asset or Folder by rendition id.", response=InputStream.class, position=2)
	@ApiResponses({@com.wordnik.swagger.annotations.ApiResponse(code=200, message="The request has been completed successfully"), @com.wordnik.swagger.annotations.ApiResponse(code=400, message="A required parameter is not specified or has null or invalid value"), @com.wordnik.swagger.annotations.ApiResponse(code=401, message="Unauthorized access to the resource"), @com.wordnik.swagger.annotations.ApiResponse(code=404, message="Rendition not found with the specified id"), @com.wordnik.swagger.annotations.ApiResponse(code=500, message="An internal server error occurred, refer to the response for more information")})
	public Response getRendition(@ApiParam(value="Rendition Id", required=true) @PathParam("id") String id, @ApiParam(value="The disposition type", allowableValues="attachment", required=false) @QueryParam("disposition") String dispositionParam, @ApiParam(value="Is caching enabled for this request", allowableValues="true,false", defaultValue="true", required=false) @QueryParam("enable_caching") String enableCachingParam, @ApiParam(value="User-Agent HTTP header", required=false) @HeaderParam("user-agent") String userAgentParam, @Context HttpServletRequest httpServletRequest)
	{
		ContentInfo contentInfo = null;    
		String disposition = ParamValidationUtils.validatedCaseInsensitiveStringParameter("disposition", dispositionParam, ContentConstants.VALID_DISPOSITION_TYPES);
		boolean cacheFlag = ParamValidationUtils.convertBooleanStringParameter("enable_caching", enableCachingParam, Boolean.valueOf(true));
		try
		{
			contentInfo = retrieveRendition(id, disposition, getOTMMSession(httpServletRequest));
		}
		catch (WebApplicationException e)
		{
			throw e;
		}
		catch (Throwable t)
		{
			log.error("retrieval of rendition failed", t);
			throw new OTMMRestException(t.getMessage(), "restapi.error.unknown.error");
		}
		return ResponseBuilderUtils.createResponseWithHeaders(contentInfo, disposition, cacheFlag, userAgentParam);
	}
	
	public ContentInfo retrieveRendition(String id, String disposition, SecuritySession securitySession) throws OTMMRestException
	{
		ContentInfo contentInfo = null;
		    
		TeamsIdentifier objectId = new TeamsIdentifier(id);
		try
		{
			ContentDataRequest contentDataRequest = new ContentDataRequest();
			contentDataRequest.setRetrievalMethod(disposition);
			contentDataRequest.setLoadStorageAttributes(true);
		      
			contentInfo = AssetContentServices.getInstance().retrieveContent(objectId, ContentData.ContentDataSource.INPUTSTREAM, contentDataRequest, null, securitySession);
			if (contentInfo == null) {
				throw new OTMMRestException(Response.Status.NOT_FOUND, "Rendition not found with the id " + id, "restapi.error.rendition.rendition-id-not-found");
			}
			ContentInfoUtil.validateFilenameAndMimeType(contentInfo.getName(), contentInfo.getMimeType());
		    //OTMM Setting ������ üũ - MAX SIZE DOWNLOAD  
			//ContentInfoUtil.validateContentDownloadable(contentInfo);
		      
			log.debug("Retrieved renditon for:" + id);
		}
	    catch (InvalidSecuritySessionException se)
	    {
	      throw new OTMMRestException(Response.Status.UNAUTHORIZED, se);
	    }
	    catch (BaseTeamsException bte)
	    {
	    	if (bte.getMessageId().equals("message.error.content.invalid.content.info")) {
	    		throw new OTMMRestException(Response.Status.NOT_FOUND, "Rendition not found with the id " + id, "restapi.error.rendition.rendition-id-not-found");
	    	}
	    	throw new OTMMRestException(bte);
	    }
	    return contentInfo;
	}
}
