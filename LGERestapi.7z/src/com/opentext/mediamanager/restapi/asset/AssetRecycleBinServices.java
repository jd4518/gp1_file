package com.opentext.mediamanager.restapi.asset;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.Asset;
import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.services.AssetDataLoadRequest;
import com.artesia.asset.services.AssetServices;
import com.artesia.asset.services.RetrieveAssetsCriteria;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.search.Search;
import com.artesia.search.SearchCondition;
import com.artesia.search.SearchConstants;
import com.artesia.search.SearchPagedResult;
import com.artesia.search.SearchScalarCondition;
import com.artesia.search.SearchSortField;
import com.artesia.search.services.AssetSearchServices;
import com.artesia.security.SecuritySession;
import com.opentext.mediamanager.restapi.common.BaseResource;
import com.opentext.mediamanager.restapi.dto.AssetRecycleBinDto;
import com.opentext.mediamanager.restapi.representation.AssetRecycleBinCollection;
import com.wordnik.swagger.annotations.ApiParam;

import utils.Utils;

/*
* ---------------------------------------------------------------------------------------
* PROJ    :   New Marketing Product Information_LGE
* NAME    :   AssetRecycleBinServices.java
* DESC    :   �ӽû����� Asset ����Ʈ ��ȸ
* Author  :   ��â��
* VER     :   v1.0
* Copyright 2019 LG CNS All right reserved
* ---------------------------------------------------------------------------------------
*                       ��             ��           ��          ��
* ---------------------------------------------------------------------------------------
*       DATE       AUTHOR                                  DESCRIPTION
*  ------------ -----------  ------------------------------------------------------------
*   2019.07.23    ��â��            �ӽû����� Asset ����Ʈ ��ȸ
*   2019.07.24    ��â��            �ӻ������ Asset ���ű�� / Response �޽��� Collection �߰�
* ---------------------------------------------------------------------------------------
*/

@Path(BaseResource.SUPPORTED_VERSIONS + "/assetRecycleBine")
public class AssetRecycleBinServices extends BaseResource {
	public static final Log logger = LogFactory.getLog(AssetRecycleBinServices.class);
	public static final TeamsIdentifier CONTENT_STATUS = new TeamsIdentifier("ARTESIA.FIELD.CONTENT STATUS");
	public static final TeamsIdentifier UOI_NAME = new TeamsIdentifier("ARTESIA.FIELD.ASSET NAME");
	public static final TeamsIdentifier DELETION_STATE_DT = new TeamsIdentifier(
			"ARTESIA.FIELD.DATE ASSET LAST DELETED OR UN-DELETED");
	public static final TeamsIdentifier CONTENT_TYPE = new TeamsIdentifier("ARTESIA.FIELD.CONTENT TYPE");
	public static final TeamsIdentifier DELETION_STATE_USER_NAME = new TeamsIdentifier(
			"ARTESIA.FIELD.ASSET LAST DELETED OR UN-DELETED BY");

	@Path("/deletedAsset")
	@GET
	@Produces({ "application/json" })
	public Response deletedAssetList(@ApiParam(defaultValue = "1") @QueryParam("before") long before,
			@ApiParam(defaultValue = "25") @QueryParam("after") long after,
			@ApiParam(defaultValue = "desc") @QueryParam("sortprefix") String sortprefix,
			@QueryParam("sortfield") String sortfield, @Context HttpServletRequest request) throws BaseTeamsException {
		SecuritySession clientSession = getOTMMSession(request);
		if (!(clientSession.getRoleName().equals("Administrator")
				|| clientSession.getRoleName().equals("MPIS Admin"))) {
			// return Response.status(401).build();
			return Response.status(401).entity(Utils.bodyMessage(401, "You do not have access to this list."))
					.type(MediaType.APPLICATION_JSON_TYPE).build();
		}
		SecuritySession session = Utils.getLocalSession2();
		Search search = new Search();
		List<SearchCondition> mcList = new ArrayList<SearchCondition>();

		SearchSortField searchSortField = new SearchSortField();
		try {
			searchSortField.setMetadataFieldId((TeamsIdentifier) AssetRecycleBinServices.class
					.getField(sortfield.toUpperCase()).get(new TeamsIdentifier()));
		} catch (Exception e) {
			searchSortField.setMetadataFieldId(DELETION_STATE_DT);
		}
		searchSortField.setSortOrder(sortprefix.toLowerCase());
		search.addSortField(searchSortField);

		SearchScalarCondition search1 = new SearchScalarCondition(CONTENT_STATUS, SearchConstants.OPERATOR_ID__CHAR_IS,
				"DELETED");
		search1.setRelationalOperator(SearchConstants.OPERATOR_AND);

		SearchScalarCondition search2 = new SearchScalarCondition(DELETION_STATE_USER_NAME,
				SearchConstants.OPERATOR_ID__CHAR_IS_NOT, "1001");
		search2.setRelationalOperator(SearchConstants.OPERATOR_AND);

		mcList.add(search1);
		mcList.add(search2);

		search.addConditions(mcList);
		SearchPagedResult searchPagedResult = AssetSearchServices.getInstance().runPagedAssetSearch(search, before,
				after, session);

		List<AssetIdentifier> assetIdList = searchPagedResult.getAssetIdList();
		AssetIdentifier[] assetIds = assetIdList.toArray(new AssetIdentifier[0]);

		RetrieveAssetsCriteria criteria = new RetrieveAssetsCriteria(assetIds);
		AssetDataLoadRequest dataLoadRequest = new AssetDataLoadRequest();
		dataLoadRequest.setLoadMetadata(true);
		dataLoadRequest.setLoadSecurityPolicies(true);

		Asset[] assets = AssetServices.getInstance().retrieveAssets(criteria, dataLoadRequest, session);
		AssetRecycleBinCollection assetRecycleBinCollection = new AssetRecycleBinCollection();
		assetRecycleBinCollection.setTotalCount(searchPagedResult.getTotalHitCount());

		List<AssetRecycleBinDto> assetRecycleBinDtos = new ArrayList<AssetRecycleBinDto>();
		for (Asset asset : assets) {
			AssetRecycleBinDto assetRecycleBinDto = new AssetRecycleBinDto();
			assetRecycleBinDto.setUoi_name(asset.getName());
			assetRecycleBinDto.setUoi_id(asset.getAssetId().asString());
			assetRecycleBinDto.setContent_type(asset.getContentType());
			assetRecycleBinDto.setDeletion_state_dt(asset.getDeletionStateLastUpdateDate().toString());
			assetRecycleBinDto.setDeletion_state_user_name(asset.getDeletionStateUserName());
			assetRecycleBinDto.setThumnail_id(asset.getThumbnailContentId());
			assetRecycleBinDto.setMetadata_model_id(asset.getMetadataModelId().toString());
			assetRecycleBinDtos.add(assetRecycleBinDto);
		}
		assetRecycleBinCollection.setAssetList(assetRecycleBinDtos);

		return Response.ok(assetRecycleBinCollection, MediaType.APPLICATION_JSON_TYPE).build();
	}

	@Path("/purgeAsset")
	@POST
	@Consumes({ "application/x-www-form-urlencoded" })
	@Produces(MediaType.TEXT_HTML)
	public Response purgeAssetList(@FormParam("uoi_ids") String uoi_ids, @Context HttpServletRequest request) {

		SecuritySession clientSession = getOTMMSession(request);
		if (!(clientSession.getRoleName().equals("Administrator")
				|| clientSession.getRoleName().equals("MPIS Admin"))) {
			// return Response.status(401).build();
			return Response.status(401).entity(Utils.bodyMessage(401, "No permissions to purge.")).type(MediaType.APPLICATION_JSON_TYPE).build();
		}
		SecuritySession session = Utils.getLocalSession2();
		String[] ids = uoi_ids.split(",");
		List<AssetIdentifier> assetIdList = new ArrayList<>();
		for (String uoi_id : ids) {
			assetIdList.add(new AssetIdentifier(uoi_id));
		}
		try {
			AssetServices.getInstance().purgeAssets(assetIdList, session);
		} catch (BaseTeamsException e) {
			logger.info("purgeAsset Error : " + e.getMessage());
		}
		return Response.ok(Utils.bodyMessage(Response.Status.OK.getStatusCode(), "Asset(s) have been successfully Purged."), MediaType.APPLICATION_JSON_TYPE).build();
	}
}
