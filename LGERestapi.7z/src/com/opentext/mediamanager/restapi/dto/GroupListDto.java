package com.opentext.mediamanager.restapi.dto;


/**
 * 메일그룹 DTO
 * @author chungkyu1.lee
 *
 */
public class GroupListDto {
	private String groupId;
	private String groupNm;
	private String regId;
	private String regDt;
	
	
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getGroupNm() {
		return groupNm;
	}
	public void setGroupNm(String groupNm) {
		this.groupNm = groupNm;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	
	
	
	
	
}
