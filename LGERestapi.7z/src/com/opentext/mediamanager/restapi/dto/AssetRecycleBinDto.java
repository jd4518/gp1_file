package com.opentext.mediamanager.restapi.dto;

public class AssetRecycleBinDto {
	
	private String uoi_id;
	
	private String uoi_name;
	
	private String content_type;
	
	private String deletion_state_dt;
	
	private String deletion_state_user_name; 
	
	private String thumnail_id;
	
	private String metadata_model_id;
	
	public String getMetadata_model_id() {
		return metadata_model_id;
	}

	public void setMetadata_model_id(String metadata_model_id) {
		this.metadata_model_id = metadata_model_id;
	}

	public String getThumnail_id() {
		return thumnail_id;
	}

	public void setThumnail_id(String thumnail_id) {
		this.thumnail_id = thumnail_id;
	}

	public String getUoi_id() {
		return uoi_id;
	}
	
	public void setUoi_id(String uoi_id) {
		this.uoi_id = uoi_id;
	}
	
	public String getUoi_name() {
		return uoi_name;
	}
	
	public void setUoi_name(String uoi_name) {
		this.uoi_name = uoi_name;
	}
	
	public String getContent_type() {
		return content_type;
	}
	
	public void setContent_type(String content_type) {
		this.content_type = content_type;
	}
	
	public String getDeletion_state_dt() {
		return deletion_state_dt;
	}
	
	public void setDeletion_state_dt(String deletion_state_dt) {
		this.deletion_state_dt = deletion_state_dt;
	}
	
	public String getDeletion_state_user_name() {
		return deletion_state_user_name;
	}
	
	public void setDeletion_state_user_name(String deletion_state_user_name) {
		this.deletion_state_user_name = deletion_state_user_name;
	}
}
