package com.opentext.mediamanager.restapi.dto;

public class AssetExpiredListDto {
	
	private String assetId;
	
	private String assetExpireDate;
	
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getAssetExpireDate() {
		return assetExpireDate;
	}

	public void setAssetExpireDate(String assetExpireDate) {
		this.assetExpireDate = assetExpireDate;
	}
	
}
