package com.opentext.mediamanager.restapi.dto;

public class JobFolderNameDto {
	private String folderName;

	public String getFolderName() {
		return folderName;
	}

	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}

}
