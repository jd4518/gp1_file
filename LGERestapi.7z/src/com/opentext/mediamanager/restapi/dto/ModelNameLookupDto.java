package com.opentext.mediamanager.restapi.dto;

public class ModelNameLookupDto {
	private String model_name;

	public String getModel_name() {
		return model_name;
	}

	public void setModel_name(String model_name) {
		this.model_name = model_name;
	}

}
