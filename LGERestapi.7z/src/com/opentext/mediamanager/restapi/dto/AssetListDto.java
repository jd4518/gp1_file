package com.opentext.mediamanager.restapi.dto;

public class AssetListDto {
	
	private String assetId;
	
	private String mineType;
	
	private String assetUrl;
	
	private String assetName;
	
	private String assetCreatorId; 
	
	private Long assetSize;
	
	private String thumbnailUrl;
	
	private String assetImportDt;
	
	private String assetExpireDt;

	public String getThumbnailUrl() {
		return thumbnailUrl;
	}

	public void setThumbnailUrl(String thumbnailUrl) { 
		this.thumbnailUrl = thumbnailUrl;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getMineType() {
		return mineType;
	}

	public void setMineType(String mineType) {
		this.mineType = mineType;
	}

	public String getAssetUrl() {
		return assetUrl;
	}

	public void setAssetUrl(String assetUrl) {
		this.assetUrl = assetUrl;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetCreatorId() {
		return assetCreatorId;
	}

	public void setAssetCreatorId(String assetCreatorId) {
		this.assetCreatorId = assetCreatorId;
	}

	public Long getAssetSize() {
		return assetSize;
	}

	public void setAssetSize(Long assetSize) {
		this.assetSize = assetSize;
	}

	public String getAssetImportDt() {
		return assetImportDt;
	}

	public void setAssetImportDt(String assetImportDt) {
		this.assetImportDt = assetImportDt;
	}

	public String getAssetExpireDt() {
		return assetExpireDt;
	}

	public void setAssetExpireDt(String assetExpireDt) {
		this.assetExpireDt = assetExpireDt;
	}
	
	
	
	
}
