package utils;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.metadata.services.AssetMetadataServices;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.common.prefs.PrefData;
import com.artesia.common.prefs.PrefDataId;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.metadata.MetadataCollection;
import com.artesia.metadata.MetadataField;
import com.artesia.metadata.MetadataTableField;
import com.artesia.metadata.MetadataValue;
import com.artesia.security.SecuritySession;
import com.artesia.security.UserCriteria;
import com.artesia.security.session.services.AuthenticationServices;
import com.artesia.security.session.services.LocalAuthenticationServices;
import com.artesia.system.services.SystemServices;
import com.artesia.user.TeamsUser;
import com.artesia.user.services.UserServices;
import com.opentext.mediamanager.restapi.dto.MessageBodyDto;
import com.opentext.mediamanager.restapi.representation.MessageBodyCollection;

/**
 * 占쏙옙틸占쏙옙티
 * @author chungkyu1.lee
 *
 */
public class Utils {
	
	private static final Log log = LogFactory.getLog(Utils.class);
	
	//占싸깍옙占쏙옙
	public static SecuritySession getSecuritySession(String userName, String password) {
		String key = "TEAMS_HOME";
	    System.setProperty(key, "C:\\DEV2\\OTMM1632Dev");
		
		SecuritySession login = null;   
		try 
		{
			login = AuthenticationServices.getInstance().login(userName, password);
		} 
		catch (Exception e) 
		{
			System.out.println("Could not get session for1212 the user");
			e.printStackTrace();
			return null;
		}
		return login;
	}
	
	//占싸그아울옙
	public static void logout(SecuritySession securitySession){
		try 
		{
			AuthenticationServices.getInstance().logout(securitySession);
		} 
		catch (BaseTeamsException e) 
		{
			e.printStackTrace();
		}
	}
	
	//占쏙옙占쏙옙占쏙옙 占시쏙옙占쏙옙占쏙옙占쏙옙 占쏙옙占� (Setting)
	public static String getSystemSetting(String componentName, String keyName, String settingName, SecuritySession session){
		
		PrefDataId dataId = new PrefDataId(componentName, keyName, settingName);
		PrefData retrievedData = null;
		try 
		{
			retrievedData = SystemServices.getInstance().retrieveSystemSettingsByPrefDataId(dataId, session);
		} 
		catch (BaseTeamsException e) 
		{
			log.warn("An exception occured while fetching the system settings" );
		}
		
		return retrievedData == null ? "" : retrievedData.getValue();
	}
	
	public static TeamsUser getUserInfo(SecuritySession session, String userNm){
		TeamsUser[] userInfo = null;
		UserCriteria userCriteria = new UserCriteria();		
		userCriteria.setLoginName(userNm);	
		
		try 
		{
			userInfo = UserServices.getInstance().retrieveUsers(userCriteria, session);
		} 
		catch (BaseTeamsException e) 
		{
			e.printStackTrace();
		}	
		return userInfo[0];
	}
	
	public static String getOtdsHostName() {
		InetAddress ip;		
		String address = null;		
		try {
			ip = InetAddress.getLocalHost();
			address = "http://"+ip.getHostName()+":18080";			
		}catch(UnknownHostException e) {
			e.printStackTrace();
		}
		
		return address;
	}
	
	public static int getResultSetSize(ResultSet resultSet) {
	    int size = -1;
	    
	    try {
	        resultSet.last(); 
	        size = resultSet.getRow();
	        resultSet.beforeFirst();
	    } catch(SQLException e) {
	        return size;
	    }

	    return size;
	}
	
	public static boolean setTabularFields(AssetIdentifier assetId, TeamsIdentifier field, Set<String> ids, boolean flag, SecuritySession session) {
		System.out.println("============ setTabularFields =============== " + assetId +"================== field" + field);
		TeamsIdentifier[] fieldIds = new TeamsIdentifier[] { field };
		MetadataCollection[] metaCols;
		try {
			metaCols = AssetMetadataServices.getInstance().retrieveMetadataForAssets(assetId.asAssetIdArray(), fieldIds, null, session);
			MetadataCollection assetMetadata = metaCols[0];
			MetadataTableField valueField = (MetadataTableField) assetMetadata.findElementById(field);
			Set<String> preData = new HashSet<>();
			
			int rows = valueField.getRowCount();
			
			for(int i=0;i<rows;i++) {
				preData.add(valueField.getValueAt(i).getStringValue());
			}
	
			valueField.clearValues();
			
			valueField.setSavedValuesBehaviorMode(MetadataTableField.REPLACE_VALUES);
			
			
			
			if(preData.size() != 0) {
				for(String pre : preData) {
					valueField.addValue(new MetadataValue(pre));
				}				
			}
			for(String id : ids) 
		    {
		    	valueField.addValue(new MetadataValue(id));
		    }
    
		    AssetServices.getInstance().lockAssets(assetId.asAssetIdArray(), session);	    
		    try
		    {
		    	AssetMetadataServices.getInstance().saveMetadataForAssets(assetId.asAssetIdArray(), new MetadataField[]
		        { valueField }, session);
		    }
		    finally
		    {
		       AssetServices.getInstance().unlockAssets(assetId.asAssetIdArray(), session);
		    }
		    
		}catch (BaseTeamsException e) {
			return false;
		}			      
		return true;
	}
	
	//검색어 체크
	public static boolean blackListCheck(String value)
	{
		boolean result = false;
		if(value != null)
		{
			String word = value.toUpperCase().trim();
			String list[] = {"<", ">", "\"", "'", "%", ";", "(", ")", "&", "+", "SELECT", "AND ", "OR ", "UNION", "DECLARE", "CAST ",
	                		 "TO_CHAR", "HAVING", "GROUP BY", "FROM", "WHERE", "XP_CMDSHELL", "UPDATE", "INTO ", "INSERT"};
			
			for(String val : list)
			{
				if (word.indexOf(val) != -1) {
					result = true;
			    }
			}
		}
		return result;
	}
	
	public static SecuritySession getLocalSession2()
	{
	    SecuritySession securitySession = null;
	    try
	    {
	      securitySession = LocalAuthenticationServices.getInstance().createLocalSession("tsuper");
	    }
	    catch (BaseTeamsException localBaseTeamsException) {
	    	log.warn("Package : LGERestApi.utils | Message : Failed to create session." );
	    }
	    return securitySession;
	}
	
	public static MessageBodyCollection bodyMessage(int code, String message)
	{
		MessageBodyCollection bodyCollection = new MessageBodyCollection();
		MessageBodyDto bodyDto = new MessageBodyDto();
		bodyDto.setStatus(code);
		bodyDto.setMessage(message);
		bodyCollection.setBody(bodyDto);		
		return bodyCollection;		
	}
}
