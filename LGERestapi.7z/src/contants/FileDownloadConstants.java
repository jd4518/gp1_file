package contants;

public class FileDownloadConstants {

	public static final String EXPIRE = "expireForm.xls";
}
