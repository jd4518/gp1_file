package contants;

public class FilePathContants {
	
	public static final String EXCEL_U_FILE_PATH = "D:\\ENGN\\OpenText\\MediaManagement\\temp\\";
	
	public static final String EXCEL_D_FILE_PATH = "E:/OpenText/OTMM/MediaManagement/excel/";
	
	public static final String FILE_DOWNLOAD_PATH = "E:/OpenText/OTMM/MediaManagement/excel/";
	
	
}
