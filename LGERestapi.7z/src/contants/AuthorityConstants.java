package contants;

public class AuthorityConstants {

	public static final String ADMIN_USER_ID 		= "tsuper";
	
	public static final String COMPONENT_NAME 		= "LGE";
	
	public static final String KEY_NAME 			= "CONFIG";
	
	public static final String VALUE_EXTERNAL_ID	= "EXTERNAL_GROUP_ID";
	
	public static final String VALUE_INTERNAL_ID	= "INTERNAL_GROUP_ID";
	
	public static final String EX_DOMAIN_ID 		= "EX_DOMAIN_ID";
	
	public static final String IN_DOMAIN_ID 		= "IN_DOMAIN_ID";
	
	public static final String MPIS_EXTERNAL_ROLE_ID= "MPIS_EXTERNAL_ROLE_ID";
	
	public static final String MPIS_EXTERNAL_TEMP_ID= "MPIS_EXTERNAL_TEMPLATED_ID";
	
	
}
