package file;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

public class FileUtils {
	
	private static FileUtils instance = new FileUtils();
	
	public static FileUtils getInstance() {
        return instance;
    }

	public boolean createFolderIfNotExists(String dirName)
			throws SecurityException {
		boolean flag = true;
		File theDir = new File(dirName);
		if (!theDir.exists()) {
			if(!theDir.mkdir()) {
				flag = false;
			}
		}
		return flag;
	}
	
	public void deleteFile(String filePath) {
		
		File file = new File(filePath);
		
		if(file.exists()) {
			file.delete();
		}
	}
	
	public void saveToFile(InputStream inStream, String target)
			throws IOException {
		OutputStream out = null;
		int read = 0;
		byte[] bytes = new byte[1024];
		out = new FileOutputStream(target);
		while ((read = inStream.read(bytes)) != -1) {
			out.write(bytes, 0, read);
		}
		out.flush();
		out.close();
	}
	
	public String getRandomString(){
        return UUID.randomUUID().toString().replaceAll("-", "");
    }
	
	public static String check_browser(HttpServletRequest request) {
        String browser = "";
        String header = request.getHeader("User-Agent");
        //신규추가된 indexof : Trident(IE11) 일반 MSIE로는 체크 안됨
        if (header.indexOf("MSIE") > -1 || header.indexOf("Trident") > -1){
            browser = "ie";
        }
        //크롬일 경우
        else if (header.indexOf("Chrome") > -1){
            browser = "chrome";
        }
        //오페라일경우
        else if (header.indexOf("Opera") > -1){
            browser = "opera";
        }
        //사파리일 경우
        else if (header.indexOf("Apple") > -1){
            browser = "sarari";
        } else {
            browser = "firfox";
        }
        return browser;
    }
	
	public static String getDisposition(String down_filename, String browser_check) throws UnsupportedEncodingException {
        String prefix = "attachment;filename=";
        String encodedfilename = null;
        System.out.println("browser_check:"+browser_check);
        if (browser_check.equals("ie")) {
            encodedfilename = URLEncoder.encode(down_filename, "UTF-8").replaceAll("\\+", "%20");
        }else if (browser_check.equals("chrome")) {
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < down_filename.length(); i++){
                char c = down_filename.charAt(i);
                if (c > '~') {
                    sb.append(URLEncoder.encode("" + c, "UTF-8"));
                } else {
                    sb.append(c);
                }
            }
            encodedfilename = sb.toString();
        }else {
            encodedfilename = "\"" + new String(down_filename.getBytes("UTF-8"), "8859_1") + "\"";
        }
        return prefix + encodedfilename;
    }

}
