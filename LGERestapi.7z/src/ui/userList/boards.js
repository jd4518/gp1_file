(function(exports) {	
	var _boardsList = {}; // 등록된 하위 메뉴 리스트
	
	var BoardsView = exports.BoardsView = otui.define("BoardsView", function() {
		this.properties = {
			'name' : 'boards' // 뷰 이름
		};
		
		// 하위 메뉴 렌더링
		function renderBoards(content) {
			var list = content.querySelector(".ot-boards-list"); 
			
			for (var name in _boardsList) {
				var board = _boardsList[name];
				var properties = board.prototype.initialProperties;
				properties.id = name;
				
				var template = this.getTemplate("list"); 
				otui.Templates.applyObject(template, properties); // 하위 메뉴들을 템플릿에 맞게 변경
				list.appendChild(template); // 변경한 하위 메뉴를 첨부
			}
		};
		
		// 하위 메뉴의 뷰 출력
		function loadBoardEvent(event) {
			var board = this.getAttribute("resourceid");
			console.log("board");
			console.log(board);
			var view = otui.Views.containing(this); // 해당 뷰 정보 
			
			view.callRoute("move", {'moveurl' : board});
		};
		
		// 뷰 초기화
		this._initContent = function initBoardsView(self, placeContent) {
			var template = this.getTemplate("content"); // content 템플릿을 얻어와서
			renderBoards.call(this, template); // 등록 된 하위 메뉴를 렌더링
			placeContent(template); // 템플릿을 UI에 배치
		};
		
		// setup 이벤트가 실행 됨
		this.bind("setup", function() {
			var content = this.contentArea();
			content.delegate(".ot-board", "click", loadBoardEvent); // 하위 메뉴 클릭시 해당 뷰 출력
		});
		
	});
	
	// 큰 메뉴 BoardsView에 하위 메뉴를 등록
	BoardsView.registerBoard = function registerBoard(view) {
		var name = view.name;
		if (!(name in _boardsList))
			_boardsList[name] = view;
	};
		
	// URL로부터 moveurl 파라미터를 얻어서 화면에 띄움
	function loadCurrentBoard(req) {
		
		var moveurl = req.params.moveurl;
		if (moveurl && _boardsList[moveurl]) {
			var view = _boardsList[moveurl]; // 클릭한 뷰 선택
			view.route.to()(req); // 선택한 뷰 출력
		} else { // 큰 메뉴 선택시 기본값으로 BoardsView 출력
			_boardsList['NoticeView'];
			req.params.moveurl = 'NoticeView';
			_boardsList['NoticeView'].route.to()(req);
		}
	};
	
	var moveBoard = BoardsView.route.as("board/:moveurl?", // URL
											otui.withTemplate("main-with-sidebar-actionbar"), // 레이아웃 템플릿
											BoardsView.route.to(), // **View.route.to()(parameter) 이런 방식으로 뷰이동(파라미터 전송X)
											loadCurrentBoard); // 커스텀 라우팅 메서드 사용(moveurl 파라미터를 읽고 해당 뷰로 연결)
	
	// 루트 선언
	BoardsView.route.define("move", moveBoard);
	
	otui.ready(function() {
		// 큰 메뉴 생성
		otui.Menus.register({
			'name' : 'board', // 경로의 첫부분과 같은 이름을 주어야 강조 효과가 나옴
			'title' : otui.tr('Board'), // 표시 되는 메뉴 이름
			'select' : BoardsView.route.use("move"), // 선택시 move라는 루트 실행
			'menuimagehover' : otui.tr('Board'),
			'setup' : function () { // 버튼 보이기 / 작동 유무(true/false, enable/disable)
				
				// return otui.UserFETManager.isTokenAvailable('TEST.TEST');
			} 
		});
	}, true);
	
})(window);