(function(exports) {
	var resourceData = [];
	var UserListView = exports.UserListView = otui.extend("JobsTableViewsBaseView", "UserListView", function() {
		
		var $loginNmElement 	= $('ot-metadata[ot-fields="loginNm"]');
		var $loginEmailElement 	= $('ot-metadata[ot-fields="loginEmail"]');
		var $firstNmElement		= $('ot-metadata[ot-fields="firstNm"]');
		var $lastNmElement		= $('ot-metadata[ot-fields="lastNm"]');
		var $comElement			= $('ot-metadata[ot-fields="com"]');
		var $depElement 		= $('ot-metadata[ot-fields="dep"]');
		var $positionElement 	= $('ot-metadata[ot-fields="position"]');

		this.properties = {
			'name' : 'UserListView', 
			'title' : otui.tr("UserList"), 
			'service' : 'newUser2', // 데이터를 가져올 서비스명
			'headerTemplate' : 'userListView_header', // html에서 thead (첫글자 대문자시 에러뜸!!)
			'rowTemplate' : 'userListView_row', // html에서 tbody (첫글자 대문자시 에러뜸!!)
			'pageProperties' : { // sort를 위한 기본값
				'sortField' : 'login_id',
				'sortPrefix' : 'asc'
			},
			'resourceData' : '',
		};
		
		// handleData = service에서 사용하는 callback
		this.handleData = function handleData(response) {
			
			var self = this;
			
			if(response) {

				// ---------- 페이징 시작 ---------- 

	/**
	 *		현재 users api에서는 전체 사용자 수를 알려주는 것이 없으므로 차후 별도로 제작하여 개수를 구해서 아래 값을 변경한 후 주석을 없애면 페이징 구현됨
	 */
				// 게시물 총 개수 체크 (서비스에서 받아온 응답에서 개수를 구해서 넣어주기)
				// PageManager.numTotalChildren[this.properties.name] = 변경해야 하는 값 ==> 
				// response.board_resource.board[0].substring(response.board_resource.board[0].indexOf('total=') + 6, response.board_resource.board[0].indexOf(', board_id')) ?
				//  response.board_resource.board[0].substring(response.board_resource.board[0].indexOf('total=') + 6, response.board_resource.board[0].indexOf(', board_id')) : 0;
				PageManager.numTotalChildren[this.properties.name] =response.user_mng_list_resource.total
;
				// PageManager.assetsPerPage = 3;
				console.log(this.properties.name);

				// 페이징 생성
				PageManager.updatePaging(this, this.properties.name);
				
				// 리스트를 템플릿 형태로 변경
				// user_mng_list_resource
				//users_resource
				var results = $($.map(response.user_mng_list_resource.user_list, function(entry) {
					var result = self.addRowFromTemplate(entry);
					if(entry.disabled) {
						$(result).find('ot-select').val('1');
					}
					return result;
				}));
				
				// 게시물 리스트 출력
				var rowLocation = self.rowLocation();
				rowLocation.empty();
				if(results.length)
					rowLocation.append(results);
				else
					rowLocation.append(otui.Templates.get("jobstableviewsbasenocontent"));
				
				// ---------- 페이지 종료 ---------- 

				
				// thead 클릭으로 sort 변경
				this.internalProperties.sortFunction = function(viewObject, sortField, sortDirection)
				{	
					self.triggerSingle("render"); // 톱니바퀴 sort로 필드값을 바로바로 넘겨주기 위해서
					self.sortFunction(viewObject, sortField, sortDirection);
	            };
				
				this.unblockContent(); // 로딩창 없애기
				// this.blockContent(); // 로딩창 보이기

				// sort 기본값 설정
				// this.properties.pageProperties.sortField = 'name';
				// this.properties.pageProperties.sortPrefix = 'desc';
				
				// 선택된 sort 컬럼에 화살표 표시 주기
				$('.ot-table-heading[name=' + this.properties.pageProperties.sortField + ']').attr('sorted', this.properties.pageProperties.sortPrefix);
				
			}
		};
		
		// 톱니바퀴 안 sort를 사용하기 위해서
		this.bind('render', function() {
			var options = $('#pageSortOptions')[0];
			if(options) {
				otui.empty(options);
				// var sortOptions = otui.JobsManager.jobsSortOptions; // api로 만들어 사용할 경우
				
				var jsonResponse = []; // 하드코딩
				jsonResponse.push({name : "아이디", 	value : "login_id"});
				jsonResponse.push({name : "이름", 	value : "name"});
				jsonResponse.push({name : "이메일",	value : "email_Addr"});
				jsonResponse.push({name : "소속회사", 	value : "company"});
				jsonResponse.push({name : "부서", 	value : "department"});
				jsonResponse.push({name : "가입일", 	value : "create_dt"});
				jsonResponse.push({name : "만료일", 	value : "expire_dt"});  
				var sortOptions = jsonResponse;
				
				for (var index in sortOptions){
					// sort 생성
					var optionItem = document.createElement("option");
					optionItem.id = "option";
					optionItem.text = sortOptions[index].name;
					optionItem.textContent = otui.TranslationManager.getTranslation(sortOptions[index].name);
		  
					if (sortOptions[index].id)
						optionItem.value = sortOptions[index].id;
					else
						optionItem.value = sortOptions[index].value;

					options.appendChild(optionItem);
				}
				options.value = this.properties.pageProperties.sortField; // 현재 정렬 값
			};
		});

		// 뷰가 표시될 때 (setup 후에 render가 작동, render가 작동 안하는 템플릿도 있는듯...)
		this.bind("render", function() {
			var contentArea = this.contentArea();
			var resultsList = contentArea.find(".ot-table-element");
			
			if (this.internalProperties.slimScroll)
				otui.resizeSlimscroll(resultsList);
			else {
				otui.slimscroll(resultsList, {'calculateSize' : true});
				this.internalProperties.slimScroll = true;
			};
		});
		
		this.bind('setup', function() {
			var self = this;
			
			var noticeSearch = $(document).find('.notice-search');
			noticeSearch.attr('placeholder', 'search for keywords');
			noticeSearch.focusin(function() {
				$(this).attr('placeholder', '');
				$(this).addClass("focused");
			});
			noticeSearch.focusout(function() {
				$(this).attr('placeholder', 'search for keywords');
				$(this).removeClass("focused");
			});
		});
		
	});

	UserListView.change = function(event) {
		console.log(event.path[2].model.user_id); // 아이디 값으로 api만들어서 승인신청 하기
	};
		
	// 조회
	otui.registerService('newUser' , {
		'read' : function newUser(data, callback) {
			PageManager.assetsPerPage = 3;
			//ex  (otmmapi/v4/ ex/user?where=&type=I&before=1&after=25)
			var url = otui.service + '/users?after=' + (data.properties.serviceData.pageProperties.page * data.properties.serviceData.pageProperties.assetsPerPage) + '&limit=' + data.properties.serviceData.pageProperties.assetsPerPage + '&sort=' + data.properties.serviceData.pageProperties.sortPrefix + '_' + data.properties.serviceData.pageProperties.sortField;
			otui.get(url, undefined, otui.contentTypes.json, function(response, status, success) {
				if (!success) {
					callback.call(data, null);
				} else {
					callback.call(data, response);
				}
			});
		}
	});
	otui.registerService('newUser2' , {
		'read' : function newUser(data, callback) {
			//ex  (otmmapi/v4/ ex/user?where=&type=I&before=1&after=25)
			var befor = data.properties.serviceData.pageProperties.page * data.properties.serviceData.pageProperties.assetsPerPage +1
			var after = ((Number(data.properties.serviceData.pageProperties.page) +1)) * data.properties.serviceData.pageProperties.assetsPerPage;
			
			var url = otui.service + '/ex/user?where=&type=&before=' + befor + '&after=' + after+'&sort='+data.properties.serviceData.pageProperties.sortField+' '+data.properties.serviceData.pageProperties.sortPrefix;
			// + '&sort=' + data.properties.serviceData.pageProperties.sortPrefix + '_' + data.properties.serviceData.pageProperties.sortField;
			otui.get(url, undefined, otui.contentTypes.json, function(response, status, success) {  
				if (!success) {
					callback.call(data, null);
				} else {
					callback.call(data, response);
				}
			});
		}
	});
	
	BoardsView.registerBoard(UserListView); // BoardsView에 해당 뷰 등록(그래야 메뉴에 해당 뷰가 보임)

})(window);

//버튼 정의 
// userRegistActions
otui.scope('$evnets', function($event) {
	otui.userRegistActions = new otui.IntegrationPoint('userRegistActions', otui.is(otui.modes.TABLET) ? "mobileactions" : "jobs-actions-simple", {
		// 'render' : otui.IntegrationPoint.OVERFLOW({"maxItems" : 4, 'in-menu' : otui.IntegrationPoint.OVERFLOW_IN_MENU.SHOW_OVERFLOWED}),
		'menu' : otui.tr('registerUser'), // 대충 써도 됨
		// 'template' : otui.is(otui.modes.TABLET) ? 'mobileactionsmore' : 'jobs-actions-simple-more'
	});

	// 글 쓰기 버튼 클릭 이벤트
	otui.userRegistActions.write = function(event, resource, point) {
		UserAddView.show(); // 글 작성 다이얼로그 띄움
	};

	
	// 글 쓰기 버튼 생성
	otui.userRegistActions.register({
		'name' : 'board',
		'text' : otui.tr('RegisterUser'),
		// 'setup' : function() {return 'enable';}, // 버튼 표시(true/false) or 작동 유무(enable/disable) 
		'select' : otui.userRegistActions.write,
	}, 0);

	
});
(function(exports) {
	var UserAddView = exports.UserAddView = otui.define("UserAddView", function() {
		this.properties = {
			'name' : 'UserAddView', 
			'title' : otui.tr("RegisterUser")
		}
		
		
		// Function called to create the content for this view. Note that initContent functions must always have a name.
		this._initContent = function initBusinessCard(self, placeContent) {
		// First retrieve our content template, and use the "placeContent" callback to tell the framework to display it.
		placeContent(this.getTemplate("content"));
		
		// Then call the function to retrieve our user details and get them.
		//loadUser.call(this);
		};
		
		
		this.bind("setup", function() {
			// Retrieve the main content area for this view now that it's been set up, and place event listeners on it.
			// The contentArea is expressed as a jQuery object, so we can make use of jQuery's event delegation.
			var contentArea = this.contentArea();
			
			// Within event listeners, we want to make sure that we have a handle for the view. So we create one here which can be accessed inside the event listener.
			var view = this;
			
			// Add a click listener for email links to call sendEmail.
			contentArea.delegate(".ot-businesscard-email-link", "click", function(event) {
				view.sendEmail();
			});
			//필드초기화
			fieldInitialization();
			//로그인아이디, 이메일 중복체크
			overLapChk();			
		});
		
		function overLapChk(){
			var $loginNmElement 	= $('ot-metadata[ot-fields="loginNm"]');
			var $loginEmailElement 	= $('ot-metadata[ot-fields="loginEmail"]');
						
			$loginNmElement.focusout(function(){
				if($loginNmElement.find('input').val() != '')
				{	
					var regExp = /^(?!(?:[0-9]+)$)([a-zA-Z]|[0-9a-zA-Z]){4,}$/;      
					if(!regExp.test($loginNmElement.find('input').val()))    
					{
						$loginNmElement.attr('ot-in-error','ot-in-error');
						$loginNmElement.find('.ot-error-msg').text("you have entered invalid data");
						return false;
					}else{
						$loginNmElement.find('.ot-error-msg').text('');			  	
						$loginNmElement.removeAttr('ot-in-error');  
					}	
			
					var url = otui.service + '/ex/validation?search='+$loginNmElement.find('input').val()+'&type=L';  				
					otui.get(url, undefined, otui.contentTypes.json, function(response, status, success) 
					{
						if(status == 200)
						{
							if(response != 0)
							{
								$loginNmElement.attr('ot-in-error','ot-in-error');
								$loginNmElement.find('.ot-error-msg').text("Duplicate account.");
							}
						}
					},"","html");
				}	
			});  
			
			$loginEmailElement.focusout(function(){
				if($loginEmailElement.find('input').val() != '')
				{
					var regExp = /^([\w-\.']+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
					if(!regExp.test($loginEmailElement.find('input').val()))      
					{
						$loginEmailElement.attr('ot-in-error','ot-in-error');
						$loginEmailElement.find('.ot-error-msg').text("you have entered invalid data.");
						return false;
					}else{
						$loginEmailElement.find('.ot-error-msg').text('');				
						$loginEmailElement.removeAttr('ot-in-error');
					}					
					
					var url = otui.service + '/ex/validation?search='+$loginEmailElement.find('input').val()+'&type=E';    			 	  
					otui.get(url, undefined, otui.contentTypes.json, function(response, status, success) 
					{
						if(status == 200)
						{
							if(response != 0)
							{
								$loginEmailElement.attr('ot-in-error','ot-in-error');
								$loginEmailElement.find('.ot-error-msg').text("Duplicate Email account.");
							}
						}
					},"","html");
				}
			});
		}
		
		
		function fieldInitialization(){
			var $loginNmElement 	= $('ot-metadata[ot-fields="loginNm"]');
			var $loginEmailElement 	= $('ot-metadata[ot-fields="loginEmail"]');
			var $firstNmElement		= $('ot-metadata[ot-fields="firstNm"]');
			var $lastNmElement		= $('ot-metadata[ot-fields="lastNm"]');
			var $comElement			= $('ot-metadata[ot-fields="com"]');
			var $depElement 		= $('ot-metadata[ot-fields="dep"]');
			var $positionElement 	= $('ot-metadata[ot-fields="position"]');
			
			$loginNmElement.click(function(){
				if($loginNmElement.find('.ot-error-msg').text() != ''){
					$loginNmElement.find('.ot-error-msg').text('');				
					$loginNmElement.removeAttr('ot-in-error');
				}  
			});
			
			$loginEmailElement.click(function(){
				if($loginEmailElement.find('.ot-error-msg').text() != ''){
					$loginEmailElement.find('.ot-error-msg').text('');				
					$loginEmailElement.removeAttr('ot-in-error');
				}  
			});
			
			$firstNmElement.click(function(){
				if($firstNmElement.find('.ot-error-msg').text() != ''){
					$firstNmElement.find('.ot-error-msg').text('');				
					$firstNmElement.removeAttr('ot-in-error');
				}  
			});
			
			$lastNmElement.click(function(){
				if($lastNmElement.find('.ot-error-msg').text() != ''){
					$lastNmElement.find('.ot-error-msg').text('');				
					$lastNmElement.removeAttr('ot-in-error');
				}  
			});
			
			$comElement.click(function(){
				if($comElement.find('.ot-error-msg').text() != ''){
					$comElement.find('.ot-error-msg').text('');				
					$comElement.removeAttr('ot-in-error');
				}  
			});
			
			$depElement.click(function(){
				if($depElement.find('.ot-error-msg').text() != ''){
					$depElement.find('.ot-error-msg').text('');				
					$depElement.removeAttr('ot-in-error');
				}  
			});
			
			$positionElement.click(function(){
				if($positionElement.find('.ot-error-msg').text() != ''){
					$positionElement.find('.ot-error-msg').text('');				
					$positionElement.removeAttr('ot-in-error');
				}  
			});
		}
		
		// Visible function which will create a new email to the user's current email address.
		this.sendEmail = function sendEmail() {
			// Get the user details, and see if they have an email address and that it's enabled.
			var userDetails = this.internalProperties.userDetails;
			if (userDetails) {
				if (userDetails.email_address && userDetails.email_enabled) {
					var addr = userDetails.email_address;
					
					// Create a "mailto" URI for this email address, and assign the browser's current location to that 
					// (Which will cause the browser to open the platform's default email platform.
					var href = "mailto:" + addr;
					location.assign(href);
				}
				else {
					// The user has no email address, display a notification to the user as such.
					var displayName = userDetails.name;
					otui.NotificationManager.showNotification({
						'message' : otui.tr("{0} has no email address", displayName), // The translation message has a placeholder in it, which we fill with the display name.
						'status' : 'error', // Show this notification as an error.
						'stayOpen' : true // Keep this notification open until the user manually gets rid of it.
					});
				}
			}
		};
		
		function loadUser() {
		
			var userName = this.properties.userName;
			
			// Display a loader whilst we're retrieving the details.
			this.blockContent();
			
			// In the callback function, "this" wont' be set to the current view, so we preserve scope by creating "self".
			var self = this;
			
			otui.services.user.read({'userName' : userName}, function(response, success) {
				// If the request was a success, then apply the response, which is the user details, to our content.
				// Also, save a copy of it into our internal properties for later.
				if (success)
					{
					self.internalProperties.userDetails = response;
					otui.Templates.applyObject(self.contentArea(), response);
					}
					
				// Then unblock our content
				self.unblockContent();
			});
		};

		this.submit = function(event, loginNm, loginEmail, firstNm, lastNm, company, dep, position)
		{

			otui.confirm("Do you want to join the user?", 
			function(doit)
			{
				if (doit)
				{
					//on Continue.
					if(emptyFieldChk())
					{
						var serviceUrl = "/ex/user/";
						var formData = "loginNm="+loginNm+"&loginEmail="+loginEmail+"&firstNm="+firstNm+"&lastNm="+lastNm+"&company="+company+"&department="+dep+"&position="+position+"&description=TEST";  
						otui.post(otui.service + serviceUrl, formData, otui.contentTypes.formData, function(response, status, success)
						{
							if(success)
							{
								otui.alert({'title' : otui.tr("INFORMATION"), 'message' : 'Your subscription is complete.', 'type' : otui.alertTypes.INFORMATION,
									'closeCallback':function (event) 
									{
										otui.DialogUtils.cancelDialog($('span.ot-modal-dialog-closer'));	  									
									}
								});
							}
							else
							{
								otui.alert({'title' : otui.tr("ERROR"), 'message' : 'You failed to save.', 'type' : otui.alertTypes.ERROR,  
									
								});
							}
						});
					}					
				}
			}); 
		};
		
		function emptyFieldChk(){
			var $loginNmElement 	= $('ot-metadata[ot-fields="loginNm"]');
			var $loginEmailElement 	= $('ot-metadata[ot-fields="loginEmail"]');
			var $firstNmElement		= $('ot-metadata[ot-fields="firstNm"]');
			var $lastNmElement		= $('ot-metadata[ot-fields="lastNm"]');
			var $comElement			= $('ot-metadata[ot-fields="com"]');
			var $depElement 		= $('ot-metadata[ot-fields="dep"]');
			var $positionElement 	= $('ot-metadata[ot-fields="position"]');
			var message = "This field is required.";
			if($loginNmElement.val() == ''){
				$loginNmElement.attr('ot-in-error','ot-in-error');
				$loginNmElement.find('.ot-error-msg').text(message);
				return false;
			}
			else if($loginEmailElement.val() == ''){
				$loginEmailElement.attr('ot-in-error','ot-in-error');
				$loginEmailElement.find('.ot-error-msg').text(message);
				return false;
			}
			else if($firstNmElement.val() == ''){
				$firstNmElement.attr('ot-in-error','ot-in-error');
				$firstNmElement.find('.ot-error-msg').text(message);
				return false;
			}
			else if($lastNmElement.val() == ''){
				$lastNmElement.attr('ot-in-error','ot-in-error');
				$lastNmElement.find('.ot-error-msg').text(message);
				return false;
			}
			else if($comElement.val() == ''){
				$comElement.attr('ot-in-error','ot-in-error');
				$comElement.find('.ot-error-msg').text(message);
				return false;
			}
			else if($depElement.val() == ''){
				$depElement.attr('ot-in-error','ot-in-error');
				$depElement.find('.ot-error-msg').text(message);
				return false;
			}
			else if($positionElement.val() == ''){
				$positionElement.attr('ot-in-error','ot-in-error');
				$positionElement.find('.ot-error-msg').text(message);  
				return false;
			}
			
			return true;
		}
		
		
	});
	UserAddView.show = function(event, options)
	{
		// otui.dialog("UserAddView", options);
		this.asDialog();
	}
})(window);