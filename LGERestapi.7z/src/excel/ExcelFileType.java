package excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


/**
 * ���� ���ε� ���� Ȯ���� üũ
 * @author chungkyu1.lee
 *
 */
public class ExcelFileType {
	
	private static ExcelFileType instance = new ExcelFileType();
	
	public static ExcelFileType getInstance() {
        return instance;
    }
	
	public Workbook getWorkBook(String filePath) {		
		Workbook resultWorkbook = null;		
		File file = new File(filePath);
		
		try {
			resultWorkbook = parse(file);
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return resultWorkbook;		
	}
	
	private Workbook parse(File file) throws Exception{
		return parse(file.getName(), new FileInputStream(file));
	}

	private Workbook parse(String name, InputStream fileInputStream) throws Exception {
		
		System.out.println(name);
		
		if(name.toUpperCase().endsWith("XLS")) {
			return new HSSFWorkbook(fileInputStream);
		}else if(name.toUpperCase().endsWith("XLSX")){
			return new XSSFWorkbook(fileInputStream);
		}else{
			throw new Exception("format failed");
		}	
	}
}
