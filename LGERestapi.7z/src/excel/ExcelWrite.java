package excel;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.util.CellRangeAddress;

public class ExcelWrite {

	 public void ExcelDown(String title, String[] header, String[] content, List<Map> map, HttpServletResponse response) throws Exception{
		  try{
		   HSSFRow row = null;
		   HSSFCell cell = null;
		   HSSFWorkbook wb = new HSSFWorkbook();
		   
		   HSSFSheet sheet = wb.createSheet();
		   wb.setSheetName(0, title);
		   
		   int cellCount = header.length;
		   
		   //���� ���� ����
		   HSSFCellStyle titleCellStyle = wb.createCellStyle();
		   titleCellStyle.setBorderBottom(HSSFCellStyle.BORDER_THICK);
		   titleCellStyle.setBorderLeft(HSSFCellStyle.BORDER_THICK);
		   titleCellStyle.setBorderRight(HSSFCellStyle.BORDER_THICK);
		   titleCellStyle.setBorderTop(HSSFCellStyle.BORDER_THICK);
		   titleCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		   titleCellStyle.setFillForegroundColor(HSSFColor.ORANGE.index);
		   titleCellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		   
		   //�����
		   HSSFRow headerRow = sheet.createRow((short)0);
		   for(int i = 0; i < cellCount; i++){
		    cell = headerRow.createCell(i);
		    cell.setCellValue(header[i]);
		    cell.setCellStyle(titleCellStyle);
		   }
		   
		   //���� ���� ����
		   HSSFCellStyle contentCellStyle = wb.createCellStyle();
		   contentCellStyle.setBorderBottom(HSSFCellStyle.BORDER_THICK);
		   contentCellStyle.setBorderLeft(HSSFCellStyle.BORDER_THICK);
		   contentCellStyle.setBorderRight(HSSFCellStyle.BORDER_THICK);
		   contentCellStyle.setBorderTop(HSSFCellStyle.BORDER_THICK);
		   contentCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		   contentCellStyle.setFillForegroundColor(HSSFColor.WHITE.index);
		   contentCellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		   
		   if(map.size() > 0){
		    for(int i = 0; i < map.size(); i++){
		     row = sheet.createRow((short)(i+1));
		     for(int j = 0; j < content.length; j++){
		      cell = row.createCell(j);
		      String cont = "";
		      cont = String.valueOf(map.get(i).get(content[j]));
		      if("null".equals(cont)){
		       cell.setCellValue("9900");
		      }else{
		       cell.setCellValue(cont);
		      }
		      cell.setCellStyle(contentCellStyle);
		     }
		    }
		   }else{
		    row = sheet.createRow((short)1);
		    for(int i = 0; i < cellCount; i++){
		     cell = row.createCell(i);
		     if(i == 0){
		      cell.setCellValue("��ϵ� �����Ͱ� �����ϴ�.");
		     }
		     cell.setCellStyle(contentCellStyle);
		    }
		    sheet.addMergedRegion(new CellRangeAddress(1, 1, 0, cellCount-1));
		   }
		   
		    //autuSizeColumn after setColumnWidth setting!!
		   for (int i=0;i<cellCount;i++)  
		   { 
		     sheet.autoSizeColumn(i);
		     sheet.setColumnWidth(i, (sheet.getColumnWidth(i))+512 );
		   }
		   
		   response.setContentType("application/vnd.ms-excel;charset=utf-8");
		   response.setHeader("Content-Disposition", "attachment;filename=" +new String((title).getBytes("KSC5601"),"8859_1")+".xls");
		   wb.write(response.getOutputStream());
		  }catch (Exception e) {
		   e.printStackTrace();
		  }
		 }
}
