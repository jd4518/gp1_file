package eunm;

public enum FileList {
	EXPIRE("expireForm.xls");
	
	final private String name;
	
	private FileList(String name) {
		this.name= name;	
	}
	
	public String getName() {
		return name;
	}
}
