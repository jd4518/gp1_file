package common;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.Asset;
import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.BulkAssetResult;
import com.artesia.asset.metadata.services.AssetMetadataServices;
import com.artesia.asset.services.AssetDataLoadRequest;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.common.prefs.PrefData;
import com.artesia.common.prefs.PrefDataId;
import com.artesia.container.Container;
import com.artesia.container.services.ContainerServices;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.event.Event;
import com.artesia.metadata.MetadataCollection;
import com.artesia.metadata.MetadataElement;
import com.artesia.metadata.MetadataField;
import com.artesia.metadata.MetadataTableField;
import com.artesia.metadata.MetadataValue;
import com.artesia.reviewjob.ReviewJob;
import com.artesia.reviewjob.ReviewJobConstants;
import com.artesia.reviewjob.ReviewJobConstants.PARTICIPANT_RETRIEVAL;
import com.artesia.reviewjob.ReviewJobConstants.PARTICIPANT_SORT_FIELD;
import com.artesia.reviewjob.ReviewJobList;
import com.artesia.reviewjob.ReviewJobParticipant;
import com.artesia.reviewjob.ReviewJobSortCriteria;
import com.artesia.reviewjob.services.ReviewJobServices;
import com.artesia.search.Search;
import com.artesia.search.SearchCondition;
import com.artesia.search.SearchConstants;
import com.artesia.search.SearchMetadataCondition;
import com.artesia.search.SearchPagedResult;
import com.artesia.search.SearchSortField;
import com.artesia.search.services.AssetSearchServices;
import com.artesia.security.SecurityPermissions;
import com.artesia.security.SecurityPolicy;
import com.artesia.security.SecuritySession;
import com.artesia.security.UserGroup;
import com.artesia.security.services.SecurityPolicyServices;
import com.artesia.security.services.UserGroupServices;
import com.artesia.system.services.SystemServices;
import com.artesia.user.UserIdentifier;
import com.artesia.user.services.UserServices;

import contants.LGEConstatns;
import ttsg_teams.admin.db.DBMgr;
import ttsg_teams.common.common.TeamsException;
import utils.Utils;


/**
 * 2019.07.29 외부사용자 정책에 Subscribe 권한 추가
 * @author changdeock.yang
 *
 */
public class EventListenerUtils {
	private static final Log log = LogFactory.getLog(EventListenerUtils.class);
	
	private static final SecurityPolicyServices securityPolicyServices 	= SecurityPolicyServices.getInstance();
	private static final UserGroupServices userGroupServices 				= UserGroupServices.getInstance();
	private static final UserServices userServices 						= UserServices.getInstance();
	
	private static final String COMPONENT   = LGEConstatns.COMPONENT_NAME;
	private static final String KEY 		= LGEConstatns.KEY_NAME; 
	
	//teams >> setting �� ��������.
	public static String getSystemSetting(String componentName, String keyName, String settingName, SecuritySession session){		
		PrefDataId dataId = new PrefDataId(componentName, keyName, settingName);
		PrefData retrievedData = null;
		try 
		{
			retrievedData = SystemServices.getInstance().retrieveSystemSettingsByPrefDataId(dataId, session);
		} 
		catch (BaseTeamsException e)   
		{
			log.warn("An exception occured while fetching the system settings" );
		}		
		return retrievedData == null ? "" : retrievedData.getValue();
	}
	
	//�ű� ��å����(����) 
	public static TeamsNumberIdentifier createDynamicPolicy(String dynamicpolicyName, SecuritySession session) throws BaseTeamsException {
		SecurityPolicy aDynamicPolicy = new SecurityPolicy();
	    aDynamicPolicy.setOwnershipType("PUBLIC");
	    aDynamicPolicy.setName(dynamicpolicyName);
	    return securityPolicyServices.createSecurityPolicy(aDynamicPolicy, session);	    
	}
	
	public static TeamsNumberIdentifier createPolicy(String dynamicpolicyName, SecuritySession session) throws BaseTeamsException {
		SecurityPolicy aDynamicPolicy = new SecurityPolicy();
	    aDynamicPolicy.setOwnershipType("PUBLIC");
	    aDynamicPolicy.setName(dynamicpolicyName);
	    return securityPolicyServices.createSecurityPolicy(aDynamicPolicy, session);	    
	}
	
	//�ű� �׷� ���� workflow 
	public static TeamsNumberIdentifier createDynamicUserGroup(String groupName, SecuritySession session) throws BaseTeamsException {
		String parentId  = Utils.getSystemSetting(COMPONENT, KEY, LGEConstatns.DYNAMIC_PARENT_USER_GROUP_ID, session);

		TeamsNumberIdentifier parentUserGroupId = new TeamsNumberIdentifier(new Long(parentId));
		UserGroup userGroup = new UserGroup();
		userGroup.setName(groupName);
		return  userGroupServices.createUserGroup(parentUserGroupId, userGroup, session);
	}
	
	//�ű� �׷���� allowto
	public static TeamsNumberIdentifier createDynamicUserGroupAllowTo(String groupName, SecuritySession session) throws BaseTeamsException {
		String parentId  = Utils.getSystemSetting(COMPONENT, KEY, LGEConstatns.DYNAMIC_PARENT_ALLOWTO_USER_GROUP_ID, session);
		
		TeamsNumberIdentifier parentUserGroupId = new TeamsNumberIdentifier(new Long(parentId));
		UserGroup userGroup = new UserGroup();
		userGroup.setName(groupName);
		return  userGroupServices.createUserGroup(parentUserGroupId, userGroup, session);
	}
	
	//�űԱ׷���� embago
	public static TeamsNumberIdentifier createDynamicUserGroupEmbago(String groupName, SecuritySession session) throws BaseTeamsException {
		String parentId  = Utils.getSystemSetting(COMPONENT, KEY, LGEConstatns.DYNAMIC_PARENT_EMBARGO_USER_GROUP_ID, session);
		
		TeamsNumberIdentifier parentUserGroupId = new TeamsNumberIdentifier(new Long(parentId));
		UserGroup userGroup = new UserGroup();
		userGroup.setName(groupName);
		return  userGroupServices.createUserGroup(parentUserGroupId, userGroup, session);
	}
	
	//��å ���� ����
	public static boolean updateScurityPermission(TeamsNumberIdentifier policyId, TeamsNumberIdentifier groupId, SecuritySession session, int level) {
		SecurityPermissions permission = new SecurityPermissions();
		switch(level) 
		{
			case 1 : permission.setAssetViewPermission(true);
					 permission.setPreviewViewPermission(true);
					 permission.setSummaryViewPermission(true);
					 permission.setExportPermission(true);
					 permission.setSubscribePermission(true);
					 permission.setContentEditPermission(true);
					 permission.setMetadataEditPermission(true);
					 permission.setCommentsPermission(true);
					 permission.setDeleteAssetPermission(true);
					 permission.setEditParentsPermission(true);
					 permission.setUserGroupId(groupId); 
					 permission.setSecurityPolicyId(policyId);
					 
			case 2 : permission.setAssetViewPermission(true);
					 permission.setPreviewViewPermission(true);
					 permission.setSummaryViewPermission(true);
					 permission.setExportPermission(true);
					 permission.setSubscribePermission(true);
					 permission.setContentEditPermission(true);
					 permission.setMetadataEditPermission(true);
					 permission.setCommentsPermission(true);
					 permission.setEditParentsPermission(true);
					 permission.setUserGroupId(groupId); 
					 permission.setSecurityPolicyId(policyId);
					 
			case 3 : permission.setAssetViewPermission(true);
					 permission.setUserGroupId(groupId); 
					 permission.setSecurityPolicyId(policyId);
			case 4 : permission.setAssetViewPermission(true);
					 permission.setPreviewViewPermission(true);
					 permission.setSummaryViewPermission(true);
					 permission.setExportPermission(true);
					 permission.setContentEditPermission(true);  
					 permission.setUserGroupId(groupId);
					 permission.setSecurityPolicyId(policyId);
					 permission.setSubscribePermission(true);
			break;
		}
    	try 
    	{
			securityPolicyServices.lockSecurityPolicy(policyId, session);
			securityPolicyServices.updateSecurityPolicyPermissions(permission, session);
		    securityPolicyServices.unlockSecurityPolicy(policyId, session);
		    return true;
		} 
    	catch (BaseTeamsException e) 
    	{
    		log.info(e.getMessage());
			e.printStackTrace();
			return false;
		} 
    	finally 
    	{
			try 
			{
				securityPolicyServices.unlockSecurityPolicy(policyId, session);
			} 
			catch (BaseTeamsException e) 
			{
				e.printStackTrace();
			}
		}	    	
	}
	
	//��ť��Ƽ ���� ��ȸ
	public static SecurityPolicy getSecurityPolicy(String securityPolicyName, SecuritySession session) throws BaseTeamsException
	{
		SecurityPolicy [] securityPolicys = securityPolicyServices.retrieveSecurityPoliciesByName(securityPolicyName, session);
		if(securityPolicys.length != 0 )
		{
			System.out.println("getSecurityPolicy call : " + securityPolicys);
		}
		
		return securityPolicys[0];
	}

	
	//�����׷����� ��ȸ
	public static UserGroup getUserGroup(String userGroupName, SecuritySession session) throws BaseTeamsException
	{
		UserGroup [] userGroup = userGroupServices.retrieveUserGroupsByName(userGroupName, session);
		return userGroup[0];
	}
	//��ť��Ƽ�� ���� ��ȸ
	public static SecurityPolicy[] getSecurityPolicys(String securityPolicyName, SecuritySession session) throws BaseTeamsException 
	{
		SecurityPolicy [] securityPolicys = securityPolicyServices.retrieveSecurityPoliciesByName(securityPolicyName, session);
		return securityPolicys;
	}
	//�����׷������ ��ȸ
	public static UserGroup[] getUserGroups(String userGroupName, SecuritySession session) throws BaseTeamsException 
	{
		UserGroup [] userGroup = userGroupServices.retrieveUserGroupsByName(userGroupName, session);
		return userGroup;
	}
	
	//��ť��Ƽ ����(ID����)
	public static boolean deleteSecurityPolicyToId(TeamsNumberIdentifier securityPolicyId, SecuritySession session)
	{
		try 
		{
			securityPolicyServices.lockSecurityPolicy(securityPolicyId, session);
			securityPolicyServices.deleteSecurityPolicy(securityPolicyId, session);
			securityPolicyServices.unlockSecurityPolicy(securityPolicyId, session);
			return true;
		} 
		catch (BaseTeamsException e) 
		{			
			log.info(e.getMessage());
			e.printStackTrace();
			return false;
		} 
		finally 
		{
			try 
			{
				securityPolicyServices.unlockSecurityPolicy(securityPolicyId, session);
			} 
			catch (BaseTeamsException e) 
			{
				e.printStackTrace();
			}
		}	
	}
	//��ť��Ƽ ���� (��Ī����)
	public static boolean deleteSecurityPolicyToName(String securityPolicyName, SecuritySession securitySession) 
	{
		TeamsNumberIdentifier policyId = null;
		try 
		{
			SecurityPolicy [] scurityPolicy = securityPolicyServices.retrieveSecurityPoliciesByName(securityPolicyName, securitySession);
			policyId = scurityPolicy[0].getId();
			SecurityPolicyServices.getInstance().lockSecurityPolicy(policyId, securitySession);
			SecurityPolicyServices.getInstance().deleteSecurityPolicy(policyId, securitySession);
			SecurityPolicyServices.getInstance().unlockSecurityPolicy(policyId, securitySession);
			return true;
		} 
		catch (NumberFormatException | BaseTeamsException e)
		{
			log.info(e.getMessage());
			e.printStackTrace();
			return false;
		}
		finally 
		{
			try 
			{
				SecurityPolicyServices.getInstance().unlockSecurityPolicy(policyId, securitySession);
			} 
			catch (BaseTeamsException e) 
			{
				e.printStackTrace();
			}
		}
	}
	//�����׷����(ID����)
	public static boolean deleteUserGroupToId(TeamsNumberIdentifier userGroupId, SecuritySession session) 
	{
		try 
		{
			userGroupServices.lockUserGroup(userGroupId, session);
			userGroupServices.deleteUserGroup(userGroupId, session);
			userGroupServices.unlockUserGroup(userGroupId, session);
			return true;
		}
		catch (BaseTeamsException e) 
		{			
			log.info(e.getMessage());
			e.printStackTrace();
			return false;
		} 
		finally 
		{
			try 
			{
				userGroupServices.unlockUserGroup(userGroupId, session);
			} 
			catch (BaseTeamsException e) 
			{
				e.printStackTrace();
			}
		}
	}
	//�����׷����(��Ī ����)	
	public static boolean deleteUserGroupToName(String groupName, SecuritySession securitySession) 
	{	
		TeamsNumberIdentifier groupId = null;
		try 
		{
			UserGroup [] groupIds = UserGroupServices.getInstance().retrieveUserGroupsByName(groupName, securitySession);
			groupId = groupIds[0].getId();
			UserGroupServices.getInstance().lockUserGroup(groupId, securitySession);
			UserGroupServices.getInstance().deleteUserGroup(groupId, securitySession);
			UserGroupServices.getInstance().unlockUserGroup(groupId, securitySession);
			return true;
		} 
		catch (BaseTeamsException e) 
		{
			log.info(e.getMessage());
			e.printStackTrace();
			return false;
		}
		finally
		{
			try 
			{
				UserGroupServices.getInstance().unlockUserGroup(groupId, securitySession);
			} 
			catch (BaseTeamsException e) 
			{
				e.printStackTrace();
			}
		}
	}
	//����� �׷쿡 �߰�
	public static boolean addUsersToGroup(Set<String> valuesSet, SecuritySession session, String groupNm) 
	{
		UserGroup[] group;
		TeamsNumberIdentifier groupId = null;
		try 
		{
			group = userGroupServices.retrieveUserGroupsByName(groupNm, session);
			groupId = group[0].getId();
			UserGroupServices.getInstance().lockUserGroup(groupId, session);
			UserGroupServices.getInstance().addArtesiaUserGroupUsers(groupId, (String[])valuesSet.toArray(new String[valuesSet.size()]), session);
			UserGroupServices.getInstance().unlockUserGroup(groupId, session);
			return true;
		} 
		catch (BaseTeamsException e) 
		{
			log.info(e.getMessage());
			e.printStackTrace();
			return false;
		}
		finally 
		{
			try 
			{
				userGroupServices.unlockUserGroup(groupId, session);
			} 
			catch (BaseTeamsException e) 
			{
				e.printStackTrace();
			}
		}
		
	}	
	
	public static boolean addUserToGroup(Set<String> valuesSet, SecuritySession session, TeamsNumberIdentifier groupId) 
	{
		try 
		{
			UserGroupServices.getInstance().lockUserGroup(groupId, session);
			UserGroupServices.getInstance().addArtesiaUserGroupUsers(groupId, (String[])valuesSet.toArray(new String[valuesSet.size()]), session);
			UserGroupServices.getInstance().unlockUserGroup(groupId, session);
			return true;
		} 
		catch (BaseTeamsException e) 
		{
			log.info(e.getMessage());
			e.printStackTrace();
			return false;
		}
		finally 
		{
			try 
			{
				userGroupServices.unlockUserGroup(groupId, session);
			} 
			catch (BaseTeamsException e) 
			{
				e.printStackTrace();
			}
		}
		
	}	
	//��/�ܺ� ����� ����
	public static String userStats(String userId, SecuritySession session) throws BaseTeamsException 
	{
		String internal = Utils.getSystemSetting(COMPONENT, KEY, LGEConstatns.VALUE_INTERNAL_ID, session);
		String external = Utils.getSystemSetting(COMPONENT, KEY, LGEConstatns.VALUE_EXTERNAL_ID, session);
		String type = "";
		UserGroup [] groups = userServices.retrieveUsersUserGroups(new UserIdentifier(userId), session);
		for(UserGroup group :  groups) 
		{
			if(group.getId().toString().equals(internal)) 
			{
				type = "I";
			}
			else if(group.getId().toString().equals(external)) 
			{
				type = "E";
			}
		}
		return type;
	}
	
	//Asset���� ��ȸ
	public static Asset getAssetInfo(AssetIdentifier assetId, SecuritySession session) throws BaseTeamsException 
	{
		AssetDataLoadRequest dataRequest = new AssetDataLoadRequest();
		
		dataRequest.setLoadPath(true);
		dataRequest.setLoadMetadata(true);
		dataRequest.setLoadMetadataByModel(true);
		dataRequest.setLoadSecurityPolicies(true);
		return AssetServices.getInstance().retrieveAsset(assetId, dataRequest, session);
	}
	
	public static Asset getAssetInfoLast(AssetIdentifier assetId, SecuritySession session) throws BaseTeamsException 
	{
		AssetDataLoadRequest dataRequest = new AssetDataLoadRequest();
		
		dataRequest.setLoadMetadata(true);
		dataRequest.setLoadMetadataByModel(true);
		dataRequest.setLoadSecurityPolicies(true);
		dataRequest.setLoadAssetContentInfo(true);
		dataRequest.setLoadAssetContentWithText(true);
		dataRequest.setLoadMacResourceInfo(true);
		dataRequest.setLoadVocabularyTerms(true);
		BulkAssetResult result = AssetServices.getInstance().retrieveAssetHistory(assetId, false, false, session);
		
		
		return AssetServices.getInstance().retrieveAsset(result.getListOfSuccessfulAssetId().get(0), dataRequest, session);
	}
	
	//Asset ��Ÿ������ ���� ��ȸ 
	public static MetadataElement getMetadataForField(Asset anAsset, TeamsIdentifier fieldId)
	{
		MetadataCollection metadataCollection = anAsset.getMetadata();
		
		return metadataCollection.findElementById(fieldId);
	}
	
	//Asset���� rvjob���� ��ȸ
	public static List<ReviewJob> getRvJobId(Asset asset, SecuritySession securitySession) throws BaseTeamsException 
	{
		ReviewJobList list = null;
		
		try {
			PARTICIPANT_RETRIEVAL participantFilter = null;
			
			list = ReviewJobServices.getInstance().getAssetReviewJobHistory(asset.getAssetId(), new ReviewJobSortCriteria(), 0, 999, participantFilter, false, false, securitySession);
		}catch(NullPointerException e) {
			return null;
		}catch(IndexOutOfBoundsException e) {
			return null;
		}
		return list.getReviewJobList();
	}
	
	//Set<AssetIdentifier> ���·� Set<Asset> assets ���� ��ȸ
	public static Set<Asset> getAssetIdentifierToAssets(Set<AssetIdentifier> assetIds, SecuritySession session)
	{
		Set<Asset> assets = new HashSet<Asset>();
		AssetDataLoadRequest dataRequest = new AssetDataLoadRequest();
		dataRequest.setLoadPath(true);
		dataRequest.setLoadSecurityPolicies(true);
		dataRequest.setLoadMetadata(true);
		dataRequest.setLoadMetadataByModel(true);
		
		for(AssetIdentifier assetId : assetIds) {
			
			try {
				Asset asset = AssetServices.getInstance().retrieveAsset(assetId, dataRequest, session);
				assets.add(asset);
			} catch (BaseTeamsException e) {
				log.info(e.getMessage());
				e.printStackTrace();
			}
		}
		return assets;
	}
	//List<AssetIdentifier> ���·� List<Asset> ���� ��ȸ
	public static List<Asset> getAssetIdentifierToAssetList(List<AssetIdentifier> assetIds, SecuritySession session)
	{
		List<Asset> assets = new ArrayList<Asset>();
		AssetDataLoadRequest dataRequest = new AssetDataLoadRequest();
		dataRequest.setLoadPath(true);
		dataRequest.setLoadSecurityPolicies(true);
		dataRequest.setLoadMetadata(true);
		dataRequest.setLoadMetadataByModel(true);
		
		for(AssetIdentifier assetId : assetIds) {
			
			try {			
				assets.add(AssetServices.getInstance().retrieveAsset(assetId, dataRequest, session));
			} catch (BaseTeamsException e) {
				log.info(e.getMessage());
				e.printStackTrace();
			}
		}
		return assets;
	}
	
	//����̵�� Asset���� ��ȸ
	public static List<AssetIdentifier> getRvjobToAssets(TeamsIdentifier rvjobId, SecuritySession session)
	{
		List<AssetIdentifier> list = null;
		try {
			list = ReviewJobServices.getInstance().retrieveReviewJobAssetIdList(rvjobId, ReviewJobConstants.NAME, false, true, session);
		} catch (BaseTeamsException e) {
			log.info(e.getMessage());
			e.printStackTrace();
		}
		return list;
	}
	//Embago �׷� �� ��å ����
	public static boolean deleteEmbagoPolicyAndGroup(AssetIdentifier asset, SecuritySession securitySession)
	{		
		try {
			SecurityPolicy [] embagoPolicy = EventListenerUtils.getSecurityPolicys(LGEConstatns.DYNAMIC_SCURITY_EMBARGO_PREFIX+asset.getId(), securitySession);
			if(embagoPolicy.length != 0) 
			{
				UserGroup embagoInterGroup = EventListenerUtils.getUserGroup(LGEConstatns.DYNAMIC_USER_GROUP_INTERNAL_EMBARGO_PREFIX+asset.getId(), securitySession);
				UserGroup embagoExterGroup = EventListenerUtils.getUserGroup(LGEConstatns.DYNAMIC_USER_GROUP_EXTERNAL_EMBARGO_PREFIX+asset.getId(), securitySession);
				try {
					userGroupServices.lockUserGroup(embagoInterGroup.getId(), 	securitySession);
					userGroupServices.deleteUserGroup(embagoInterGroup.getId(), 	securitySession);
					userGroupServices.unlockUserGroup(embagoInterGroup.getId(), 	securitySession);
					
					userGroupServices.lockUserGroup(embagoExterGroup.getId(), 	securitySession);
					userGroupServices.deleteUserGroup(embagoExterGroup.getId(), 	securitySession);
					userGroupServices.unlockUserGroup(embagoExterGroup.getId(), 	securitySession);
					
					securityPolicyServices.lockSecurityPolicy(embagoPolicy[0].getId(), securitySession);
					securityPolicyServices.deleteSecurityPolicy(embagoPolicy[0].getId(), securitySession);
					securityPolicyServices.unlockSecurityPolicy(embagoPolicy[0].getId(), securitySession);
				}finally {
					userGroupServices.unlockUserGroup(embagoInterGroup.getId(), 	securitySession);
					userGroupServices.unlockUserGroup(embagoExterGroup.getId(), 	securitySession);
					securityPolicyServices.unlockSecurityPolicy(embagoPolicy[0].getId(), securitySession);
				}	
			}
		} catch (BaseTeamsException e) {
			log.info(e.getMessage());
			e.printStackTrace();
			return false;
		}		
		return true;
	}
	//AllowTo ��å �� �׷� ����
	public static boolean deleteAllowToPolicyAndGroup(AssetIdentifier asset, SecuritySession securitySession) 
	{		
		try {
			SecurityPolicy [] allowtoPolicy = EventListenerUtils.getSecurityPolicys(LGEConstatns.DYNAMIC_SCURITY_ALLOW_TO_PREFIX+asset.getId(), securitySession);
			if(allowtoPolicy.length != 0) 
			{
				UserGroup allowToGroup = EventListenerUtils.getUserGroup(LGEConstatns.DYNAMIC_USER_GROUP_ALLOW_TO_PREFIX+asset.getId(), securitySession);
				try {												
					userGroupServices.lockUserGroup(allowToGroup.getId(), 	securitySession);
					userGroupServices.deleteUserGroup(allowToGroup.getId(), 	securitySession);
					userGroupServices.unlockUserGroup(allowToGroup.getId(), 	securitySession);
					
					securityPolicyServices.lockSecurityPolicy(allowtoPolicy[0].getId(), securitySession);
					securityPolicyServices.deleteSecurityPolicy(allowtoPolicy[0].getId(), securitySession);
					securityPolicyServices.unlockSecurityPolicy(allowtoPolicy[0].getId(), securitySession);
				}finally {
					userGroupServices.unlockUserGroup(allowToGroup.getId(), 	securitySession);
					securityPolicyServices.unlockSecurityPolicy(allowtoPolicy[0].getId(), securitySession);
				}
			}
		} catch (BaseTeamsException e) {
			log.info(e.getMessage());
			e.printStackTrace();
			return false;
		}		
		return true;
	}
	//���̳��� ��å ����(job ������ ���̳��� ��å ����)
	public static boolean deleteDynamicPolicy(String jobId, SecuritySession securitySession)
	{		
		for(String group : LGEConstatns.LGE_USER_GROUPS_PREFIX) 
		{
			String fullNm = group+jobId;
			UserGroup [] groupIds = null;
						
			try
			{
				groupIds = UserGroupServices.getInstance().retrieveUserGroupsByName(fullNm, securitySession);
				userGroupServices.lockUserGroup(groupIds[0].getId(), 	securitySession);
				userGroupServices.deleteUserGroup(groupIds[0].getId(), 	securitySession);
				userGroupServices.unlockUserGroup(groupIds[0].getId(), 	securitySession);
			} 
			catch (BaseTeamsException e) 
			{
				log.info(e.getMessage());
				e.printStackTrace();
				return false;
			}	
			finally 
			{
				try {
					userGroupServices.unlockUserGroup(groupIds[0].getId(), 	securitySession);
				} catch (BaseTeamsException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				 
		}		
		return true;
	}
	
	//����� ���̳��� �׷� ����(job ������ ���̳��� �׷� ����)
	public static boolean deleteDynamicGroup(String jobId, SecuritySession securitySession)
	{		
		String scurityPolicy = contants.LGEConstatns.DYNAMIC_SCURITY_POLICY+jobId;

		SecurityPolicy [] scurityPolicys = null;
		try 
		{
			scurityPolicys = securityPolicyServices.retrieveSecurityPoliciesByName(scurityPolicy, securitySession);
			if(scurityPolicys.length != 0) {
				SecurityPolicyServices.getInstance().lockSecurityPolicy(scurityPolicys[0].getId(), securitySession);
				SecurityPolicyServices.getInstance().deleteSecurityPolicy(scurityPolicys[0].getId(), securitySession);
				SecurityPolicyServices.getInstance().unlockSecurityPolicy(scurityPolicys[0].getId(), securitySession);
			}			
		} 
		catch (NumberFormatException | BaseTeamsException e)
		{
			log.info(e.getMessage());
			e.printStackTrace();
			return false;
		}
		finally {
			
			try {
				if(scurityPolicys.length != 0 ) {
					SecurityPolicyServices.getInstance().unlockSecurityPolicy(scurityPolicys[0].getId(), securitySession);
				}				
			} catch (BaseTeamsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}	
	//��Ÿ������ owner field ������ ����
	public static boolean setAssetToMetadataField(List<AssetIdentifier> assets, SecuritySession securitySession) 
	{
		MetadataField [] metaFields = new MetadataField[]{new MetadataField(LGEConstatns.ASSET_OWNER_ID)};		
		List<Asset> assetList = getAssetIdentifierToAssetList(assets, securitySession);
		for(Asset asset : assetList) {
						
			try {
				List<ReviewJob> rvJobList = getRvJobId(asset, securitySession);
				metaFields[0].setValue(rvJobList.get(0).getInitiatorUserId().toString());
				AssetServices.getInstance().lockAsset(asset.getAssetId(), securitySession);
				AssetMetadataServices.getInstance().saveMetadataForAssets(asset.getAssetId().asAssetIdArray(), metaFields, securitySession);
				AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);				
			} catch (BaseTeamsException e) {
				e.printStackTrace();
				return false;
			}finally {
				try {
					AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);
				} catch (BaseTeamsException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return true;
	}
	//����� �׷� ����
	public static void deleteGroup(Event event, SecuritySession securitySession) 
	{		
		for(String group : LGEConstatns.LGE_USER_GROUPS_PREFIX) 
		{
			String fullNm = group+event.getObjectId();
			UserGroup [] groupIds = null;
			try 
			{
				groupIds = UserGroupServices.getInstance().retrieveUserGroupsByName(fullNm, securitySession);
				UserGroupServices.getInstance().lockUserGroup(groupIds[0].getId(), securitySession);
				UserGroupServices.getInstance().deleteUserGroup(groupIds[0].getId(), securitySession);
				UserGroupServices.getInstance().unlockUserGroup(groupIds[0].getId(), securitySession);
			} 
			catch (BaseTeamsException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				try {
					UserGroupServices.getInstance().unlockUserGroup(groupIds[0].getId(), securitySession);
				} catch (BaseTeamsException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}		
	}
	
	// job completed시 정책변경
	// dynamic -> public + allowTo
	// dynamic + embargo ->  embargo
	// dynamic + embargo + embargo 기간이후 -> public + allowTo
	// 정책변경은 AssetToEditHandler에서 적용됨.
	public static void defaultSecuritySetting(Event event, SecuritySession securitySession) 
	{
		TeamsIdentifier allowToUserfield 		= LGEConstatns.ALLOW_TO_USER_ACCESS_FIELD_ID;
		TeamsIdentifier folderField 			= LGEConstatns.FOLDER_PATH_ID;
		
		Set<String> SetUsers = new HashSet<String>();
		try 
		{
			//job 아이디를 통해 job에 속해있는 asset list 조회
			List<AssetIdentifier> list = ReviewJobServices.getInstance().retrieveReviewJobAssetIdList(new TeamsIdentifier(event.getObjectId()), ReviewJobConstants.NAME, true, true, securitySession);
			if(!list.isEmpty()) 
			{
				//Asset중에 Embargo Asset 검색
				List<Asset> assets = EventListenerUtils.getAssetIdentifierToAssetList(list, securitySession);
				for(Asset asset : assets) {
					
					PARTICIPANT_SORT_FIELD sortField = null;
					List<ReviewJobParticipant> rvjobList = ReviewJobServices.getInstance().retrieveParticipantList(new TeamsIdentifier(event.getObjectId()), 3, sortField, false, false, securitySession);
					for(ReviewJobParticipant user : rvjobList) 
					{
						log.info("============== user id : " + user.getUserId().toString());
						String type = userStats(user.getUserId().toString(), securitySession);
						if(type.equals("E")) SetUsers.add(user.getUserId().toString());
					}
					
					boolean flag = getEmbargoChk(asset, securitySession);
					if(!flag) 
					{		
						//일반 Asset metadata settting
						setTabularFields(asset.getAssetId(), allowToUserfield, SetUsers, false, securitySession);
					}
					else 
					{
						//embargoAssets.add(asset);
						MetadataCollection metadataCollection 	= asset.getMetadata();
						//Embago 메타데이터 정보 조회
						MetadataElement embagoElement 			= metadataCollection.findElementById(LGEConstatns.EMBARGO_USER_ACCESS_FIELD_ID);
						//AllowTo 메타데이터 정보 조회
						//데이터 변환
						MetadataValue[] embagoValues 			= embagoElement == null ? null : ((MetadataTableField)embagoElement).getValues();
						
						for (MetadataValue aValue : embagoValues)
						{
							if (aValue.getValue() != null)
							{
								//내부 or 외부 사용자 구분
								String type = EventListenerUtils.userStats(aValue.getStringValue(), securitySession);
								log.info("============== aValue id : " + aValue.getStringValue()+" aValue type : " + type);
								if(type.equals("E"))
								{
									SetUsers.add(aValue.getStringValue());
								}
							}
						}
						setTabularFields(asset.getAssetId(), allowToUserfield, SetUsers, false, securitySession);
						
					}
					
					try {
	     				String folderQuery = "SELECT FOLDERNAME FROM OTMM.LGE_MPIS_JOB_FOLDER_NAME_CT WHERE JOB_ID = '"+event.getObjectId()+"'";
//	     				ResultSet folderResult = DbConnection.selectQuery(folderQuery, null);
	     				Connection connection = null;
	     				PreparedStatement preparedStatement = null;	
	     				ResultSet folderResult = null;
	     				Set<String> ids = new HashSet<>();
	     				try
	     				{
	     					DBMgr db = new DBMgr();
	     					connection = db.openDatabase();
	     					preparedStatement = connection.prepareStatement(folderQuery);
	     					folderResult = preparedStatement.executeQuery();	
	     					while(folderResult.next())
	     					{
	    	     				if(folderResult.next()) 
	    	     				{	     					
	    	     					ids.add(folderResult.getString("foldername"));
	    	     					
	    	     				}  
	    	     				else 
	    	     				{
	    	     					ids.add(event.getObjectName());
	    	     				}	
	     					}

	     				}
	     				finally
	     				{
	     					if(connection != null)  connection.close();
	     					if(preparedStatement != null) preparedStatement.close();
	     					if(folderResult != null) folderResult.close();
	     				}
	     				
//	     				Set<String> ids = new HashSet<>();
//	     				if(folderResult.next()) 
//	     				{	     					
//	     					ids.add(folderResult.getString("foldername"));
//	     					
//	     				}  
//	     				else 
//	     				{
//	     					ids.add(event.getObjectName());
//	     				}
	     				setTabularFields(asset.getAssetId(), folderField, ids, false, securitySession);
	     			} catch (SQLException | TeamsException e) {
	     				// TODO Auto-generated catch block
	     				e.printStackTrace();
	     			} 									
				}
			}
		} 
		catch (BaseTeamsException e) 
		{
			log.info("========== event : defaultSecuritySetting try " + e.getMessage());
			e.printStackTrace();
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
	}
	
	
	// 정책 삭제
	public static boolean deleteSecurityPolicy(Event event, SecuritySession securitySession) 
	{
		String securiyPolicy = contants.LGEConstatns.DYNAMIC_SCURITY_POLICY+event.getObjectId();
		SecurityPolicy [] scurityPolicy = null;
		try 
		{
			scurityPolicy = securityPolicyServices.retrieveSecurityPoliciesByName(securiyPolicy, securitySession);
			SecurityPolicyServices.getInstance().lockSecurityPolicy(scurityPolicy[0].getId(), securitySession);
			SecurityPolicyServices.getInstance().deleteSecurityPolicy(scurityPolicy[0].getId(), securitySession);
			SecurityPolicyServices.getInstance().unlockSecurityPolicy(scurityPolicy[0].getId(), securitySession);
			return true;
		} 
		catch (NumberFormatException | BaseTeamsException e)
		{
			e.printStackTrace();
			return false;
		}finally {
			try {
				SecurityPolicyServices.getInstance().unlockSecurityPolicy(scurityPolicy[0].getId(), securitySession);
			} catch (BaseTeamsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	//Embago or Allowto asset üũ
//	public static boolean embagoAndAllowToChk(Asset asset, SecuritySession securitySession) 
//	{
//		
//		try {
//			SecurityPolicy[] embagoPolicy =  getSecurityPolicys(LGEConstatns.DYNAMIC_SCURITY_EMBAGO_PREFIX+asset.getAssetId(), securitySession);
//			SecurityPolicy[] allowtoPolicy =  getSecurityPolicys(LGEConstatns.DYNAMIC_SCURITY_ALLOW_TO_PREFIX+asset.getAssetId(), securitySession);
//			if(embagoPolicy.length == 0 && allowtoPolicy.length == 0) return false;
//		} catch (BaseTeamsException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace(); 
//		}
//		return true;
//	}
	
	public static boolean embagoAndAllowToChk(Asset asset, SecuritySession securitySession) 
	{		
		try {
			SecurityPolicy[] embagoPolicy =  getSecurityPolicys(LGEConstatns.DYNAMIC_SCURITY_EMBARGO_PREFIX+asset.getAssetId(), securitySession);
			MetadataCollection metadataCollection 	= asset.getMetadata();
			MetadataElement allowToElement 			= metadataCollection.findElementById(LGEConstatns.ALLOW_TO_USER_ACCESS_FIELD_ID);
			MetadataValue[] allowToValues 			= allowToElement == null ? null : ((MetadataTableField)allowToElement).getValues();
			if(embagoPolicy.length == 0 && allowToValues.length == 0) return false;
		} catch (BaseTeamsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace(); 
		}
		return true;
	}
	
	public static boolean embagoChk(Asset asset, SecuritySession securitySession) 
	{		
		try {
			SecurityPolicy[] embagoPolicy =  getSecurityPolicys(LGEConstatns.DYNAMIC_SCURITY_EMBARGO_PREFIX+asset.getAssetId(), securitySession);
			if(embagoPolicy.length == 0) return false;
		} catch (BaseTeamsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace(); 
		}
		return true;
	}
	
	public static boolean embargoPolicyChk(Asset asset, SecuritySession securitySession) 
	{				
		List<SecurityPolicy> assetPolicyList = asset.getSecurityPolicyList();
		for(SecurityPolicy assetPolicy : assetPolicyList) 
		{
			if(assetPolicy.getName().contains(LGEConstatns.DYNAMIC_SCURITY_EMBARGO_PREFIX)) 
			{
				return true;
			}									
		}
		return false;
	}
	
	public static boolean getEmbargoChk(Asset asset, SecuritySession securitySession) throws ParseException 
	{				
		//Asset 메타데이터 조회
		MetadataCollection metadataCollection 	= asset.getMetadata();
		//Embargo Date 조회
		MetadataElement embagoDateElement 		= metadataCollection.findElementById(new TeamsIdentifier("ARTESIA.FIELD.EMBARGO DATE"));		
		MetadataValue embargoDate 				=  ((MetadataField)embagoDateElement).getValue();
		if(!embargoDate.isNullValue())
		{
			if(new SimpleDateFormat("yyyy-MM-dd").parse(embargoDate.getStringValue()).getTime() <= new SimpleDateFormat("yyyy-MM-dd").parse(getDate(0)).getTime())	return true;
		}
		
		List<SecurityPolicy> assetPolicyList = asset.getSecurityPolicyList();
		for(SecurityPolicy assetPolicy : assetPolicyList) 
		{
			if(assetPolicy.getName().contains(LGEConstatns.DYNAMIC_SCURITY_EMBARGO_PREFIX)) 
			{
				return true;
			}									
		}
		return false;
	}
	
	
	//public 정책 체크
	public static boolean publicPolicyChk(Asset asset, SecuritySession securitySession) 
	{
		String publicCcurityPolicyCode 	= Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.KEY_NAME, LGEConstatns.PUBLIC_SECURITY_POLICY_ID, securitySession);		
		List<SecurityPolicy> assetPolicyList = asset.getSecurityPolicyList();
		if(!embagoAndAllowToChk(asset, securitySession)) {
			for(SecurityPolicy assetPolicy : assetPolicyList) {						
				if(publicCcurityPolicyCode.equals(assetPolicy.getId().toString())) {
					return  true;
				}
			}
		}
		return false;
	}
	
	// folder or asset exist check and return id
	public static AssetIdentifier folderCheck(TeamsIdentifier parentId, SecuritySession session, String pathName) throws BaseTeamsException 
	{
		List<String> names = new ArrayList<>();		
		names.add(pathName);
		List<AssetIdentifier> path = ContainerServices.getInstance().getChidAssetsWithNames(parentId, names, session);
		
		if(path.size() != 0) {
			return path.get(0);
		}		
		return null;
	}
	
	// create folder
	public static Container createFolder(TeamsIdentifier parentId, String folderName, SecuritySession session) throws BaseTeamsException 
	{
		String hierarchy_id = Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.KEY_NAME, LGEConstatns.JOB_HIERARCHY_POLICY_ID, session);
		Container parentContainer = null;
		Container newContainer = new Container();
 		Set<SecurityPolicy> securityPolicys = new HashSet<SecurityPolicy>();
 		securityPolicys.add(new SecurityPolicy(new TeamsNumberIdentifier(new Long("2"))));
 		//2019-04-17 JOB정책 추가
 		securityPolicys.add(new SecurityPolicy(new TeamsNumberIdentifier(new Long(hierarchy_id))));
 		
 		newContainer.setName(folderName);
 		newContainer.setContainerTypeId(new TeamsIdentifier("ARTESIA.BASIC.FOLDER"));
 		newContainer.setSecurityPolicies((SecurityPolicy[]) securityPolicys.toArray(new SecurityPolicy[securityPolicys.size()]));
 		parentContainer = ContainerServices.getInstance().createContainer(newContainer, parentId, session);
 		
 		return parentContainer;
	}
	  
	//Tabular Field 셋팅
	public static boolean setTabularFields(AssetIdentifier assetId, TeamsIdentifier field, Set<String> ids, boolean flag, SecuritySession session) {
		log.info("============ setTabularFields =============== " + assetId +"================== field" + field);
		TeamsIdentifier[] fieldIds = new TeamsIdentifier[] { field };
		MetadataCollection[] metaCols;
		try {
			metaCols = AssetMetadataServices.getInstance().retrieveMetadataForAssets(assetId.asAssetIdArray(), fieldIds, null, session);
			MetadataCollection assetMetadata = metaCols[0];
			MetadataTableField valueField = (MetadataTableField) assetMetadata.findElementById(field);
			Set<String> preData = new HashSet<>();
			
			int rows = valueField.getRowCount();
			
			for(int i=0;i<rows;i++) {
				preData.add(valueField.getValueAt(i).getStringValue());
			}
	
			valueField.clearValues();
			
			valueField.setSavedValuesBehaviorMode(MetadataTableField.REPLACE_VALUES);
			
			for(String id : ids) 
		    {
				preData.add(id);
		    }
			
			if(preData.size() != 0) {
				for(String pre : preData) {
					valueField.addValue(new MetadataValue(pre));
				}				
			}	
			//추가 UNLOCK부터 실해
			AssetServices.getInstance().unlockAssets(assetId.asAssetIdArray(), session);
		    AssetServices.getInstance().lockAssets(assetId.asAssetIdArray(), session);	    
		    try
		    {
		    	AssetMetadataServices.getInstance().saveMetadataForAssets(assetId.asAssetIdArray(), new MetadataField[]
		        { valueField }, session);
		    }
		    finally
		    {
		       AssetServices.getInstance().unlockAssets(assetId.asAssetIdArray(), session);
		    }
		    
		}catch (BaseTeamsException e) {
			return false;
		}			      
		return true;
	}
	
	
	public static String getJobFolderName(String jobId) {		
		String folderNm = null;
		try {
				String folderQuery = "SELECT FOLDERNAME FROM OTMM.LGE_MPIS_JOB_FOLDER_NAME_CT WHERE JOB_ID = '"+jobId+"'";
				Connection connection = null;
				PreparedStatement preparedStatement = null;	
				ResultSet folderResult = null;
				try
				{
					DBMgr db = new DBMgr();
					connection = db.openDatabase();
					preparedStatement = connection.prepareStatement(folderQuery);
					folderResult = preparedStatement.executeQuery();	
					while(folderResult.next())
					{
						folderNm = folderResult.getString("foldername");
					}

				}
				finally
				{
					if(connection != null)  connection.close();
					if(preparedStatement != null) preparedStatement.close();
					if(folderResult != null) folderResult.close();
				}
				
//				ResultSet folderResult = DbConnection.selectQuery(folderQuery, null);
//				if(folderResult.next()) {					
//					folderNm = folderResult.getString("foldername");
//				}
			} catch (SQLException | TeamsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return folderNm;
	}
	
	public static Container getFolder(AssetIdentifier id,  SecuritySession session) {
		Container con = new Container();
		AssetDataLoadRequest request = new AssetDataLoadRequest();

		try {
			con =  ContainerServices.getInstance().getContainer(id, request, session);
		} catch (BaseTeamsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	public static String getDate(int month) 
	{
		Calendar cal = Calendar.getInstance();
	    cal.add(Calendar.MONTH, +month);
	    Date currentTime=cal.getTime();
	    SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd"); 
	    String release_Dt_start=formatter.format(currentTime);
	    return release_Dt_start;
	}
	@SuppressWarnings("deprecation")
	public static String getMaxVersionAssetId(AssetIdentifier id, SecuritySession session) throws BaseTeamsException
    {
		Asset asset = getAssetInfo(id, session);
		Search search = new Search();
		List<SearchCondition> mcList = new ArrayList<SearchCondition>();
		SearchMetadataCondition fi = null;
		String assetId = null;
    
		SearchSortField sortField = new SearchSortField(new TeamsIdentifier("ARTESIA.FIELD.ASSET VERSION"), "desc");
		fi = new SearchMetadataCondition(new TeamsIdentifier("ARTESIA.FIELD.ORIGINAL ASSET ID"), new TeamsIdentifier("ARTESIA.OPERATOR.CHAR.IS"), asset.getOriginalAssetId().toString());
		fi.setRelationalOperator("and");    
		mcList.add(fi);
		search.addConditions(mcList);
		search.addSortField(sortField);
		search.setPluginId(SearchConstants.DATABASE_SEARCH_PLUGIN_ID);
    
		SearchPagedResult searchPagedResult = null;
		try
		{
			searchPagedResult = AssetSearchServices.getInstance().runPagedAssetSearch(search, new Long(0), new Long(1), session);
			if (searchPagedResult.getHitCount() > 0) {
				assetId = ((AssetIdentifier)searchPagedResult.getAssetIdList().get(0)).getId();
			}
		}
		catch (BaseTeamsException e)
		{
			e.printStackTrace();
		}
		return assetId;
    }
		  
	@SuppressWarnings("deprecation")
	public static Set<String> getVersionAssetIds(AssetIdentifier id, SecuritySession session) throws BaseTeamsException
	{
		Asset asset = getAssetInfo(id, session);
	    Search search = new Search();
	    List<SearchCondition> mcList = new ArrayList<SearchCondition>();
	    SearchMetadataCondition fi = null;
	    Set<String> assetIds = new HashSet<String>();
	    
	    SearchSortField sortField = new SearchSortField(new TeamsIdentifier("ARTESIA.FIELD.ASSET VERSION"),  "desc");
	    fi = new SearchMetadataCondition(new TeamsIdentifier("ARTESIA.FIELD.ORIGINAL ASSET ID"), new TeamsIdentifier("ARTESIA.OPERATOR.CHAR.IS"), asset.getOriginalAssetId().toString());
	    fi.setRelationalOperator("and");
	    
	    mcList.add(fi);
	    search.addConditions(mcList);
	    search.addSortField(sortField);
	    search.setPluginId(SearchConstants.DATABASE_SEARCH_PLUGIN_ID);
	    
	    SearchPagedResult searchPagedResult = null;
	    try
	    {
	      searchPagedResult = AssetSearchServices.getInstance().runPagedAssetSearch(search, new Long(0), new Long(0), session);
	      if (searchPagedResult.getHitCount() > 0) 
	      {
	        for (int i = 0; i < searchPagedResult.getHitCount(); i++) {
	          assetIds.add(((AssetIdentifier)searchPagedResult.getAssetIdList().get(i)).getId());
	        }
	      }
	    }
	    catch (BaseTeamsException e)
	    {
	      e.printStackTrace();
	    }
	    return assetIds;
	}
}
