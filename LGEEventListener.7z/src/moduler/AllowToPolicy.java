package moduler;

import java.util.Set;

import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.security.SecurityPolicy;
import com.artesia.security.SecuritySession;
import com.artesia.security.UserGroup;
import com.artesia.security.services.SecurityPolicyServices;
import com.artesia.security.services.UserGroupServices;

import common.EventListenerUtils;
import contants.LGEConstatns;
import utils.Utils;

public class AllowToPolicy {
	private static final String COMPONENT   = LGEConstatns.COMPONENT_NAME;
	private static final String KEY 		= LGEConstatns.KEY_NAME;
	
	private static final UserGroupServices userGroupServices 				= UserGroupServices.getInstance();
	private static final SecurityPolicyServices securityPolicyServices 	= SecurityPolicyServices.getInstance();
	
	private static final AllowToPolicy instance = new AllowToPolicy();
	
	
	public static final AllowToPolicy getInstance()
	{
	    return instance;
	}
	
	//AllowTo �׷� �� ��å ����
	public void create(Set<String> users, SecuritySession securitySession) throws BaseTeamsException {
		String adminGroupId = EventListenerUtils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.KEY_NAME, LGEConstatns.SYSTEM_ADMIN_GROUP_ID, securitySession);
			
		TeamsNumberIdentifier createdAllowToPolicy 		= EventListenerUtils.createPolicy(LGEConstatns.DYNAMIC_SCURITY_ALLOW_TO_PREFIX+users.iterator().next(), securitySession);
		TeamsNumberIdentifier createdAllowToUserGroup 	= createDynamicUserGroupAllowTo(LGEConstatns.DYNAMIC_USER_GROUP_ALLOW_TO_PREFIX+users.iterator().next(), securitySession);
		EventListenerUtils.updateScurityPermission(createdAllowToPolicy, createdAllowToUserGroup, securitySession, 4);
		EventListenerUtils.updateScurityPermission(createdAllowToPolicy, new TeamsNumberIdentifier(new Long(adminGroupId)), securitySession, 1);
		EventListenerUtils.addUserToGroup(users, securitySession, createdAllowToUserGroup);
	}
	

	
	//AllowTo �׷� �� ��å ����
	public void delete(Set<String> users, SecuritySession securitySession) {
		deleteAllowToPolicyAndGroup(users, securitySession);
	}
	
	//AllowTo �׷� ����
	private TeamsNumberIdentifier createDynamicUserGroupAllowTo(String groupName, SecuritySession session) throws BaseTeamsException {
		String parentId  = Utils.getSystemSetting(COMPONENT, KEY, LGEConstatns.DYNAMIC_PARENT_ALLOWTO_USER_GROUP_ID, session);
		
		TeamsNumberIdentifier parentUserGroupId = new TeamsNumberIdentifier(new Long(parentId));
		UserGroup userGroup = new UserGroup();
		userGroup.setName(groupName);
		return  userGroupServices.createUserGroup(parentUserGroupId, userGroup, session);
	}
	
	//AllowTo �׷� �� ��å ����
	private boolean deleteAllowToPolicyAndGroup(Set<String> users, SecuritySession securitySession) 
	{		
		for(String user : users) {
			try {
				SecurityPolicy [] allowtoPolicy = EventListenerUtils.getSecurityPolicys(LGEConstatns.DYNAMIC_SCURITY_ALLOW_TO_PREFIX+user, securitySession);
				if(allowtoPolicy.length != 0) 
				{
					UserGroup allowToGroup = EventListenerUtils.getUserGroup(LGEConstatns.DYNAMIC_USER_GROUP_ALLOW_TO_PREFIX+user, securitySession);
					try {												
						userGroupServices.lockUserGroup(allowToGroup.getId(), 	securitySession);
						userGroupServices.deleteUserGroup(allowToGroup.getId(), 	securitySession);
						userGroupServices.unlockUserGroup(allowToGroup.getId(), 	securitySession);
						
						securityPolicyServices.lockSecurityPolicy(allowtoPolicy[0].getId(), securitySession);
						securityPolicyServices.deleteSecurityPolicy(allowtoPolicy[0].getId(), securitySession);
						securityPolicyServices.unlockSecurityPolicy(allowtoPolicy[0].getId(), securitySession);
					}finally {
						userGroupServices.unlockUserGroup(allowToGroup.getId(), 	securitySession);
						securityPolicyServices.unlockSecurityPolicy(allowtoPolicy[0].getId(), securitySession);
					}
				}
			} catch (BaseTeamsException e) {
				e.printStackTrace();
				return false;
			}
		}			
		return true;
	}

}
