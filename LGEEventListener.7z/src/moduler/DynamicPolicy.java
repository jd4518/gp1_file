package moduler;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.security.services.AssetSecurityServices;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.event.Event;
import com.artesia.reviewjob.ReviewJobConstants.PARTICIPANT_SORT_FIELD;
import com.artesia.reviewjob.ReviewJobParticipant;
import com.artesia.reviewjob.services.ReviewJobServices;
import com.artesia.security.SecurityPolicy;
import com.artesia.security.SecuritySession;
import com.artesia.security.UserGroup;
import com.artesia.security.services.SecurityPolicyServices;
import com.artesia.security.services.UserGroupServices;

import common.EventListenerUtils;
import contants.LGEConstatns;
import utils.Utils;

public class DynamicPolicy {
	private static final SecurityPolicyServices securityPolicyServices = SecurityPolicyServices.getInstance();
	private static final UserGroupServices userGroupServices 				= UserGroupServices.getInstance();
	private static final DynamicPolicy instance = new DynamicPolicy();
	
	private static final String COMPONENT   = LGEConstatns.COMPONENT_NAME;
	private static final String KEY 		= LGEConstatns.KEY_NAME;
	
	public static final DynamicPolicy getInstance()
	{
	    return instance;
	}
	
	/**
	 * DynamicPolicy ����
	 * @param event
	 * @param securitySession
	 */
	public void create(Event event, SecuritySession securitySession, boolean assign) {		
		String adminGroupId = EventListenerUtils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.KEY_NAME, LGEConstatns.SYSTEM_ADMIN_GROUP_ID, securitySession);
		//2019-04-17 어드민관리 계정추가
		String dynamicAdminGroupId = EventListenerUtils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.KEY_NAME, LGEConstatns.DYNAMIC_ADMIN_GROUP_ID, securitySession);
		
		
		
		//���λ���� ����
		Set<String> internalUser = new HashSet<>();
		//�ܺλ���� ����
		Set<String> externalUser = new HashSet<>();
		
		Set<TeamsNumberIdentifier> policyIds = new HashSet<TeamsNumberIdentifier>();
		
		PARTICIPANT_SORT_FIELD sortField = null;
		
		try {
			//내부사용자 그룹생성
			TeamsNumberIdentifier createDynamicInterUserGroup 	= createDynamicUserGroup(LGEConstatns.LGE_USER_GROUPS_PREFIX[0]+event.getObjectId(), securitySession);
			//외부사용자 그룹생성
			TeamsNumberIdentifier createDynamicExterUserGroup 	= createDynamicUserGroup(LGEConstatns.LGE_USER_GROUPS_PREFIX[1]+event.getObjectId(), securitySession);
			//다이나믹 정책 생성
			TeamsNumberIdentifier createDynamicPolicy 	  		= EventListenerUtils.createPolicy(LGEConstatns.DYNAMIC_SCURITY_PREFIX+event.getObjectId(), securitySession);
			//내부 사용자그룹 정책 권한부여
			EventListenerUtils.updateScurityPermission(createDynamicPolicy, createDynamicInterUserGroup, securitySession, 2);
			//외부 사용자그룹 정책 권한부여
			EventListenerUtils.updateScurityPermission(createDynamicPolicy, createDynamicExterUserGroup, securitySession, 4);
			//관리자에게 정책 권한 부여
			EventListenerUtils.updateScurityPermission(createDynamicPolicy, new TeamsNumberIdentifier(new Long(adminGroupId)), securitySession, 1);
			//adminGroup에게 정책 권한 부여
			EventListenerUtils.updateScurityPermission(createDynamicPolicy, new TeamsNumberIdentifier(new Long(dynamicAdminGroupId)), securitySession, 1);
						
			//job에 포함된 사용자 정보 조회
			List<ReviewJobParticipant> list = ReviewJobServices.getInstance().retrieveParticipantList(new TeamsIdentifier(event.getObjectId()), 3, sortField, false, false, securitySession);
			
			for(ReviewJobParticipant user : list) 
			{
				//내/외부 사용자 구분
				String type = EventListenerUtils.userStats(user.getUserId().toString(), securitySession);
				if(type.equals("I")) 		internalUser.add(user.getUserId().toString());
				else if(type.equals("E")) 	externalUser.add(user.getUserId().toString());  				
			}
			//내/외부 사용자 그룹에 추가
			if(internalUser.size() != 0) EventListenerUtils.addUsersToGroup(internalUser, securitySession, contants.LGEConstatns.LGE_USER_GROUPS_PREFIX[0]+event.getObjectId());
			if(externalUser.size() != 0) EventListenerUtils.addUsersToGroup(externalUser, securitySession, contants.LGEConstatns.LGE_USER_GROUPS_PREFIX[1]+event.getObjectId());
			if(assign)
			{
				policyIds.add(createDynamicPolicy);
				List<AssetIdentifier> assetList = EventListenerUtils.getRvjobToAssets(new TeamsIdentifier(event.getObjectId()), securitySession);
				
				System.out.println("ReOpenJob asset size : " + assetList.size());
				
				AssetIdentifier[] stringArray = assetList.toArray(new AssetIdentifier[0]);
				
//				for(AssetIdentifier assetId : assetList)
//				{
//					System.out.println("asset Id : " + assetId);
					AssetServices.getInstance().unlockAssets(stringArray, securitySession);
					AssetServices.getInstance().lockAssets(stringArray, securitySession);
//					AssetServices.getInstance().lockAsset(assetId, securitySession);
					AssetSecurityServices.getInstance().assignSecurityPoliciesToAssets(stringArray , (TeamsNumberIdentifier[]) policyIds.toArray(new TeamsNumberIdentifier[policyIds.size()]), false, securitySession);
					AssetServices.getInstance().unlockAssets(stringArray, securitySession);
//				}
				
			}
			
		} catch (NumberFormatException e) {
			e.printStackTrace();
			
		} catch (BaseTeamsException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * DynamicPolicy ����
	 * @param event
	 * @param securitySession
	 */
	public void delete(Event event, SecuritySession securitySession) {
		deleteGroup(event, securitySession);
		deleteSecurityPolicy(event, securitySession);
	}
	
	/*******************************************************************************************************************************************/
	//���̳��� �׷� ����
	private boolean deleteGroup(Event event, SecuritySession securitySession) {
		for(String group : contants.LGEConstatns.LGE_USER_GROUPS_PREFIX) 
		{
			String fullNm = group+event.getObjectId();
			try 
			{
				UserGroup [] groupIds = UserGroupServices.getInstance().retrieveUserGroupsByName(fullNm, securitySession);
				UserGroupServices.getInstance().lockUserGroup(groupIds[0].getId(), securitySession);
				UserGroupServices.getInstance().deleteUserGroup(groupIds[0].getId(), securitySession);
				UserGroupServices.getInstance().unlockUserGroup(groupIds[0].getId(), securitySession);
			} 
			catch (BaseTeamsException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		}	
		return true;
	}
	//���̳��� ��å ����
	private boolean deleteSecurityPolicy(Event event, SecuritySession securitySession) 
	{
		String securiyPolicy = LGEConstatns.DYNAMIC_SCURITY_PREFIX+event.getObjectId();
		SecurityPolicy [] scurityPolicy = null;
		try 
		{
			scurityPolicy = securityPolicyServices.retrieveSecurityPoliciesByName(securiyPolicy, securitySession);
			SecurityPolicyServices.getInstance().lockSecurityPolicy(scurityPolicy[0].getId(), securitySession);
			SecurityPolicyServices.getInstance().deleteSecurityPolicy(scurityPolicy[0].getId(), securitySession);
			SecurityPolicyServices.getInstance().unlockSecurityPolicy(scurityPolicy[0].getId(), securitySession);
			return true;
		} 
		catch (NumberFormatException | BaseTeamsException e)
		{
			e.printStackTrace();
			return false;
		}
//		finally {
//			try {
//				SecurityPolicyServices.getInstance().unlockSecurityPolicy(scurityPolicy[0].getId(), securitySession);
//			} catch (BaseTeamsException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
	}

	//�ű� �׷� ���� workflow 
	private TeamsNumberIdentifier createDynamicUserGroup(String groupName, SecuritySession session) throws BaseTeamsException {
		String parentId  = Utils.getSystemSetting(COMPONENT, KEY, LGEConstatns.DYNAMIC_PARENT_USER_GROUP_ID, session);
		TeamsNumberIdentifier parentUserGroupId = new TeamsNumberIdentifier(new Long(parentId));
		UserGroup userGroup = new UserGroup();
		userGroup.setName(groupName);
		return  userGroupServices.createUserGroup(parentUserGroupId, userGroup, session);
	}
}
