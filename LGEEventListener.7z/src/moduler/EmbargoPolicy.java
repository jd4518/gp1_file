package moduler;

import java.util.Set;

import com.artesia.asset.Asset;
import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.security.services.AssetSecurityServices;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.security.SecuritySession;

import common.EventListenerUtils;
import contants.LGEConstatns;
import utils.Utils;

public class EmbargoPolicy {
	
	AssetServices 			assetServices			= AssetServices.getInstance();
	AssetSecurityServices   assetSecurityServices   = AssetSecurityServices.getInstance();
	
	
	private static final EmbargoPolicy instance = new EmbargoPolicy();
	
	public static final EmbargoPolicy getInstance()
	{
	    return instance;
	}
	
	public void create(Asset asset, Set<String> interUsers, Set<String> exterUsers, Set<TeamsNumberIdentifier> policyIds, SecuritySession securitySession) throws BaseTeamsException {
		
//		securitySession = Utils.getLocalSession2();
		String adminGroupId = EventListenerUtils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.KEY_NAME, LGEConstatns.SYSTEM_ADMIN_GROUP_ID, securitySession);
		
		String interGroupName  	= LGEConstatns.DYNAMIC_USER_GROUP_INTERNAL_EMBARGO_PREFIX + asset.getAssetId();
		String exterGroupName  	= LGEConstatns.DYNAMIC_USER_GROUP_EXTERNAL_EMBARGO_PREFIX + asset.getAssetId();
		String policyName 		= LGEConstatns.DYNAMIC_SCURITY_EMBARGO_PREFIX+ asset.getAssetId();
		TeamsNumberIdentifier createdDynamicInterUserGroup 	= EventListenerUtils.createDynamicUserGroupEmbago(interGroupName, securitySession);
		TeamsNumberIdentifier createdDynamicExterUserGroup 	= EventListenerUtils.createDynamicUserGroupEmbago(exterGroupName, securitySession);
		TeamsNumberIdentifier createdDynamicPolicy 	  		= EventListenerUtils.createDynamicPolicy(policyName, securitySession);
		EventListenerUtils.updateScurityPermission(createdDynamicPolicy, createdDynamicInterUserGroup, securitySession, 2);
		EventListenerUtils.updateScurityPermission(createdDynamicPolicy, createdDynamicExterUserGroup, securitySession, 4);
		EventListenerUtils.updateScurityPermission(createdDynamicPolicy, new TeamsNumberIdentifier(new Long(adminGroupId)), securitySession, 1);
		if(interUsers.size() != 0) {
			EventListenerUtils.addUsersToGroup(interUsers, securitySession, interGroupName);
		}
		if(exterUsers.size() != 0) {
			EventListenerUtils.addUsersToGroup(exterUsers, securitySession, exterGroupName);
		}		
		policyIds.add(createdDynamicPolicy);
		
		try 
		{
			//Asset 湲곗〈 �젙梨� �궘�젣, �깉濡쒖슫 �젙梨� �븷�떦
			assetServices.lockAsset(asset.getAssetId(), securitySession);
			assetSecurityServices.assignSecurityPoliciesToAssets(new AssetIdentifier[]{asset.getAssetId()}, (TeamsNumberIdentifier[]) policyIds.toArray(new TeamsNumberIdentifier[policyIds.size()]), true, securitySession);
			assetServices.unlockAsset(asset.getAssetId(), securitySession);
		}
		finally 
		{
			assetServices.unlockAsset(asset.getAssetId(), securitySession);
		}
	}
	
//	private TeamsNumberIdentifier createDynamicUserGroupEmbago(String groupName, SecuritySession session) throws BaseTeamsException {
//		String parentId  = Utils.getSystemSetting(COMPONENT, KEY, LGEConstatns.DYNAMIC_PARENT_EMBARGO_USER_GROUP_ID, session);
//		
//		TeamsNumberIdentifier parentUserGroupId = new TeamsNumberIdentifier(new Long(parentId));
//		UserGroup userGroup = new UserGroup();
//		userGroup.setName(groupName);
//		return  userGroupServices.createUserGroup(parentUserGroupId, userGroup, session);
//	}
}
