/**
 * Create Setting group 
 */
declare
	@configGroupID bigint,
	@configurationGroupName varchar(100);
	
	set @configGroupId = 2000;
	set @configurationGroupName = 'LGE';
	
	delete from OTMM.OTMM_SYS_CONFIG_GROUPS where id = @configGroupID AND GROUP_NAME = @configurationGroupName;

insert into OTMM.OTMM_SYS_CONFIG_GROUPS (ID, GROUP_NAME, DESCRIPTION, IS_ENABLED, IS_READONLY) 
values (@configGroupID, @configurationGroupName, 'Configuration Group For MPIS custom settings', 'Y', 'N');


/**
 * Create OTDS GROUP ID setting
 */
declare
	@configGroupID bigint,
	@configComponentId bigint,
	@configComponentSettingId bigint,
	@configComponentName varchar(100),
	@keyName varchar(100),
	@settingName varchar(100),
	@settingValue varchar(100),
	@key varchar(100);

   	set @configComponentName = 'LGE';

   	set @configGroupID = 2000;   	
   	set @configComponentId = 3000;
	set @configComponentSettingId = 4000;
	
delete from OTMM.OTMM_SYS_CONFIG_COMPONENTS where id = @configComponentId AND COMPONENT_NAME = @configComponentName;
set @keyName = 'CONFIG';
insert into OTMM.OTMM_SYS_CONFIG_COMPONENTS (ID, GROUP_ID, COMPONENT_NAME, KEY_NAME, DESCRIPTION, IS_ENABLED, IS_READONLY) 
values (@configComponentId, @configGroupID, @configComponentName, @keyName, 'LGE CONFIG INFORMATION', 'Y', 'N' );

set @settingName = 'DEFAULT_SECURITY_POLICY';
set @settingValue = '';

insert into OTMM.OTMM_SYS_CONFIG_SETTINGS (ID, COMPONENT_ID, NAME, CONFIG_VALUE, DESCRIPTION, IS_PUBLIC, IS_CACHEABLE, IS_ENABLED, IS_READONLY, DATATYPE) 
values (@configComponentSettingId, @configComponentId, @settingName, @settingValue, 'DEFAULT_SECURITY_POLICY ID information', 'Y', 'N', 'Y', 'N', 'STRING');

set @settingName = 'DUMY_SECURITY_POLICY';
set @settingValue = '';

insert into OTMM.OTMM_SYS_CONFIG_SETTINGS (ID, COMPONENT_ID, NAME, CONFIG_VALUE, DESCRIPTION, IS_PUBLIC, IS_CACHEABLE, IS_ENABLED, IS_READONLY, DATATYPE) 
values (@configComponentSettingId, @configComponentId, @settingName, @settingValue, 'DUMY_SECURITY_POLICY ID information', 'Y', 'N', 'Y', 'N', 'STRING');

set @settingName = 'DUMY_USER_GROUP';
set @settingValue = '';

insert into OTMM.OTMM_SYS_CONFIG_SETTINGS (ID, COMPONENT_ID, NAME, CONFIG_VALUE, DESCRIPTION, IS_PUBLIC, IS_CACHEABLE, IS_ENABLED, IS_READONLY, DATATYPE) 
values (@configComponentSettingId, @configComponentId, @settingName, @settingValue, 'DUMY_USER_GROUP ID information', 'Y', 'N', 'Y', 'N', 'STRING');

set @settingName = 'EXTERNAL_GROUP';
set @settingValue = '';

insert into OTMM.OTMM_SYS_CONFIG_SETTINGS (ID, COMPONENT_ID, NAME, CONFIG_VALUE, DESCRIPTION, IS_PUBLIC, IS_CACHEABLE, IS_ENABLED, IS_READONLY, DATATYPE) 
values (@configComponentSettingId, @configComponentId, @settingName, @settingValue, 'EXTERNAL_GROUP ID information', 'Y', 'N', 'Y', 'N', 'STRING');

set @settingName = 'INTERNAL_GROUP';
set @settingValue = '';

insert into OTMM.OTMM_SYS_CONFIG_SETTINGS (ID, COMPONENT_ID, NAME, CONFIG_VALUE, DESCRIPTION, IS_PUBLIC, IS_CACHEABLE, IS_ENABLED, IS_READONLY, DATATYPE) 
values (@configComponentSettingId, @configComponentId, @settingName, @settingValue, 'INTERNAL_GROUP ID information', 'Y', 'N', 'Y', 'N', 'STRING');



