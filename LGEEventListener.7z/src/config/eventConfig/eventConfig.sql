
/**
 * 40007 user created
 * 51051 Rvjob create
 * 51061 Rvjob reopen
 * 51053 Rvjob complete
 * 51016 Rvjob add asset
 * 51058 Rvjob add user
 * 51059 Rvjob delete user
 * 51054 Rvjob delete 
 */
UPDATE OTMM.OTMM.EVENT_CTXTS
  SET IS_ENABLED_EXTERNAL = 'Y'
WHERE EVENT_ID  IN (10001,30006,40007,51051,51053,51054,51056,51057,51058,51059,51061,80008)
