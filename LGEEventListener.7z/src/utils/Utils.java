 package utils;

 import java.text.SimpleDateFormat;
 import java.util.Calendar;
 import java.util.Date;

 import org.apache.commons.logging.Log;
 import org.apache.commons.logging.LogFactory;

 import com.artesia.common.exception.BaseTeamsException;
 import com.artesia.common.prefs.PrefData;
 import com.artesia.common.prefs.PrefDataId;
 import com.artesia.security.SecuritySession;
 import com.artesia.security.session.services.AuthenticationServices;
 import com.artesia.security.session.services.LocalAuthenticationServices;
 import com.artesia.system.services.SystemServices;

 public class Utils {
	
	 private static final Log log = LogFactory.getLog(Utils.class);

	 public static String getSystemSetting(String componentName, String keyName, String settingName, SecuritySession session){
		
		 PrefDataId dataId = new PrefDataId(componentName, keyName, settingName);
		 PrefData retrievedData = null;
		 try 
		 {
			 retrievedData = SystemServices.getInstance().retrieveSystemSettingsByPrefDataId(dataId, session);
		 } 
		 catch (BaseTeamsException e)   
		 {
			 log.warn("An exception occured while fetching the system settings 13312121" );
		 }
		
		 return retrievedData == null ? "" : retrievedData.getValue();
	 }
	
//	public static SecuritySession getLocalSession(String userId)
//	{
//		SecuritySession localSession = null;
//		try 
//		{
//			localSession = LocalAuthenticationServices.getInstance().createLocalSession(userId);
//		} 
//		catch (BaseTeamsException e) 
//		{
//			return null;
//		}
//		return localSession;
//	}
	
	 public static SecuritySession getLocalSession()
	 {
		 SecuritySession securitySession = null;
	     try
	     {
	    	 securitySession = AuthenticationServices.getInstance().createInternalServerSession();
	     }
	     catch (BaseTeamsException e)
	     {
	    	 log.error("Cannot create local session.");
	     }
	     return securitySession;
	 }
	
//	 public static SecuritySession getLocalSession2() {
//
//		 SecuritySession securitySession = null;
//		 try {
//			 securitySession = AuthenticationServices.getInstance().login("tsuper", "mpis2@dev");
//		 } catch (BaseTeamsException e) {
//			// log.error("Cannot create local session.");
//		 }
//		 return securitySession;
//	 }
	 
	 public static SecuritySession getLocalSession2()
	  {
	    SecuritySession securitySession = null;
	    try
	    {
	      securitySession = LocalAuthenticationServices.getInstance().createLocalSession("tsuper");
	    }
	    catch (BaseTeamsException localBaseTeamsException) {}
	    return securitySession;
	  }
	
	 public static String getDate(int month) {
			Calendar cal = Calendar.getInstance();
		    cal.add(Calendar.MONTH, +month);
		    Date currentTime=cal.getTime();
		    SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd"); 
		    String release_Dt_start=formatter.format(currentTime);
		    return release_Dt_start;
	 }
 }
