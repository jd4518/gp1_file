package Legacy;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.Asset;
import com.artesia.content.ContentInfo;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.metadata.MetadataCollection;
import com.artesia.metadata.MetadataElement;
import com.artesia.metadata.MetadataTableField;
import com.artesia.metadata.MetadataValue;
import com.artesia.security.SecurityPolicy;
import com.artesia.security.SecuritySession;

import utils.Utils;
import contants.LGEConstatns;

public class Lgcom {
private static final Log LOGGER = LogFactory.getLog(Lgcom.class);
	
	String lgcom5Id;
	String [] arrLgcom5AllowContentTypes;
    String [] arrLgcom5AllowMimeTypes;
    String [] arrLgcom5AllowExtensions;
    String [] arrLgcom5AllowFileNames;
    
    String [] arrLgcom5DenyContentTypes;
    String [] arrLgcom5DenyMimeTypes;
    String [] arrLgcom5DenyExtensions;
    String [] arrLgcom5DenyFileNames;
    
    String [] arrLgcom5DenyMetaContentsType1s;
    String [] arrLgcom5DenyMetaContentsType2s;
    String publicshId;
    
    public String getLgcom5Id(){
    	return this.lgcom5Id;
    }
    
	public Lgcom(SecuritySession session) {
		
		//LG.COM5 nMPIS 권한 제어 기준 Settings
		this.lgcom5Id = Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.LG_COM5, LGEConstatns.LGCOM5_SECURITY_POLICY_ID, session);
		
		publicshId = Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.KEY_NAME, LGEConstatns.PUBLIC_SECURITY_POLICY_ID, session);
		
		String lgcom5AllowContentTypes = Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.LG_COM5, LGEConstatns.LG_COM5_ALLOW_CONTENT_TYPES, session);
        String lgcom5AllowMimeTypes = Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.LG_COM5, LGEConstatns.LG_COM5_ALLOW_MIME_TYPE, session);
        String lgcom5AllowExtensions = Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.LG_COM5, LGEConstatns.LG_COM5_ALLOW_EXTENSIONS, session);
        String lgcom5AllowFileNames = Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.LG_COM5, LGEConstatns.LG_COM5_ALLOW_FILENAMES, session);
        
        String lgcom5DenyContentTypes = Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.LG_COM5, LGEConstatns.LG_COM5_DENY_CONTENT_TYPES, session);
        String lgcom5DenyMimeTypes = Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.LG_COM5, LGEConstatns.LG_COM5_DENY_MIME_TYPE, session);
        String lgcom5DenyExtensions = Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.LG_COM5, LGEConstatns.LG_COM5_DENY_EXTENSIONS, session);
        String lgcom5DenyFileNames = Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.LG_COM5, LGEConstatns.LG_COM5_DENY_FILENAMES, session);
        String lgcom5DenyMetaContentsType1s = Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.LG_COM5, LGEConstatns.LG_COM5_DENY_META_CONTENTS_TYPE1, session);
        String lgcom5DenyMetaContentsType2s = Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.LG_COM5, LGEConstatns.LG_COM5_DENY_META_CONTENTS_TYPE2, session);
        
        this.arrLgcom5AllowContentTypes = lgcom5AllowContentTypes.split(",");
        this.arrLgcom5AllowMimeTypes = lgcom5AllowMimeTypes.split(",");
        this.arrLgcom5AllowExtensions = lgcom5AllowExtensions.split(",");
        this.arrLgcom5AllowFileNames = lgcom5AllowFileNames.split(",");
        
        this.arrLgcom5DenyContentTypes = lgcom5DenyContentTypes.split(",");
        this.arrLgcom5DenyMimeTypes = lgcom5DenyMimeTypes.split(",");
        this.arrLgcom5DenyExtensions = lgcom5DenyExtensions.split(",");
        this.arrLgcom5DenyFileNames = lgcom5DenyFileNames.split(",");
        
        this.arrLgcom5DenyMetaContentsType1s = lgcom5DenyMetaContentsType1s.split(",");
        this.arrLgcom5DenyMetaContentsType2s = lgcom5DenyMetaContentsType2s.split(",");
	}
	
	public boolean isLgcom5Policy(Asset asset) {
		LOGGER.info("================ Lgcom isLgcom5Policy Start =================");
		/*
		 * Black list 먼저 처리 후 White List를 처리함
		 * 순서 : FileName, 확장자, MIME_TYPE, CONTENT TYPE
		 * 
		 * */
		LOGGER.info("================ asset.getContentType() =================: " + asset.getContentType());
		
		ContentInfo assetMasterContentInfo = asset.getMasterContentInfo();
//		LOGGER.info("================ assetContentInfo.getContentKind() =================: " + assetMasterContentInfo.getContentKind());
//		LOGGER.info("================ assetContentInfo.getMimeType() =================: " + assetMasterContentInfo.getMimeType());
//		LOGGER.info("================ assetContentInfo.getName() =================: " + assetMasterContentInfo.getName());
		if(assetMasterContentInfo != null)
		{
			String assstContentFileName = assetMasterContentInfo.getName();
			LOGGER.info("================ assstContentFileName =================: " + assstContentFileName);
			//-----------------------METADATA CONTENT TYPE
			// CONTENT TYPE 확인 - Black list
			MetadataCollection metadataCollection = asset.getMetadata();
			MetadataElement metadataCT1Element 		= metadataCollection.findElementById(new TeamsIdentifier("CONTENTTYPE1"));
			if(metadataCT1Element != null) {
				MetadataValue[] metadataCT1Values = ((MetadataTableField)metadataCT1Element).getValues();
				MetadataElement metadataCT2Element 		= metadataCollection.findElementById(new TeamsIdentifier("CONTENTTYPE2"));
				if(metadataCT2Element != null) {
					MetadataValue[] metadataCT2Values = ((MetadataTableField)metadataCT2Element).getValues();
					for (MetadataValue aCT1Value : metadataCT1Values)
					{
						for (String lgcom5DenyMetaContentsType1 : arrLgcom5DenyMetaContentsType1s) {
							if(lgcom5DenyMetaContentsType1.equals(aCT1Value.getStringValue())) {
								for (MetadataValue aCT2Value : metadataCT2Values) {
									for (String lgcom5DenyMetaContentsType2 : arrLgcom5DenyMetaContentsType2s) {
										if(lgcom5DenyMetaContentsType2.equals(aCT2Value.getStringValue())) {
											LOGGER.info("================ lgcom5Deny METADATA CONTENT TYPE =================: " + lgcom5DenyMetaContentsType1 + ", " + lgcom5DenyMetaContentsType2);
											return false;
										}
									}
								}
							}
						}
					}	
				}
			}

			//-----------------------File Name
			//FileName으로 Black List 확인
			for (String lgcom5DenyFileName : arrLgcom5DenyFileNames) {
				
				if(lgcom5DenyFileName.toLowerCase().equals(assstContentFileName)) {
					LOGGER.info("================ lgcom5DenyFileName =================: " + lgcom5DenyFileName);
					return false;
				}
			}
			//FileName으로 White List 확인
			for (String lgcom5AllowFileName : arrLgcom5AllowFileNames) {
				if(lgcom5AllowFileName.toLowerCase().equals(assstContentFileName)) {
					LOGGER.info("================ lgcom5AllowFileName =================: " + lgcom5AllowFileName);
					return true;
				}
			}		
			//-----------------------확장자 
			//확장자 수집
			String assstContentFileExt = "";
			int iLastIdx = assstContentFileName.lastIndexOf(".");
			if(iLastIdx > -1) {
				assstContentFileExt = assstContentFileName.substring(iLastIdx+1, assstContentFileName.length());
			}
			//확장자 Black List 확인
			for (String lgcom5DenyExtension : arrLgcom5DenyExtensions) {
				if(lgcom5DenyExtension.toLowerCase().equals(assstContentFileExt)) {
					LOGGER.info("================ lgcom5DenyExtension =================: " + lgcom5DenyExtension);
					return false;
				}
			}
			//확장자 White List 확인
			for (String lgcom5AllowExtension : arrLgcom5AllowExtensions) {
				if(lgcom5AllowExtension.toLowerCase().equals(assstContentFileExt)) {
					LOGGER.info("================ lgcom5AllowFileName =================: " + lgcom5AllowExtension);
					return true;
				}
			}
			
			//-----------------------MIME TYPE
			//MIME TYPE  Black List 확인
			String assstMimeType = assetMasterContentInfo.getMimeType();
			for (String lgcom5DenyMimeType : arrLgcom5DenyMimeTypes) {
				if(lgcom5DenyMimeType.equals(assstMimeType)) {
					LOGGER.info("================ lgcom5DenyMimeType =================: " + lgcom5DenyMimeType);
					return false;
				}
			}
			//MIME TYPE  White List 확인
			for (String lgcom5AllowMimeType : arrLgcom5AllowMimeTypes) {
				if(lgcom5AllowMimeType.equals(assstMimeType)) {
					LOGGER.info("================ lgcom5AllowFileName =================: " + lgcom5AllowMimeType);
					return true;
				}
			}
			
			//-----------------------FILE CONTENT TYPE
			// CONTENT TYPE 확인 - Black list
			String assetContentType = asset.getContentType();
			for (String lgcom5DenyContentType : arrLgcom5DenyContentTypes) {
				if(lgcom5DenyContentType.equals(assetContentType)) {
					LOGGER.info("================ lgcom5DenyContentType =================: " + lgcom5DenyContentType);
					return false;
				}
			}
			// CONTENT TYPE 확인 - White list
			for (String lgcom5AllowContentType : arrLgcom5AllowContentTypes) {
				if(lgcom5AllowContentType.equals(assetContentType)) {
					LOGGER.info("================ lgcom5AllowFileName =================: " + lgcom5AllowContentType);
					return true;
				}
			}
		}		
		LOGGER.info("================ Lgcom isLgcom5Policy End =================");
		return false;
	}

}
