package contants;

public class LGEEventConstans {
	
	public static final String ADMIN_USER_ID 		= "tsuper";
	
	public static final String CLIENT_ID	 		= "LGE";
	
	public static final String DELETE_ASSET_ID      = "30006";
	
	public static final String CREATE_USER_ID       = "40007";
	
	public static final String RVJOB_CREATED_ID 	= "51051";	
	
	public static final String RVJOB_REOPEN_ID  	= "51061";
	
	public static final String RVJOB_COMPLETE_ID 	= "51053";
	
	public static final String RVJOB_ADD_ASSET_ID 	= "51056";
	
	public static final String RVJOB_ADD_USER_ID 	= "51058";
	
	public static final String RVJOB_DELETE_USER_ID = "51059";
	
	public static final String RVJOB_DELETED_ID 	= "51054";
	
	public static final String RVJOB_UPDATED_ID 	= "51055";
	
	public static final String RVJOB_STARTED_ID 	= "51052";
	
	public static final String RVJOB_ASSET_REMOVE_ID= "51057";
	
	public static final String METADATA_UPDATE_ID	= "80008";
	
	public static final String ASSET_CHECK_IN		= "10001";
	
	public static final String USER_LOGIN_ID		= "40009";
	
	public static final String USER_DELETE_ID		= "30007";
	
	/* JOB EVENT - e */
	
	public static final String ASSET_IMPORT_END 	= "2229148";
	
	
	
	public static final String ASSET_MOVE_ID 			= "8002";
	
	public static final String RVJOB_TASK_COMPLETE_ID 	= "51074";
	
	public static final String RVJOB_TASK_STARTED_ID 	= "51069";
	
	
}	
