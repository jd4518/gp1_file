package contants;

import com.artesia.entity.TeamsIdentifier;

public class LGEConstatns {
	public static final String ADMIN_ID	 									= "tsuper";
	
	public static final String COMPONENT_NAME 								= "LGE";
	
	public static final String KEY_NAME       								= "CONFIG";
	
	public static final String [] LGE_USER_GROUPS_PREFIX 					= {"LGE_DYNAMIC_INTERNAL_GROUP_", "LGE_DYNAMIC_EXTERNAL_GROUP_"};
		
	public static final String DYNAMIC_SCURITY_PREFIX 	  					= "LGE_DYNAMIC_POLICY_";	
	
	public static final String DYNAMIC_SCURITY_ALLOW_TO_PREFIX 				= "LGE_DYNAMIC_ALLOW_TO_POLICY_";
	
	public static final String DYNAMIC_SCURITY_EMBARGO_PREFIX 				= "LGE_DYNAMIC_EMBARGO_POLICY_";	
	
	public static final String DYNAMIC_USER_GROUP_ALLOW_TO_PREFIX 			= "LGE_DYNAMIC_ALLOW_TO_GROUP_";
	
	public static final String DYNAMIC_USER_GROUP_INTERNAL_EMBARGO_PREFIX 	= "LGE_DYNAMIC_INTERNAL_EMBARGO_GROUP_";
	
	public static final String DYNAMIC_USER_GROUP_EXTERNAL_EMBARGO_PREFIX 	= "LGE_DYNAMIC_EXTERNAL_EMBARGO_GROUP_";
	
	public static final String DYNAMIC_PARENT_USER_GROUP_ID 				= "DYNAMIC_PARENT_USER_GROUP_ID";		
	
	public static final String DYNAMIC_PARENT_ALLOWTO_USER_GROUP_ID 		= "DYNAMIC_PARENT_ALLOWTO_USER_GROUP_ID";
	
	public static final String DYNAMIC_PARENT_EMBARGO_USER_GROUP_ID 		= "DYNAMIC_PARENT_EMBARGO_USER_GROUP_ID";
	
	public static final String PUBLIC_SECURITY_POLICY_ID 					= "PUBLIC_SECURITY_POLICY_ID";
	
	public static final String DUMY_SECURITY_POLICY_ID 						= "DUMY_SECURITY_POLICY_ID";
	
	public static final String SYSTEM_ADMIN_GROUP_ID 						= "SYSTEM_ADMIN_GROUP_ID";
	
	public static final String DYNAMIC_ADMIN_GROUP_ID 						= "ADMIN_GROUP_ID";			
	
	public static final String VALUE_INTERNAL_ID 							= "INTERNAL_GROUP_ID";
	
	public static final String VALUE_EXTERNAL_ID 							= "EXTERNAL_GROUP_ID";
	
	public static final String JOB_HIERARCHY_POLICY_ID 						= "JOB_HIERARCHY_POLICY_ID";
	
	public static final TeamsIdentifier ALLOW_TO_USER_ACCESS_FIELD_ID		= new TeamsIdentifier("ALLOWTO_AGENCY");
	
	public static final TeamsIdentifier EMBARGO_DATE_FIELD_ID 				= new TeamsIdentifier("ARTESIA.FIELD.EMBARGO DATE");
	
	public static final TeamsIdentifier EMBARGO_USER_ACCESS_FIELD_ID		= new TeamsIdentifier("EMBARGO_USER");
	
	public static final TeamsIdentifier ASSET_COMPLETE_YN					= new TeamsIdentifier("LGE.FIELD.COMPLETE.YN");
	
	public static final TeamsIdentifier ASSET_OWNER_ID						= new TeamsIdentifier("LGE.FIELD.OWNER");
	
	public static final TeamsIdentifier FOLDER_PATH_ID						= new TeamsIdentifier("FOLDER_PATH");
	
	public static final TeamsIdentifier CHECKVAL							= new TeamsIdentifier("LGE.FIELD.CHECKVAL");
	
	
	
	
	public static final String FROM_EMAIL									= "nmpis@lge.com";
	
	//public static final String DYNAMIC_SECURITY_POLICY_ID 					= "DYNAMIC_SECURITY_POLICY_ID";
	
	//public static final String ALLOW_TO_METAFIELD_ID 						= "LGE.MODEL.USER.LIST";
	
	//public static final String BASE_METAFIELD_ID 							= "ARTESIA.MODEL.DEFAULT";
	
	//public static final String EMBAGO_METAFIELD_ID 							= "LGE.MODEL.EMBAGO.DEFAULT";
	//	public static final TeamsIdentifier EMBARGO_USER_ACCESS_FIELD_ID		= new TeamsIdentifier("LGE.FIELD.EMBARGO ASSET ACCESS USERS");
	//	public static final TeamsIdentifier ALLOW_TO_USER_ACCESS_FIELD_ID		= new TeamsIdentifier("LGE.FIELD.ALLOWTO ASSET ACCESS USERS1");
	//	public static final TeamsIdentifier ASSET_FOLDER_FIELD_ID				= new TeamsIdentifier("LGE.FIELD.FOLDER ASSET ACCESS");
	
	
	
	
	/*************************************************************************************************/
	//setting value - default policy id 
	public static final String VALUE_DEFAULT_SECURITY_ID 		= "DEFAULT_SECURITY_POLICY";	
	//setting value - default policy id
	public static final String VALUE_DUMY_SECURITY_POLICY_ID 	= "DUMY_SECURITY_POLICY";
	
	public static final String VALUE_DUMY_USER_GROUP_ID 		= "DUMY_USER_GROUP";
		
	public static final String DYNAMIC_SCURITY_POLICY 			= "LGE_DYNAMIC_POLICY_";		
	
	public static final String [] LGE_GROUP 					= {"LGE_IN_GROUP_", "LGE_EX_GROUP_"};
	
	public static final TeamsIdentifier ALLOW_TO_USER_METAFIELD_ID  = new TeamsIdentifier("ALLOWTO.USER");
	
	
	/*************************************************************************************************/
	/******************************************* LG.COM ******************************************************/
	public static final String LG_COM5_WCMS_SECURITY_POLICY					= "LGE_LG.COM5_WCMS_POLICY";
	
	public static final String LG_COM5										= "LGCOM5";
	
	public static final String LG_COM5_ALLOW_CONTENT_TYPES					= "ALLOW_CONTENT_TYPES";
	
	public static final String LG_COM5_ALLOW_MIME_TYPE						= "ALLOW_MIME_TYPE";
	
	public static final String LG_COM5_ALLOW_EXTENSIONS						= "ALLOW_EXTENSIONS";
	
	public static final String LG_COM5_ALLOW_FILENAMES						= "ALLOW_FILENAMES";
	
	public static final String LG_COM5_DENY_CONTENT_TYPES					= "DENY_CONTENT_TYPES";
	
	public static final String LG_COM5_DENY_MIME_TYPE						= "DENY_MIME_TYPE";
	
	public static final String LG_COM5_DENY_EXTENSIONS						= "DENY_EXTENSIONS";
	
	public static final String LG_COM5_DENY_FILENAMES						= "DENY_FILENAMES";
	
	public static final String LG_COM5_DENY_META_CONTENTS_TYPE1				= "DENY_METADATA_CONTENETS_TYPE1";
	
	public static final String LG_COM5_DENY_META_CONTENTS_TYPE2				= "DENY_METADATA_CONTENETS_TYPE2";
	
	public static final String LGCOM5_SECURITY_POLICY_ID 					= "LGCOM5_SECURITY_POLICY_ID";
	
	/******************************************* LG.COM ******************************************************/
}
