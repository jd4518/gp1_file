package dbConfig;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import javax.naming.NamingException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import ttsg_teams.admin.db.DBMgr;
import ttsg_teams.common.common.TeamsException;

public class DbConnection {
	
	private static final Log logger = LogFactory.getLog(DbConnection.class); 
	
	static ResultSet queryResult = null;
	static Connection connection = null;
	static PreparedStatement preparedStatement = null;
	
	public static ResultSet executeQuery(String query, Map<String, String> article) throws NamingException{
		int index = 1;
		
		try {
			DBMgr db = new DBMgr();
			connection = db.openDatabase();
			preparedStatement = connection.prepareStatement(query);
			if(article != null) {
				for(String key :  article.keySet()){
					preparedStatement.setString(index, article.get(key).toString());
					index++;
				}
			}
			queryResult = preparedStatement.executeQuery();
		} catch (TeamsException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return queryResult;
	}
	
	
	public static ResultSet selectQuery(String query,  Map<String, String> params) throws TeamsException, SQLException {
		DBMgr db = new DBMgr();
		connection = db.openDatabase();
		int index = 1;
		
		preparedStatement = connection.prepareStatement(query);
		if(params != null) {
			for(String key :  params.keySet()){
				preparedStatement.setString(index, params.get(key).toString());
				index++;
			}
		}
		queryResult = preparedStatement.executeQuery();
		return queryResult;
	}
	
	
	public static int updateQuery(String query,  Map<String, String> params) throws TeamsException, SQLException {
		int  status = 0;
		DBMgr db = new DBMgr();
		connection = db.openDatabase();	
		int index = 1;
		try {
			preparedStatement = connection.prepareStatement(query);
			if(params != null) {
				for(String key :  params.keySet()){
					preparedStatement.setString(index, params.get(key).toString());
					index++;
				}
			}
			status = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			System.out.println("========================" + e.getErrorCode() + e.getMessage());
			e.printStackTrace();
		}		
		return status;
	}
	
	public static void sqlClose() 
	{
		try
		{
			System.out.println("sqlClose : " + queryResult +"   " + connection + "   " + preparedStatement);
			if(queryResult != null) {
				queryResult.close();
			}
			if(connection != null) {
				connection.close();
			}
			if(preparedStatement != null) {
				preparedStatement.close();
			}
		}catch(SQLException e)
		{
			System.out.println("Sql Error : " + e.getMessage());
		}
		
	}
}
