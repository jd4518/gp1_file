package mailUtils;

import java.util.Map;

import ttsg_teams.common.common.TForwardEmail;

public class sendMailApi {
	
	public static void sendMail(Map<String, String> map) {
		
		TForwardEmail fEmail = new TForwardEmail();
		fEmail.setDestination(map.get("toAddress"));
//	    fEmail.setCCDestination(ccAddress);
//	    fEmail.setReplyToDestination(replyToAddr);
	    fEmail.setFrom(map.get("fromAddress"));
	    fEmail.setSubject(map.get("subject"));
	    fEmail.setBody(map.get("body"));
	    fEmail.setServer(map.get("serverName"));
	    fEmail.send();
	}
	
}
