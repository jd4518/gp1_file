package eventHandler;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.event.Event;
import com.artesia.security.SecuritySession;

public class UserLoginHandler extends AbstractEventHandler{
	private static final Log logger = LogFactory.getLog(UserLoginHandler.class);
	@Override
	void handleEvent(Event event, SecuritySession securitySession) {
		// TODO Auto-generated method stub
		System.out.println("==================== UserLoginHandler ======================");
		if(!event.getObjectId().equals("1001") && !event.getObjectId().equals("TSERVER")) 
		{
			System.out.println(event.getObjectType());
			if(event.getObjectType().equals("USER"))
			{
				System.out.println("================ start");
				StringBuffer sql = new StringBuffer();
				sql.append(" MERGE  OTMM.LGE_MPIS_EVENT_LOG_CT 				\n");
				sql.append(" USING  (SELECT 'X' AS DUAL) AS B   			\n");
				sql.append("    ON  USER_ID = '"+event.getObjectId()+"'   	\n");
				sql.append("  WHEN  MATCHED THEN    						\n");
				sql.append("UPDATE  SET EVENT_DATE = GETDATE()   			\n");
				sql.append("  WHEN  NOT MATCHED THEN   						\n");
				sql.append("INSERT  (USER_ID, EVENT_TYPE, CLIENT_IP) VALUES('"+event.getObjectId()+"', 'LOGIN','"+event.getData()[0].getValue()+"'); \n");
				

				
				StringBuffer sql2 = new StringBuffer();
				sql2.append("INSERT INTO OTMM.LGE_MPIS_EVENT_LOG_TRG_CT 								\n");
				sql2.append("(USER_ID, EVENT_TYPE, CLIENT_IP)VALUES 									\n");
				sql2.append("('"+event.getObjectId()+"', 'LOGIN', '"+event.getData()[0].getValue()+"') 	\n");

//				try 
//				{		
//					int result;
//					try {
//						result = DbConnection.updateQuery(sql.toString(), null);
//						if(result == 1 )
//						{
//							DbConnection.updateQuery(sql2.toString(), null);
//						}						
//					} catch (SQLException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}finally {
//						DbConnection.sqlClose();
//					}
//					
//								
//				} catch (TeamsException e) {
//					logger.info("============ UserLoginHandler error : " + e.getMessage());
//					e.printStackTrace();
//				}
			}
		}		
	}
}
