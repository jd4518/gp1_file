package eventHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.artesia.common.NameValue;
import com.artesia.event.Event;
import com.artesia.security.SecuritySession;

import ttsg_teams.admin.db.DBMgr;
import ttsg_teams.common.common.TeamsException;

/**
 * OTDS에서 사용자 메일 변경시 호출 Handler
 * @author chungkyu1.lee
 *
 */
public class UpdateUserHandler extends AbstractEventHandler{

	@Override
	void handleEvent(Event event, SecuritySession securitySession) {
		// TODO Auto-generated method stub
		NameValue [] values = event.getData();
		StringBuffer sql = new StringBuffer();
		sql.append("UPDATE OTMM.OTMM.LGE_MPIS_USER_MANAGERMENT_CT 									\n");
		sql.append("   SET EMAIL_ADDR 	= '"+values[1].getValue()+"'								\n");
		sql.append(" WHERE USER_ID 		= '"+event.getObjectId()+"'									\n");
		
		try {
			Connection connection = null;
			PreparedStatement preparedStatement = null;				
			try
			{
				try {
					DBMgr db = new DBMgr();
					connection = db.openDatabase();
					preparedStatement = connection.prepareStatement(sql.toString());
					preparedStatement.executeUpdate();
				} catch (TeamsException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				
			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} 
}
