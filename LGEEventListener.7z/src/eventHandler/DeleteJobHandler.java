package eventHandler;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.Asset;
import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.security.services.AssetSecurityServices;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.event.Event;
import com.artesia.metadata.MetadataCollection;
import com.artesia.metadata.MetadataElement;
import com.artesia.metadata.MetadataField;
import com.artesia.metadata.MetadataValue;
import com.artesia.reviewjob.ReviewJob;
import com.artesia.reviewjob.ReviewJobConstants.PARTICIPANT_RETRIEVAL;
import com.artesia.reviewjob.services.ReviewJobServices;
import com.artesia.security.SecurityPolicy;
import com.artesia.security.SecuritySession;

import common.EventListenerUtils;
import contants.LGEConstatns;

/*
* ---------------------------------------------------------------------------------------
* PROJ    :   New Marketing Product Information_LGE
* NAME    :   DeleteJobHandler.java
* DESC    :   reviewToJob -> remove Asset 이벤트
* Author  :   양창덕
* VER     :   v1.0
* Copyright 2019 LG CNS All right reserved
* ---------------------------------------------------------------------------------------
*                       변             경           사          항
* ---------------------------------------------------------------------------------------
*       DATE       AUTHOR                                  DESCRIPTION
*  ------------ -----------  ------------------------------------------------------------
*   2019.08.20    양창덕            로직변경으로 Delete job시 다이나믹 정책 삭제
* ---------------------------------------------------------------------------------------
*/
public class DeleteJobHandler extends AbstractEventHandler{
	
	private static final Log logger = LogFactory.getLog(DeleteJobHandler.class);
	
	@Override
	void handleEvent(Event event, SecuritySession securitySession) {	
		try 
		{ 
			logger.info("================= DeleteJobHandler START =================" + event.getObjectId());
			String dumyPolicyId   		= EventListenerUtils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.KEY_NAME, LGEConstatns.DUMY_SECURITY_POLICY_ID, securitySession);  
			SecurityPolicy[] dynamicId 	= EventListenerUtils.getSecurityPolicys(LGEConstatns.DYNAMIC_SCURITY_POLICY+event.getObjectId(), securitySession);
			List<AssetIdentifier> alist = EventListenerUtils.getRvjobToAssets(new TeamsIdentifier(event.getObjectId()), securitySession);
			
			logger.info("================= DYNAMIC POLICY SIZE =================" + dynamicId.length);
			
			for(AssetIdentifier id : alist)
			{
				Asset asset = EventListenerUtils.getAssetInfo(id, securitySession);

				boolean anotherJobFlag = false; 
				//Asset에 다른 Dynamic 정책이 있는 경우 체크
				for(SecurityPolicy policy : asset.getSecurityPolicyList())
				{
					if(policy.getName().contains("LGE_DYNAMIC_POLICY"))
					{
						if(dynamicId.length > 0)
						{
							if(!policy.getId().toString().equals(dynamicId[0].getId().toString())) 
							{
								anotherJobFlag = true;
								break;
							}
						}						
					}
				}
				logger.info("================= anotherJobFlag =================" + anotherJobFlag);
				
				MetadataCollection metadataCollection 	= asset.getMetadata();					
				MetadataElement checkValElement	 		= metadataCollection.findElementById(new TeamsIdentifier("LGE.FIELD.CHECKVAL"));
				MetadataElement approvalElement 		= metadataCollection.findElementById(new TeamsIdentifier("ARTESIA.FIELD.LIFECYCLE APPROVAL STATE"));
				MetadataValue checkValue				= checkValElement == null ? null : ((MetadataField)checkValElement).getValue();
				MetadataValue approval					= approvalElement == null ? null : ((MetadataField)approvalElement).getValue();
				//폴더에서 생성된 Asset 체크
				if(checkValue != null && !checkValue.isNullValue() && checkValue.getStringValue().equals("Y")) 	anotherJobFlag = true;

				//Completed된 Asset 체크
				if(approval != null && !approval.isNullValue() && approval.getStringValue().toUpperCase().equals("APPROVED")) anotherJobFlag = true;
					
				//해당 조건에 만족하지 않는 경우 job에서 생성된 Asset이며, 추가적인 job에 할당된 Asset이 아니고, Completed된 기록이 없으므로 dumy 정책 부여
				if(!anotherJobFlag)
				{
					AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);
					AssetServices.getInstance().lockAsset(asset.getAssetId(), securitySession);
					AssetSecurityServices.getInstance().assignSecurityPoliciesToAssets(asset.getAssetId().asAssetIdArray(), new TeamsNumberIdentifier[] {new TeamsNumberIdentifier(Long.parseLong(dumyPolicyId))}, true, securitySession);
					AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);
				}
			}		
		} 
		catch (BaseTeamsException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				//job이 Completed가 되면 정책이 삭제되므로 체크
				ReviewJob job = ReviewJobServices.getInstance().retrieveReviewJobById(new TeamsIdentifier(event.getObjectId()), PARTICIPANT_RETRIEVAL.ALL, false, false, securitySession);
				if(job != null) {
					EventListenerUtils.deleteDynamicGroup(event.getObjectId(), securitySession);
					EventListenerUtils.deleteDynamicPolicy(event.getObjectId(), securitySession);
				}	
			} catch (BaseTeamsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//Completejob 이 된 상태인지 확인 후 Complete가 안됬다면 그룹 및 정책 삭제(Complete job시 그룹 및 정책을 삭제하기 때문에) 			
		}
		
		logger.info("================= DeleteJobHandler END =================" + event.getObjectId());
	}
}
