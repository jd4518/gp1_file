package eventHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.event.Event;
import com.artesia.reviewjob.ReviewJob;
import com.artesia.reviewjob.ReviewJobConstants.PARTICIPANT_RETRIEVAL;
import com.artesia.reviewjob.services.ReviewJobServices;
import com.artesia.security.SecuritySession;

import moduler.DynamicPolicy;
import ttsg_teams.admin.db.DBMgr;
import ttsg_teams.common.common.TeamsException;


public class CreateRvJobHandler extends AbstractEventHandler{
	
	private static final Log logger = LogFactory.getLog(CreateRvJobHandler.class);

	@Override
	void handleEvent(Event event, SecuritySession securitySession) {
		boolean assign = false;
		DynamicPolicy.getInstance().create(event, securitySession, assign);
		
		/*********************************************************************************************************/					
		PARTICIPANT_RETRIEVAL participantRetrievalFlag = null;
		ReviewJob rv = null;
		try {
			rv = ReviewJobServices.getInstance().retrieveReviewJobById(new TeamsIdentifier(event.getObjectId()), participantRetrievalFlag, false, false, securitySession);
		} catch (BaseTeamsException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		TeamsIdentifier parentId = rv.getFolderId();
		
		String id 		= event.getObjectId();
		String folderId = parentId.toString();
		StringBuffer query = new StringBuffer();
		query.append("INSERT INTO OTMM.LGE_MPIS_RVJOBS_CT(ID, FOLDER_ID) \n");
		query.append("VALUES( \n");
		query.append("'"+id+"'");
		query.append(",'"+folderId+"'");
		query.append(")");
		logger.info("query LGE_MPIS_RVJOBS_CT : " + query.toString());
		
		try {
			try {
//				DbConnection.updateQuery(query.toString(), null);
				Connection connection = null;
				PreparedStatement preparedStatement = null;				
				try
				{
					DBMgr db = new DBMgr();
					connection = db.openDatabase();
					preparedStatement = connection.prepareStatement(query.toString());
					preparedStatement.executeUpdate();	
				}
				finally
				{
					if(connection != null)  connection.close();
					if(preparedStatement != null) preparedStatement.close();
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (TeamsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*********************************************************************************************************/
	}
}
