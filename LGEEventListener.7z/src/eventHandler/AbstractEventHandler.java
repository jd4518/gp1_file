package eventHandler;

import com.artesia.event.Event;
import com.artesia.security.SecuritySession;

public abstract class AbstractEventHandler {   
	
	abstract void handleEvent(Event event, SecuritySession securitySession);
}
