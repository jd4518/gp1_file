package eventHandler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.Asset;
import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.security.services.AssetSecurityServices;
import com.artesia.asset.services.AssetDataLoadRequest;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.NameValue;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.event.Event;
import com.artesia.metadata.MetadataCollection;
import com.artesia.metadata.MetadataElement;
import com.artesia.metadata.MetadataField;
import com.artesia.metadata.MetadataTableField;
import com.artesia.metadata.MetadataValue;
import com.artesia.reviewjob.ReviewJob;
import com.artesia.security.SecurityPolicy;
import com.artesia.security.SecuritySession;
import com.artesia.security.UserGroup;
import com.artesia.security.services.SecurityPolicyServices;
import com.artesia.security.services.UserGroupServices;
import com.artesia.user.TeamsUser;

import Legacy.Lgcom;
import common.EventListenerUtils;
import contants.LGEConstatns;
import moduler.EmbargoPolicy;

/*
* ---------------------------------------------------------------------------------------
* PROJ    :   New Marketing Product Information_LGE
* NAME    :   AssetToEditHandler.java
* DESC    :   Asset Metadata 변경
* Author  :   양창덕
* VER     :   v1.0
* Copyright 2019 LG CNS All right reserved
* ---------------------------------------------------------------------------------------
*                       변             경           사          항
* ---------------------------------------------------------------------------------------
*       DATE       AUTHOR                                  DESCRIPTION
*  ------------ -----------  ------------------------------------------------------------
*   2019.08.20    양창덕            불필요한 로그 삭제
* ---------------------------------------------------------------------------------------
*/

public class AssetToEditHandler extends AbstractEventHandler{
	UserGroupServices 		userGroupServices 		= UserGroupServices.getInstance();
	SecurityPolicyServices 	securityPolicyServices 	= SecurityPolicyServices.getInstance();
	AssetServices 			assetServices			= AssetServices.getInstance();
	AssetSecurityServices   assetSecurityServices   = AssetSecurityServices.getInstance();
	
	private static final Log logger = LogFactory.getLog(AssetToEditHandler.class);
	
	@Override 
	void handleEvent(Event event, SecuritySession securitySession) 
	{
		logger.info("================= AssetToEditHandler START =================" + event.getObjectId());
		NameValue[] values = event.getData();		
		boolean updatePolicy 		= false;
		boolean updateContent	 	= false;
		
		//Edit 체크 
		for(NameValue value : values)
		{			
			if(value.getValue().equals("EMBARGO_USER") || value.getValue().equals("ALLOWTO_AGENCY") || value.getValue().equals("ARTESIA.FIELD.EMBARGO DATE"))
			{
				updatePolicy = true;
				break;
			}
			//CONTENT_TYPE가 변경이 된 경우에만  
			else if(value.getValue().equals("CONTENTTYPE1") || value.getValue().equals("CONTENTTYPE2"))
			{
				updateContent = true;
				break;
			}
		}
		logger.info("Edit Status Check");
		logger.info("====== updatePolicy ====== :" + updatePolicy + "====== updateContent ====== " + updateContent);

		AssetDataLoadRequest dataRequest 	= new AssetDataLoadRequest();
		dataRequest.setLoadMetadata(true);
		dataRequest.setLoadMetadataByModel(true);
		dataRequest.setLoadSecurityPolicies(true);
		dataRequest.setLoadAssetContentInfo(true);
		dataRequest.setLoadAssetContentWithText(true);
		dataRequest.setLoadMacResourceInfo(true);
		dataRequest.setLoadVocabularyTerms(true);
		//AssetIdentifier AssetId 정보 조회
		Asset asset = null;
		Lgcom lgcom5 = new Lgcom(securitySession);
		Set<TeamsNumberIdentifier> policyIds = new HashSet<TeamsNumberIdentifier>();
		try {
			//Asset 최신버전의 UOI_ID 조회
			asset = EventListenerUtils.getAssetInfoLast(new AssetIdentifier(event.getObjectId()), securitySession);
			//CONTENT_TYPE만 변경된 경우 실행
			if(updateContent)
			{				
				logger.info("=== updateContent / LGCOM5 Start === ");
				if(updatePolicy == false) 
				{
					if(lgcom5.isLgcom5Policy(asset)) 
					{
						//Asset 정책부여
						logger.info("=== updateContent / LGCOM5 isLgcom5Policy === : LGCOM5 권한 추가");
						policyIds.add(new TeamsNumberIdentifier(Long.parseLong(lgcom5.getLgcom5Id())));
						//Asset 메타데이터 조회
						MetadataCollection metadataCollection 	= asset.getMetadata();
						//Embago 필드정보 조회
						MetadataElement embagoElement 			= metadataCollection.findElementById(LGEConstatns.EMBARGO_USER_ACCESS_FIELD_ID);
						MetadataValue[] embagoValues 			= embagoElement == null ? null : ((MetadataTableField)embagoElement).getValues();
						MetadataElement embagoDateElement 		= metadataCollection.findElementById(new TeamsIdentifier("ARTESIA.FIELD.EMBARGO DATE"));
						MetadataValue embargoDate 				=  ((MetadataField)embagoDateElement).getValue();
						
						//String getDate = EventListenerUtils.getDate(0);
						
						if(!(asset.getSecurityPolicyList().size() == 1 && asset.getSecurityPolicyList().get(0).getName().contains(LGEConstatns.DYNAMIC_SCURITY_POLICY) || asset.getSecurityPolicyList().get(0).getName().contains(LGEConstatns.DYNAMIC_SCURITY_EMBARGO_PREFIX)))
						{
							
							if(embargoDate.isNullValue() && embagoValues.length == 0)
							{							
								logger.info("=== updateContent / LGCOM5 updatePolicy  Apply : " + updatePolicy);
								assetServices.unlockAsset(asset.getAssetId(), securitySession);
								assetServices.lockAsset(asset.getAssetId(), securitySession);
								assetSecurityServices.assignSecurityPoliciesToAssets(new AssetIdentifier[]{asset.getAssetId()}, (TeamsNumberIdentifier[]) policyIds.toArray(new TeamsNumberIdentifier[policyIds.size()]), false, securitySession);
								assetServices.unlockAsset(asset.getAssetId(), securitySession);	
							}								
						}										
					}
					else 
					{
							// LGCOM5 권한 제거
						logger.info("=== LGCOM5 isLgcom5Policy === : LGCOM5 권한 제거");
						for(SecurityPolicy assetPolicy : asset.getSecurityPolicyList()) 
						{	
							//해당 Asset에 dynamic 정책을 가져온다.
							if(assetPolicy.getName().equals(LGEConstatns.LG_COM5_WCMS_SECURITY_POLICY)) 
							{
								policyIds.add(new TeamsNumberIdentifier(Long.parseLong(assetPolicy.getId().toString())));
								assetServices.unlockAsset(asset.getAssetId(), securitySession);
								assetServices.lockAsset(asset.getAssetId(), securitySession);
								assetSecurityServices.unassignSecurityPoliciesFromAssets(new AssetIdentifier[]{asset.getAssetId()}, (TeamsNumberIdentifier[]) policyIds.toArray(new TeamsNumberIdentifier[policyIds.size()]), securitySession);
								assetServices.unlockAsset(asset.getAssetId(), securitySession);	
								break;
							}
						}
							
					}
				} 			
				logger.info("=== LGCOM5 End === ");		
			}
		} catch (BaseTeamsException e1) {
			logger.info("=== LGCOM5 catch === ");
			e1.printStackTrace();
		}
		
		logger.info("====== updatePolicy ====== :" + updatePolicy + "====== updateContent ====== " + updateContent);
		if(updatePolicy)
		{
			logger.info("====== updatePolicy START ======");
			//public 정책아이디 조회
			String publicScurityPolicyCode 		= EventListenerUtils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.KEY_NAME, LGEConstatns.PUBLIC_SECURITY_POLICY_ID, securitySession);			
			
			try {
				
				//Asset에 속한 잡 정보 조회
				List<ReviewJob> reJobList 				= EventListenerUtils.getRvJobId(asset, securitySession);
				//Embargo정책 조회 Asset에 할당된 정책이 있는지 확인
				SecurityPolicy [] embagoPolicy 			= EventListenerUtils.getSecurityPolicys(LGEConstatns.DYNAMIC_SCURITY_EMBARGO_PREFIX+asset.getAssetId(), securitySession);
//				SecurityPolicy [] allowToPolicy 		= EventListenerUtils.getSecurityPolicys(LGEConstatns.DYNAMIC_SCURITY_ALLOW_TO_PREFIX+asset.getAssetId(), securitySession);
				//Asset 메타데이터 조회
				MetadataCollection metadataCollection 	= asset.getMetadata();
				//Embago 필드정보 조회
				MetadataElement embagoElement 			= metadataCollection.findElementById(LGEConstatns.EMBARGO_USER_ACCESS_FIELD_ID);
				//AllowTo 필드정보조회
				MetadataElement allowToElement 			= metadataCollection.findElementById(LGEConstatns.ALLOW_TO_USER_ACCESS_FIELD_ID);

				MetadataValue[] embagoValues 			= embagoElement == null ? null : ((MetadataTableField)embagoElement).getValues();
				MetadataValue[] allowToValues 			= allowToElement == null ? null : ((MetadataTableField)allowToElement).getValues();
				//Embargo Date 조회
				MetadataElement embagoDateElement 		= metadataCollection.findElementById(new TeamsIdentifier("ARTESIA.FIELD.EMBARGO DATE"));
				
				MetadataElement checkValElement	 		= metadataCollection.findElementById(new TeamsIdentifier("LGE.FIELD.CHECKVAL"));
				MetadataElement approvalElement 		= metadataCollection.findElementById(new TeamsIdentifier("ARTESIA.FIELD.LIFECYCLE APPROVAL STATE"));
				MetadataValue checkValue				= checkValElement == null ? null : ((MetadataField)checkValElement).getValue();
				MetadataValue approval					= approvalElement == null ? null : ((MetadataField)approvalElement).getValue();
				
				MetadataValue embargoDate 				=  ((MetadataField)embagoDateElement).getValue();
				
				String getDate = EventListenerUtils.getDate(0);
				
				
	

				//Embago, AllowTo 둘다 아니면
				if(embagoValues.length == 0 && allowToValues.length == 0) 
				{
					logger.info("EMBARGO / ALLOW TO AGECNY NOT FOUND START");					
					logger.info("REVIEWJOB STATUS CHECK : "+ reJobList.size());
					if(reJobList.size() > 0)
					{					
						for(ReviewJob job : reJobList)
						{
							if((job.getStatus().getId() == 1) ||(job.getStatus().getId() == 2))
							{
								for(SecurityPolicy sp : asset.getSecurityPolicyList())
								{
									if(sp.getName().equals(LGEConstatns.DYNAMIC_SCURITY_PREFIX+job.getId().toString()))
									{
										policyIds.add(new TeamsNumberIdentifier(Long.parseLong(sp.getId().toString())));
									}
								}
							}
						}
					}
					logger.info("REVIEWJOB DYNAMIC POLICY SIZE : "+ policyIds.size());
										
					//folder에서 생성된 asset인 경우
					if(checkValue != null && !checkValue.isNullValue() && checkValue.getStringValue().equals("Y"))
					{
						logger.info("CREATE FOLDER LEVEL START");
						// assignSecurityPoliciesToAssets Method true 라서 선언된 PolicyIDs만 적용이 됨 그래서 LGCOM5 정책 삭제 로직은 빠져도 됨
						if(lgcom5.isLgcom5Policy(asset)) {
							//lgcom5  정책부여
							policyIds.add(new TeamsNumberIdentifier(Long.parseLong(lgcom5.getLgcom5Id())));
						}
						
						policyIds.add(new TeamsNumberIdentifier(Long.parseLong(publicScurityPolicyCode)));
						
//						for(TeamsNumberIdentifier policy : policyIds)
//						{
//							logger.info("CREATE FOLDER LEVEL POLICY INFO :" + policy.getId().toString());
//						}
						logger.info("CREATE FOLDER LEVEL END");
					}
					//job completed된 이력이 있는 asset인 경우
					else if(approval != null && !approval.isNullValue() && approval.getStringValue().toUpperCase().equals("APPROVED"))
					{
						logger.info("ASSET STATUS IS APPROVED START");
						// assignSecurityPoliciesToAssets Method true 라서 선언된 PolicyIDs만 적용이 됨 그래서 LGCOM5 정책 삭제 로직은 빠져도 됨
						if(lgcom5.isLgcom5Policy(asset)) {
							//lgcom5  정책부여
							policyIds.add(new TeamsNumberIdentifier(Long.parseLong(lgcom5.getLgcom5Id())));
						}
						policyIds.add(new TeamsNumberIdentifier(Long.parseLong(publicScurityPolicyCode)));
						
						logger.info("ASSET STATUS IS APPROVED END");
					}					
					
					try 
					{
						if(policyIds.isEmpty())
						{
							logger.info("POLICY IS BLANK");
							policyIds.add(new TeamsNumberIdentifier(Long.parseLong(publicScurityPolicyCode)));
						}	

						assetServices.unlockAsset(asset.getAssetId(), securitySession);
						assetServices.lockAsset(asset.getAssetId(), securitySession);
						assetSecurityServices.assignSecurityPoliciesToAssets(new AssetIdentifier[]{asset.getAssetId()}, (TeamsNumberIdentifier[]) policyIds.toArray(new TeamsNumberIdentifier[policyIds.size()]), true, securitySession);
						assetServices.unlockAsset(asset.getAssetId(), securitySession);
					}
					finally 
					{
						assetServices.unlockAsset(asset.getAssetId(), securitySession);
					}
					//Embargo  정책이 존재하면
					if(embagoPolicy.length != 0) 
					{
						logger.info("====== EMBARGO POLICY DELETE START ===== ");
						//Embago  삭제
						EventListenerUtils.deleteEmbagoPolicyAndGroup(asset.getAssetId(), securitySession);
						logger.info("====== EMBARGO POLICY DELETE END ===== ");
					}
					logger.info("EMBARGO / ALLOW TO AGECNY NOT FOUND END");
					
				}
				//Embargo Date가 존재하고 Embargo Date가 현재 날짜보다 크면 
				else if(!embargoDate.isNullValue() && new SimpleDateFormat("yyyy-MM-dd").parse(embargoDate.getStringValue()).getTime() > new SimpleDateFormat("yyyy-MM-dd").parse(getDate).getTime() && embagoValues.length != 0) 
				{
					logger.info("WHEN EMBARGO EXIST START");					
					logger.info("REVIEWJOB STATUS CHECK : "+ reJobList.size());
					
					if(reJobList.size() > 0)
					{					
						for(ReviewJob job : reJobList)
						{
							if((job.getStatus().getId() == 1) ||(job.getStatus().getId() == 2))
							{
								for(SecurityPolicy sp : asset.getSecurityPolicyList())
								{
									if(sp.getName().equals(LGEConstatns.DYNAMIC_SCURITY_PREFIX+job.getId().toString()))
									{
										policyIds.add(new TeamsNumberIdentifier(Long.parseLong(sp.getId().toString())));
									}
								}
							}
						}
					}
					
					//Embargo 값이 존재한다면
					if(embagoValues != null) 
					{
						logger.info("EXISTING EMBARGO USERS EXIST START");
						Set<String> SetInterUser = new HashSet<String>();
						Set<String> SetExterUser = new HashSet<String>();
						boolean ImportUserChk = false;
						for (MetadataValue aValue : embagoValues)
						{
							if (aValue.getValue() != null)
							{
								if(aValue.getValue().equals(event.getUserId()))
								{
									ImportUserChk =  true;
								}
								//내 외부 사용자 구분
								String type = EventListenerUtils.userStats(aValue.getStringValue(), securitySession);
								if(type.equals("I"))
								{
									SetInterUser.add(aValue.getStringValue());
								}
								else if(type.equals("E")) 
								{
									SetExterUser.add(aValue.getStringValue());
								}
							}
							//기존 사용자가 존재 하지 않는다면 자동으로 입력되도록 변경
							if(!ImportUserChk)
							{
								SetInterUser.add(event.getUserId().toString());
							}
						}
						
						//Embargo 정책이 없다면 생성
						if(embagoPolicy.length == 0) 
						{
							logger.info("CREATE EMBARGO GROUP / POLICY START");
							EmbargoPolicy.getInstance().create(asset, SetInterUser, SetExterUser, policyIds, securitySession);
							logger.info("CREATE EMBARGO GROUP / POLICY END");
						}
						//Embargo에서 사용자를 추가할 경우
						else if(embagoPolicy.length != 0) 
						{
							logger.info("EMBARGO ADD USERS TO A GROUP START");
							//Embargo 내부사용자 그룹아이디 조회
							UserGroup  interGroup = EventListenerUtils.getUserGroup(LGEConstatns.DYNAMIC_USER_GROUP_INTERNAL_EMBARGO_PREFIX+asset.getAssetId(), securitySession);
							//Embargo 외부사용자 그룹아이디 조회
							UserGroup  exterGroup = EventListenerUtils.getUserGroup(LGEConstatns.DYNAMIC_USER_GROUP_EXTERNAL_EMBARGO_PREFIX+asset.getAssetId(), securitySession);
							//Embargo 내부사용자 정보 조회
							TeamsUser [] interUsers = userGroupServices.retrieveUsersAssignedToUserGroup(interGroup.getId(), securitySession);
							//Embargo 외부사용자 정보 조회
							TeamsUser [] exterUsers = userGroupServices.retrieveUsersAssignedToUserGroup(exterGroup.getId(), securitySession);
		
							try {
								//내.외부 그룹 잠금
								userGroupServices.lockUserGroup(interGroup.getId(), securitySession);
								userGroupServices.lockUserGroup(exterGroup.getId(), securitySession);

								//내부사용자가 존재하면 제거
								if(interUsers.length != 0) {
									userGroupServices.removeUserGroupUsers(interGroup.getId(), interUsers, securitySession);
								}
								//Metadata에 내부 사용자가 존재하면  그룹에 저장 
								if(SetInterUser.size() != 0) {
									//�궡遺��궗�슜�옄 洹몃９�뿉 �궗�슜�옄 異붽�
									userGroupServices.addArtesiaUserGroupUsers(interGroup.getId(), (String[])SetInterUser.toArray(new String[SetInterUser.size()]), securitySession);
								}
								//외부사용자가 존재하면 제거 
								if(exterUsers.length != 0) {
									//�쇅遺��궗�슜�옄洹몃９�뿉�꽌 �궗�슜�옄 �궘�젣
									userGroupServices.removeUserGroupUsers(exterGroup.getId(), exterUsers, securitySession);												
								}
								//Metadata에 외부 사용자가 존재하면  그룹에 저장
								if(SetExterUser.size() != 0) {
									userGroupServices.addArtesiaUserGroupUsers(exterGroup.getId(), (String[])SetExterUser.toArray(new String[SetExterUser.size()]), securitySession);
								}					
								//내.외부 그룹 잠금해제
								userGroupServices.unlockUserGroup(interGroup.getId(), securitySession);
								userGroupServices.unlockUserGroup(exterGroup.getId(), securitySession);
							}finally {
								//내.외부 그룹 잠금해제
								userGroupServices.unlockUserGroup(interGroup.getId(), securitySession);
								userGroupServices.unlockUserGroup(exterGroup.getId(), securitySession);
							}
							logger.info("EMBARGO ADD USERS TO A GROUP END");
						}
						logger.info("EXISTING EMBARGO USERS EXIST END");
					}
				}
				//AllowTo 사용자가 존재한다면 
				else if(allowToValues.length != 0) 
				{
					//logger.info("EXISTING ALLOW TO AGENCY USERS EXIST START");
					
					if(reJobList.size() > 0)
					{					
						for(ReviewJob job : reJobList)
						{
							if((job.getStatus().getId() == 1) ||(job.getStatus().getId() == 2))
							{
								for(SecurityPolicy sp : asset.getSecurityPolicyList())
								{
									if(sp.getName().equals(LGEConstatns.DYNAMIC_SCURITY_PREFIX+job.getId().toString()))
									{
										policyIds.add(new TeamsNumberIdentifier(Long.parseLong(sp.getId().toString())));
									}
								}
							}
						}
					}
					
					Set<String> setUsers = new HashSet<String>();
										
					//폴더에서 생성된 Asset이라면
					logger.info("CREATE FOLDER LEVEL CHECK START");
					if(checkValue != null && !checkValue.isNullValue() && checkValue.getStringValue().equals("Y"))
					{
						logger.info("CREATE FOLDER LEVEL STATUS : OK");
						for (MetadataValue aValue : allowToValues)
						{
							if (aValue.getValue() != null)
							{							
								setUsers.add(aValue.getStringValue());						
							}
						}
						policyIds.add(new TeamsNumberIdentifier(Long.parseLong(publicScurityPolicyCode)));
						if(lgcom5.isLgcom5Policy(asset)) {
							//lgcom5  정책부여
							policyIds.add(new TeamsNumberIdentifier(Long.parseLong(lgcom5.getLgcom5Id())));
						}
					}
					//logger.info("CREATE FOLDER LEVEL CHECK END");
					
					//job에 존재하는지 확인 및 Completed된 job이 있는지 체크
					boolean jobCompletedFlag = false;
					if(reJobList.size() != 0)
					{
						
						for(int idx = 0; idx <reJobList.size();idx++)							
						{
							//2019-04-29 완료날짜 비교에서 상태값 비교로 변경
							if(reJobList.get(idx).getStatus().getId() == 3)
							{
								jobCompletedFlag = true;
								break;
							}
						}
					}
					//완료된 job이 있다면, Embargo정책 삭제
					if(jobCompletedFlag)
					{
						if(embagoPolicy.length != 0) 
						{
							EventListenerUtils.deleteEmbagoPolicyAndGroup(asset.getAssetId(), securitySession);	
						}
					}
					//job Compelted된 Asset이라면
					if(approval != null && !approval.isNullValue() && approval.getStringValue().toUpperCase().equals("APPROVED"))
					{
						logger.info("ALLOW TO AGECNY ASSET STATUS IS APPROVED START");
						for (MetadataValue aValue : allowToValues)
						{
							if (aValue.getValue() != null)
							{							
								setUsers.add(aValue.getStringValue());						
							}
						}
						policyIds.add(new TeamsNumberIdentifier(Long.parseLong(publicScurityPolicyCode)));
						if(lgcom5.isLgcom5Policy(asset)) {
							//lgcom5  정책부여
							policyIds.add(new TeamsNumberIdentifier(Long.parseLong(lgcom5.getLgcom5Id())));
						}	
						//logger.info("ALLOW TO AGECNY ASSET STATUS IS APPROVED END");
					}


					for(String user : setUsers) 
					{
						SecurityPolicy policy = EventListenerUtils.getSecurityPolicy(LGEConstatns.DYNAMIC_SCURITY_ALLOW_TO_PREFIX+user, securitySession);
						policyIds.add(policy.getId());
					}
					try 
					{
						//2019-04-29 변경 null값이 들어가서
						if(policyIds.size() > 0)
						{
							assetServices.unlockAsset(asset.getAssetId(), securitySession);
							assetServices.lockAsset(asset.getAssetId(), securitySession);
							assetSecurityServices.assignSecurityPoliciesToAssets(new AssetIdentifier[]{asset.getAssetId()}, (TeamsNumberIdentifier[]) policyIds.toArray(new TeamsNumberIdentifier[policyIds.size()]), true, securitySession);
							assetServices.unlockAsset(asset.getAssetId(), securitySession);
						}						
					}
					finally					
					{
						assetServices.unlockAsset(asset.getAssetId(), securitySession);
						//Embago  정책이 존재하면
						if(embagoPolicy.length != 0) 
						{
							//logger.info("====== ALLOW TO AGENCY EMBARGO POLICY DELETE START ===== ");
							//Embago  삭제
							EventListenerUtils.deleteEmbagoPolicyAndGroup(asset.getAssetId(), securitySession);
							
							//logger.info("====== ALLOW TO AGENCY EMBARGO POLICY DELETE END ===== ");
						}	
					}		
				}	
			} 
			catch (BaseTeamsException | ParseException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
		}
	}
}
