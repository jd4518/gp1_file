package eventHandler;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.Asset;
import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.security.services.AssetSecurityServices;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.NameValue;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.event.Event;
import com.artesia.security.SecuritySession;

import common.EventListenerUtils;
import contants.LGEConstatns;

/*
* ---------------------------------------------------------------------------------------
* PROJ    :   New Marketing Product Information_LGE
* NAME    :   RemoveAssetHandler.java
* DESC    :   rvjob에서 asset remove handler
* Author  :   양창덕
* VER     :   v1.0
* Copyright 2019 LG CNS All right reserved
* ---------------------------------------------------------------------------------------
*                       변             경           사          항
* ---------------------------------------------------------------------------------------
*       DATE       AUTHOR                                  DESCRIPTION
*  ------------ -----------  ------------------------------------------------------------
*   2019.09.18    양창덕           reviewjob에서 asset remove hanlder 로직 변경
*   2019.12.31    양창덕           reviewjob에서 asset remove 발생 시 예외처리 로직 추가 line : 54
* ---------------------------------------------------------------------------------------
*/
public class RemoveAssetHandler extends AbstractEventHandler{
	
	private static final Log logger = LogFactory.getLog(RemoveAssetHandler.class);

	@Override
	void handleEvent(Event event, SecuritySession securitySession) {
		
		logger.info("================== RemoveAssetHandler START =====================");
		String dumyPolicyId   = EventListenerUtils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.KEY_NAME, LGEConstatns.DUMY_SECURITY_POLICY_ID, securitySession);
		NameValue [] values = event.getData();
		for(NameValue value : values)
		{
			if(value.getName().equals("Asset Id"))
			{
				Asset asset = null;
				try 
				{
					asset = EventListenerUtils.getAssetInfo(new AssetIdentifier(value.getValue()), securitySession);
					if(asset != null)
					{
						asset = EventListenerUtils.getAssetInfoLast(new AssetIdentifier(value.getValue()), securitySession);	
						AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);
						AssetServices.getInstance().lockAsset(asset.getAssetId(), securitySession);
						AssetSecurityServices.getInstance().assignSecurityPoliciesToAssets(asset.getAssetId().asAssetIdArray(), new TeamsNumberIdentifier[] {new TeamsNumberIdentifier(Long.parseLong(dumyPolicyId))}, true, securitySession);
						AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);
					}							
				}
				catch (BaseTeamsException e) 
				{
					logger.info("RemoveHander Error : "+ asset.getAssetId().toString() +" " + e.getMessage() );
					e.printStackTrace();
				}
			}
		}
		logger.info("================== RemoveAssetHandler END =====================");
		
		
//		logger.info("================== RemoveAssetHandler START =====================");
//		//dumy 정책 아이디 조회
//		String dumyPolicyId   = EventListenerUtils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.KEY_NAME, LGEConstatns.DUMY_SECURITY_POLICY_ID, securitySession);
//		//dynamic 정책아이디 조회
//		Set<TeamsNumberIdentifier> policyIds = new HashSet<TeamsNumberIdentifier>();
//
//		NameValue [] values = event.getData();
//		for(NameValue value : values) 
//		{
//			if(value.getName().equals("Asset Id"))
//			{
//				Asset asset;
//				try {
//					//Asset 유효성체크 필요.
//					asset = EventListenerUtils.getAssetInfo(new AssetIdentifier(value.getValue()), securitySession);
//					if(asset != null)
//					{
//						asset = EventListenerUtils.getAssetInfoLast(new AssetIdentifier(value.getValue()), securitySession);
//						MetadataCollection metadataCollection 	= asset.getMetadata();					
//						MetadataElement checkValElement	 		= metadataCollection.findElementById(LGEConstatns.CHECKVAL);
//						MetadataElement approvalElement 		= metadataCollection.findElementById(new TeamsIdentifier("ARTESIA.FIELD.LIFECYCLE APPROVAL STATE"));
//						MetadataValue checkValue				= checkValElement == null ? null : ((MetadataField)checkValElement).getValue();
//						MetadataValue approval					= approvalElement == null ? null : ((MetadataField)approvalElement).getValue();
//						
//						
//						boolean folFlag = false;
//						//폴더에서 생성된것인지 판단
//						if(checkValue != null && !checkValue.isNullValue() && checkValue.getStringValue().equals("Y"))
//						{
//							folFlag = true;
//						}
//						boolean jobFlag = false;
//						//Job에서 생성되고 승인이 된것인지 판단
//						if(approval != null && !approval.isNullValue() && approval.getStringValue().toUpperCase().equals("APPROVED")) 
//						{
//							jobFlag = true;
//						}
//						
//						
//						
//						logger.info("================== folFlag : " + folFlag + " ===================== jobFlag : " + jobFlag);
//						
//						//public된 Asset인 경우
//						if(folFlag || jobFlag)
//						{
//							if(asset.getSecurityPolicyList().size() > 1)
//							{
//								//Embargo 정책유무 판단
//								List<SecurityPolicy> assetPolicyList = asset.getSecurityPolicyList();
//								for(SecurityPolicy assetPolicy : assetPolicyList) 
//								{
//									System.out.println("remove 정책비교" + assetPolicy.getName().contains(LGEConstatns.DYNAMIC_SCURITY_POLICY+event.getObjectId()));
//									if(!assetPolicy.getName().contains(LGEConstatns.DYNAMIC_SCURITY_POLICY+event.getObjectId())) 
//									{
//										policyIds.add(assetPolicy.getId());
//									}
//								}	
//								if(policyIds.size() > 0 )
//								{
//									//Remove Job에 대한 Dynamic 정책만 삭제
//									AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);
//									AssetServices.getInstance().lockAsset(asset.getAssetId(), securitySession);
//									AssetSecurityServices.getInstance().assignSecurityPoliciesToAssets(asset.getAssetId().asAssetIdArray(), (TeamsNumberIdentifier[]) policyIds.toArray(new TeamsNumberIdentifier[policyIds.size()]), true, securitySession);
//									AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);
//								}
//							}							
//						}
//						else
//						{
//							//dumy 정책부여
//							AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);
//							AssetServices.getInstance().lockAsset(asset.getAssetId(), securitySession);
//							AssetSecurityServices.getInstance().assignSecurityPoliciesToAssets(asset.getAssetId().asAssetIdArray(), new TeamsNumberIdentifier[] {new TeamsNumberIdentifier(Long.parseLong(dumyPolicyId))}, true, securitySession);
//							AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);
//						}
//						
//					}
//				}					
//				 catch (BaseTeamsException e) 
//				{
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				
//			}
//		}	
//		logger.info("================== RemoveAssetHandler END =====================");
	}
}
