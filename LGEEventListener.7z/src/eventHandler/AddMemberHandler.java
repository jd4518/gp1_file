package eventHandler;

import java.util.HashSet;
import java.util.Set;

import com.artesia.common.NameValue;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.event.Event;
import com.artesia.security.SecuritySession;

import common.EventListenerUtils;

public class AddMemberHandler extends AbstractEventHandler{

	@Override
	void handleEvent(Event event, SecuritySession securitySession) {
		NameValue [] values = event.getData();
		Set<String> internalUser = new HashSet<>();
		Set<String> externalUser = new HashSet<>();
		for(NameValue value : values) {
			//rvjob team등록된 사용자 정보 
			if(value.getName().equals("_userIdKey")) {
				try {
					//내부 or 외부 사용자 상태 구분
					String type = EventListenerUtils.userStats(value.getValue(), securitySession);		
					//내부사용자일 경우
					if(type.equals("I")) internalUser.add(value.getValue());
					//외부사용자일 경우 
					else if(type.equals("E")) externalUser.add(value.getValue());  	
				} catch (BaseTeamsException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}
		}
		//외부 or 내부 사용자 그룹에 추가
		if(internalUser.size() != 0) EventListenerUtils.addUsersToGroup(internalUser, securitySession, contants.LGEConstatns.LGE_USER_GROUPS_PREFIX[0]+event.getObjectId());
		if(externalUser.size() != 0) EventListenerUtils.addUsersToGroup(externalUser, securitySession, contants.LGEConstatns.LGE_USER_GROUPS_PREFIX[1]+event.getObjectId());
	}
}
