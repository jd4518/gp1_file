package eventHandler;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.metadata.services.AssetMetadataServices;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.NameValue;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.event.Event;
import com.artesia.metadata.MetadataField;
import com.artesia.security.SecuritySession;


public class MataDataToUpdateHandler extends AbstractEventHandler{
	
	private static final MetadataField [] metaFields = new MetadataField[]{new MetadataField(new TeamsIdentifier("TEST.META.FILED04"))};

	private static final Log LOGGER = LogFactory.getLog(MataDataToUpdateHandler.class);
	@Override
	void handleEvent(Event event, SecuritySession securitySession) 
	{		
		NameValue[] value = event.getData();
		metaFields[0].setValue(value[1].getValue());
		
		AssetIdentifier asset = new AssetIdentifier(event.getObjectId());		
		if(!value[0].getValue().equals(metaFields[0].getId().toString())) 
		{
			try 
			{
				AssetServices.getInstance().lockAsset(new AssetIdentifier(event.getObjectId()), securitySession);
				AssetMetadataServices.getInstance().saveMetadataForAssets(asset.asAssetIdArray(), metaFields, securitySession);
				AssetServices.getInstance().unlockAsset(new AssetIdentifier(event.getObjectId()), securitySession);
			} 
			catch (BaseTeamsException e) 
			{
				e.printStackTrace();
			}
		}			
	}

}
