package eventHandler;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.Asset;
import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.security.services.AssetSecurityServices;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.NameValue;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.event.Event;
import com.artesia.metadata.MetadataCollection;
import com.artesia.metadata.MetadataElement;
import com.artesia.metadata.MetadataField;
import com.artesia.metadata.MetadataValue;
import com.artesia.security.SecurityPolicy;
import com.artesia.security.SecuritySession;

import common.EventListenerUtils;
import contants.LGEConstatns;
import utils.Utils;

/**
 * 실행순서
 * Interceptor 실행 (LGEAssetInterceptor.java)-> EventListner 실행 (AddAssetsToSecurityPolicyHandler.java)
 * @author chungkyu1.lee
 * 1. job에서 asset import 
 * 2. 
 */
public class AddAssetsToSecurityPolicyHandler extends AbstractEventHandler{
	
	private static final Log LOGGER = LogFactory.getLog(AddAssetsToSecurityPolicyHandler.class);
	
	@Override
	public void handleEvent(Event event, SecuritySession securitySession) 
	{
			
		LOGGER.info("========================== AddAssetsToSecurityPolicyHandler START =============================");
		
		//Asset 아이디 변수
		Set<AssetIdentifier> assetIds = new HashSet<AssetIdentifier>();
		//Asset 변수
		Set<Asset> assets = new HashSet<Asset>();

		//public 정책 아이디 정보
		String publicScurityPolicyCode 	= Utils.getSystemSetting(LGEConstatns.COMPONENT_NAME, LGEConstatns.KEY_NAME, LGEConstatns.PUBLIC_SECURITY_POLICY_ID, securitySession);
		
		SecurityPolicy  securityPolicy = null;	
		try {
			//다이나믹정책이름을 통해 아이디 정보 조회
			securityPolicy = EventListenerUtils.getSecurityPolicy(contants.LGEConstatns.DYNAMIC_SCURITY_PREFIX+event.getObjectId(), securitySession);	
		} catch (BaseTeamsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		NameValue [] values = event.getData();
		for(NameValue value : values) {
			if(value.getName().equals("Asset Id")){
				//import된 Asset 아이디 정보 담기
				assetIds.add(new AssetIdentifier(value.getValue()));
			}			
		}
		
		//AssetIdentifier 형태의 Asset Id를 통해 Asset 정보 조회
		assets = EventListenerUtils.getAssetIdentifierToAssets(assetIds, securitySession);

		for(Asset asset : assets)
		{
			System.out.println("====================== " + asset.getContentType());
			if(!asset.getContentType().equals("VIDEO"))
			{
				Set<TeamsNumberIdentifier> policyIds = new HashSet<TeamsNumberIdentifier>();			
				Set<TeamsNumberIdentifier> dynamics = new HashSet<TeamsNumberIdentifier>();
				policyIds.add(new TeamsNumberIdentifier(Long.parseLong(securityPolicy.getId().toString())));

				try 
				{
					MetadataCollection metadataCollection 	= asset.getMetadata();					
					MetadataElement checkValElement	 		= metadataCollection.findElementById(LGEConstatns.CHECKVAL);
					MetadataElement approvalElement 		= metadataCollection.findElementById(new TeamsIdentifier("ARTESIA.FIELD.LIFECYCLE APPROVAL STATE"));
					MetadataValue checkValue				= checkValElement == null ? null : ((MetadataField)checkValElement).getValue();
					MetadataValue approval					= approvalElement == null ? null : ((MetadataField)approvalElement).getValue();
					
					
					//기존 정책 중에 embargo, allowto, dynamic가 있다면 유지함.
					List<SecurityPolicy> assetPolicyList = asset.getSecurityPolicyList();
					for(SecurityPolicy assetPolicy : assetPolicyList) 
					{		
						
						if(checkValue != null &&  !checkValue.isNullValue() && checkValue.getStringValue().equals("Y"))
						{
							if(assetPolicy.getName().contains(LGEConstatns.DYNAMIC_SCURITY_ALLOW_TO_PREFIX) 
								|| assetPolicy.getName().contains(LGEConstatns.DYNAMIC_SCURITY_EMBARGO_PREFIX)) 
								{
									policyIds.add(assetPolicy.getId());
								}	
						}										
						else
						{
							if(assetPolicy.getName().contains(LGEConstatns.DYNAMIC_SCURITY_EMBARGO_PREFIX)) 
							{
								policyIds.add(assetPolicy.getId());
							}
						}
						if(assetPolicy.getName().contains(LGEConstatns.DYNAMIC_SCURITY_POLICY))
						{
							dynamics.add(assetPolicy.getId());
						}
					}
					//asset metadata onwer에 값 검색
					MetadataElement ownerElement = asset.getMetadata().findElementById(LGEConstatns.ASSET_OWNER_ID);				
					MetadataValue ownerValue 	 = ((MetadataField)ownerElement).getValue();
					
					if(checkValue != null &&  !checkValue.isNullValue() && checkValue.getStringValue().equals("Y"))
					{					
						if(!EventListenerUtils.embargoPolicyChk(asset, securitySession)) 
						{
							policyIds.add(new TeamsNumberIdentifier(Long.parseLong(publicScurityPolicyCode)));
						}					
					}
					//job에서 완료된 경우
					if(approval != null && !approval.isNullValue() && approval.getStringValue().toUpperCase().equals("APPROVED"))
					{
						if(!EventListenerUtils.embargoPolicyChk(asset, securitySession)) 						
						{
							policyIds.add(new TeamsNumberIdentifier(Long.parseLong(publicScurityPolicyCode)));
						}	
					}
					
					//기존 다이나믹 정책을 가지고 있으면 같이 부여.
					for(TeamsNumberIdentifier index : dynamics)
					{					
						policyIds.add(index);
					}
					
					AssetServices.getInstance().lockAsset(asset.getAssetId(), securitySession);
					AssetSecurityServices.getInstance().assignSecurityPoliciesToAssets(new AssetIdentifier[]{asset.getAssetId()}, (TeamsNumberIdentifier[]) policyIds.toArray(new TeamsNumberIdentifier[policyIds.size()]), true, securitySession);
					AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);						
				} catch (BaseTeamsException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally
				{
					try {
						AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);
					} catch (BaseTeamsException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		LOGGER.info("========================== AddAssetsToSecurityPolicyHandler END =============================");
	}		
}
