package eventHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.common.exception.BaseTeamsException;
import com.artesia.event.Event;
import com.artesia.security.SecurityPolicy;
import com.artesia.security.SecuritySession;
import com.artesia.security.services.SecurityPolicyServices;
import com.artesia.security.session.services.AuthenticationServices;

import common.EventListenerUtils;
import contants.LGEConstatns;
import ttsg_teams.admin.db.DBMgr;
import ttsg_teams.common.common.TeamsException;

public class DeleteUserHandler  extends AbstractEventHandler{

	private static final Log LOGGER = LogFactory.getLog(DeleteUserHandler.class);
	
	@Override
	void handleEvent(Event event, SecuritySession securitySession) {
		
		LOGGER.info("=========================   DeleteUserHandler START  =======================");
		LOGGER.info("=========================  " + event.getObjectId());
		LOGGER.info("=========================  " + event.getUserId());
		StringBuffer delete = new StringBuffer();							
		delete.append("DELETE FROM OTMM.OTMM.LGE_MPIS_USER_MANAGERMENT_CT			\n");
		delete.append(" WHERE USER_ID  = '"+event.getObjectId()+"' 					\n");		    			
		Connection connection2 = null;
		PreparedStatement preparedStatement2 = null;				
		try
		{
			DBMgr db2 = new DBMgr();
			connection2 = db2.openDatabase();
			preparedStatement2 = connection2.prepareStatement(delete.toString());
			preparedStatement2.executeUpdate();	
		} catch (TeamsException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{							
			try {
				if(connection2 != null) connection2.close(); 						
				if(preparedStatement2 != null) preparedStatement2.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		try {
			SecurityPolicy[] policys = SecurityPolicyServices.getInstance().retrieveSecurityPoliciesByName(LGEConstatns.DYNAMIC_SCURITY_ALLOW_TO_PREFIX+event.getObjectId(), securitySession);
			if(policys.length > 0)
			{
				EventListenerUtils.deleteSecurityPolicyToId(policys[0].getId(), securitySession);
			}
			EventListenerUtils.deleteUserGroupToName(LGEConstatns.DYNAMIC_USER_GROUP_ALLOW_TO_PREFIX+event.getObjectId(), securitySession);
		} catch (BaseTeamsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOGGER.info("=========================   DeleteUserHandler END  =======================");
	}
}
