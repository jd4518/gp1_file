package eventHandler;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.security.services.AssetSecurityServices;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.event.Event;
import com.artesia.security.SecurityPolicy;
import com.artesia.security.SecuritySession;
import com.artesia.security.services.SecurityPolicyServices;

import common.EventListenerUtils;
import contants.LGEConstatns;
import moduler.DynamicPolicy;

public class ReOpenJobHandler extends AbstractEventHandler{

	@Override
	void handleEvent(Event event, SecuritySession securitySession) {
		boolean assign = true;
		
		try {
			//2019-04-19 정책 유무 판단
			SecurityPolicy [] policy = SecurityPolicyServices.getInstance().retrieveSecurityPoliciesByName(LGEConstatns.DYNAMIC_SCURITY_PREFIX+event.getObjectId(), securitySession);
			System.out.println("ReOpen Policy Status : " + policy.length);
			//2019-04-19 정책 없으면 생성
			if(policy.length == 0)
			{
				DynamicPolicy.getInstance().create(event, securitySession, assign);
			}
			else
			{
				Set<TeamsNumberIdentifier> policyIds = new HashSet<TeamsNumberIdentifier>();
				//Select Job into Assets
				System.out.println("ReOpen Select Job into Assets");
				List<AssetIdentifier> assetList = EventListenerUtils.getRvjobToAssets(new TeamsIdentifier(event.getObjectId()), securitySession);
				
				System.out.println("ReOpenJob asset size : " + assetList.size());
				
				//예외처리
				if(assetList.size() > 0 )
				{
					AssetIdentifier[] stringArray = assetList.toArray(new AssetIdentifier[0]);
					
					policyIds.add(policy[0].getId());				
					
					AssetServices.getInstance().unlockAssets(stringArray, securitySession);
					AssetServices.getInstance().lockAssets(stringArray, securitySession);
					AssetSecurityServices.getInstance().assignSecurityPoliciesToAssets(stringArray , (TeamsNumberIdentifier[]) policyIds.toArray(new TeamsNumberIdentifier[policyIds.size()]), false, securitySession);
					AssetServices.getInstance().unlockAssets(stringArray, securitySession);
				}
			}
				
		} catch (BaseTeamsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
