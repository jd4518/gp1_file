package eventHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.artesia.common.exception.BaseTeamsException;
import com.artesia.event.Event;
import com.artesia.security.SecuritySession;
import com.artesia.user.TeamsUser;
import com.artesia.user.UserIdentifier;
import com.artesia.user.services.UserServices;

import mailUtils.sendMailApi;
import moduler.AllowToPolicy;
import ttsg_teams.admin.db.DBMgr;
import ttsg_teams.common.common.TeamsException;
import utils.Utils;

public class CreateUserHandler extends AbstractEventHandler {

	@Override
	void handleEvent(Event event, SecuritySession securitySession) {  
		try 
		{  
			System.out.println("================ CreateUserHandler  ======================");
			String type = "";
			TeamsUser user = UserServices.getInstance().retrieveTeamsUser(new UserIdentifier(event.getObjectId()), securitySession);
			System.out.println("===========" + user.getDomainName());  
			if(user.getDomainName().equals("otmm.external.users") || user.getDomainName().equals("otmm.internal.users"))
			{
				String desc [] = null;	
				if (user.getDescription() == null)
			      {
			        type = "I";
			      }
			      else
			      {
			        desc = user.getDescription().split(",");
			        String flag = desc[0].substring(0, 1);
			        if (flag.equals("E")) {
			          type = "E";
			        } else {
			          type = "I";
			        }
			      }
				String userId 		= user.getUserId().toString();
				String loginId 		= user.getLoginName();
				String name	   		= user.getName().replaceAll("'", "''");
				String emailAddr 	= user.getEmailAddress();
				String company = null;
			    String description = null;
			    if(desc != null)
			    {
			    	if (desc.length > 1)
				    {
				      company = desc[1].replaceAll("'", "''");
				      description = desc[2].replaceAll("'", "''");
				    }
			    }
			    
				String regId 		= event.getData()[0].getValue();
				
				
				StringBuffer sql = new StringBuffer();
				sql.append("INSERT INTO OTMM.LGE_MPIS_USER_MANAGERMENT_CT 									\n");
				sql.append("			(USER_ID, LOGIN_ID, NAME, EMAIL_ADDR,  								\n");
				sql.append("			 COMPANY, DESCRIPTION, CREATE_DT, EXPIRE_DT, TYPE, REG_ID, REG_DT 	\n");
				sql.append("		    )VALUES( 															\n");
				sql.append("			'"+userId+"'														\n");
				sql.append("			,'"+loginId+"'														\n");
				sql.append("			,N'"+name+"'															\n");
				sql.append("			,N'"+emailAddr+"'													\n");
				if(type.equals("E"))
				{
					sql.append("			,N'"+company+"'													\n");
					sql.append("			,N'"+description+"'												\n");
				}
				else
				{
					sql.append("			,''																\n");
					sql.append("			,''																\n");
				}
				
				sql.append("			,(SELECT CAST(CAST(GETDATE() AS DATE) AS DATETIME))					\n");
				sql.append("			,(SELECT CAST(CAST(GETDATE()+90 AS DATE) AS DATETIME))				\n");
				sql.append("			,'"+type+"'															\n");
				sql.append("			,'"+regId+"'														\n");
				sql.append("			, getDate()															\n");
				sql.append("			)																	\n");
				
				System.out.println("================ CreateUserHandler  sql ======================");
				System.out.println(sql.toString());
				try 
				{
					try {
//						DbConnection.updateQuery(sql.toString(), null);
						Connection connection = null;
						PreparedStatement preparedStatement = null;				
						try
						{
							DBMgr db = new DBMgr();
							connection = db.openDatabase();
							preparedStatement = connection.prepareStatement(sql.toString());
							preparedStatement.executeUpdate();	
						}
						finally
						{
							if(connection != null)  connection.close();
							if(preparedStatement != null) preparedStatement.close();
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//외부사용자 AllowTo 정책생성
					if(type.equals("E")) 
					{					
						Set<String> users = new HashSet<>();
						users.add(user.getUserId().toString());
						AllowToPolicy.getInstance().create(users, securitySession);
					}
				} 
				catch (TeamsException e) {
					// TODO Auto-generated catch block
					//sendMail(user, securitySession);
					e.printStackTrace();
				}
			}			
		} 
		catch (BaseTeamsException e) 
		{
			e.printStackTrace();
		}	
	}
	
	private void sendMail(TeamsUser userInfo, SecuritySession securitySession)
	{
	    Map<String, String> map = new HashMap<String, String>();
	    StringBuffer returnValue = new StringBuffer();
	    returnValue.append("External User Register is Failed");
	    returnValue.append("User : " + userInfo.getLoginName());
	    returnValue.append("Please do not reply to this message. It is an automated email from the Media Management system.");
	    
	    map.put("fromAddress", Utils.getSystemSetting("COMMON", "SERVER", "ADMIN_EMAIL_ADDRESS", securitySession));
	    map.put("toAddress", Utils.getSystemSetting("COMMON", "SERVER", "ADMIN_EMAIL_ADDRESS", securitySession));
	    map.put("ccAddress", "");
	    map.put("replyToAddr", "");
	    map.put("subject", "External User Register is Failed");
	    map.put("body", returnValue.toString());
	    map.put("serverName", Utils.getSystemSetting("COMMON", "SERVER", "EMAIL_SERVER", securitySession));
	    sendMailApi.sendMail(map);
	}
}
