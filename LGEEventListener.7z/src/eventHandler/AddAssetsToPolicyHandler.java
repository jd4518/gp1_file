package eventHandler;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.Asset;
import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.security.services.AssetSecurityServices;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.NameValue;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.event.Event;
import com.artesia.security.SecurityPolicy;
import com.artesia.security.SecuritySession;

import common.EventListenerUtils;

public class AddAssetsToPolicyHandler extends AbstractEventHandler{
	
	private static final Log logger = LogFactory.getLog(AddAssetsToPolicyHandler.class);
	
	@Override
	void handleEvent(Event event, SecuritySession securitySession) {
//		1. 다이나믹 정책 판단
//		2. 다이나믹 정책이 존재한다면 패스
//		3. 다이나믹 정책이 없다면 다이나믹 정책을 Asset에 부여
//		4. Embargo 형태의 Asset이라면 LG5.0 정책은 사용안함.
		
//		Set<Asset> setAllowToAssets = new HashSet<Asset>();
//		Set<AssetIdentifier> setAssets = new HashSet<AssetIdentifier>();
		NameValue [] values = event.getData();

		Set<TeamsNumberIdentifier> policyIds = new HashSet<TeamsNumberIdentifier>();
		logger.info("======= AddAssetsToPolicyHandler START   ======");
		boolean jobFlag = false;
		for(NameValue value : values) {
			if(value.getName().equals("Asset Id")) {
				try {
					System.out.println("AddAssetsToPolicyHandler" +  value.getValue());
					Asset asset = EventListenerUtils.getAssetInfoLast(new AssetIdentifier(value.getValue()), securitySession);	
					
					System.out.println("=============getId " + asset.getAssetId());
					
					for(SecurityPolicy assetPolicy : asset.getSecurityPolicyList())
					{						
						if(assetPolicy.getId().equals(new TeamsNumberIdentifier(new Long("2"))))
						{
							jobFlag = true;
							break;
						}  
					} 
					   
					logger.info("======= AddAssetsToPolicyHandler Add To Job True / False : " + jobFlag);
					if(! jobFlag)
					{ 
						//정책부여
						SecurityPolicy securityPolicy = EventListenerUtils.getSecurityPolicy(contants.LGEConstatns.DYNAMIC_SCURITY_PREFIX+event.getObjectId(), securitySession);
						policyIds.add(new TeamsNumberIdentifier(Long.parseLong(securityPolicy.getId().toString())));
						AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);
						AssetServices.getInstance().lockAsset(asset.getAssetId(), securitySession);
						AssetSecurityServices.getInstance().assignSecurityPoliciesToAssets(new AssetIdentifier[]{asset.getAssetId()}, (TeamsNumberIdentifier[]) policyIds.toArray(new TeamsNumberIdentifier[policyIds.size()]), false, securitySession);
						AssetServices.getInstance().unlockAsset(asset.getAssetId(), securitySession);
					}
				} catch (BaseTeamsException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
