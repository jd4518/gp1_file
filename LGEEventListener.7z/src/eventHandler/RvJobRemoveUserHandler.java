package eventHandler;

import java.util.HashSet;
import java.util.Set;

import com.artesia.common.NameValue;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.event.Event;
import com.artesia.security.SecuritySession;
import com.artesia.security.UserGroup;
import com.artesia.security.services.UserGroupServices;

import common.EventListenerUtils;

public class RvJobRemoveUserHandler extends AbstractEventHandler{

	@Override
	void handleEvent(Event event, SecuritySession securitySession) {
		
		NameValue [] values = event.getData();
		Set<String> valuesSet = new HashSet<>();
		
		for(NameValue value : values) {
			//삭제된 사용자 담기
			if(value.getName().equals("_userIdKey")) {
				valuesSet.add(value.getValue());
			}
		}
		if(valuesSet.size() != 0) {
			for(String userId : valuesSet) {
				String type = null;
				try {
					//사용자 내부 or 외부 구분
					type = EventListenerUtils.userStats(userId, securitySession);
				} catch (BaseTeamsException e1) {
					e1.printStackTrace();
				}
				String groupNm = "";
				//내부 or 외부 그룹이름 정보
				if(type.equals("I")) {
					groupNm = contants.LGEConstatns.LGE_USER_GROUPS_PREFIX[0]+event.getObjectId();
				}else {
					groupNm = contants.LGEConstatns.LGE_USER_GROUPS_PREFIX[1]+event.getObjectId();
				}
				UserGroup[] group;
				TeamsNumberIdentifier createdDynamicUserGroup = null;					
				try 
				{
					//내부 or 외부 그룹이름을 통해 그룹 아이디 조회
					group = UserGroupServices.getInstance().retrieveUserGroupsByName(groupNm, securitySession);
					createdDynamicUserGroup = group[0].getId();
					//조회된 그룹아이디에 등록된 사용자 삭제
					UserGroupServices.getInstance().lockUserGroup(createdDynamicUserGroup, securitySession);
					UserGroupServices.getInstance().removeArtesiaUserGroupUsers(createdDynamicUserGroup, (String[])valuesSet.toArray(new String[valuesSet.size()]), securitySession);
					UserGroupServices.getInstance().unlockUserGroup(createdDynamicUserGroup, securitySession);
				} 
				catch (BaseTeamsException e) 
				{
					e.printStackTrace();
				}
				finally 
				{
					try {
						UserGroupServices.getInstance().unlockUserGroup(createdDynamicUserGroup, securitySession);
					} catch (BaseTeamsException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		}
	}
}
