package eventHandler;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.common.exception.BaseTeamsException;
import com.artesia.event.Event;
import com.artesia.event.EventListener;
import com.artesia.security.SecuritySession;
import com.artesia.security.session.services.AuthenticationServices;
import com.artesia.security.session.services.LocalAuthenticationServices;
import com.artesia.user.TeamsUser;
import com.artesia.user.UserIdentifier;
import com.artesia.user.services.UserServices;

import contants.LGEEventConstans;
import utils.Utils;

public class LGEEventHandler implements EventListener{
	
	List<String> eventsToListen = new ArrayList<String>();
	
	private static final Log LOGGER = LogFactory.getLog(LGEEventHandler.class);
	
	//register에서 등록된 이벤트번호 추가
	public LGEEventHandler(String... eventIds)
	{
		for (String anEvent : eventIds)
		{			
			eventsToListen.add(anEvent);
		}
	}

	public void onEvent(Event event) {
		if (event != null)
		{
			String eventId = event.getEventId().toString();
			
			
			LOGGER.info("============================================================");
			LOGGER.info("================getEventId " +eventId + "===================");
			LOGGER.info("============================================================");
			
			SecuritySession securitySession = Utils.getLocalSession2();
//			SecuritySession securitySession = null;
//			try {
//				securitySession = getEventUserSession(event.getUserId(), session);
//			} catch (BaseTeamsException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
			if (securitySession == null)
			{
				return;
			}			
			//특정 이벤트 번호에 따른 이벤트 실행
			if(eventsToListen.contains(eventId))
			{
				AbstractEventHandler eventHandler = null;
				//Asset 메타데이터 업데이트시 발생 
				if(LGEEventConstans.METADATA_UPDATE_ID.equals(eventId)) 
				{
					eventHandler = new AssetToEditHandler();  
				}
				//사용자 등록시 이벤트 발생
				else if(LGEEventConstans.CREATE_USER_ID.equals(eventId)) 
				{
					eventHandler = new CreateUserHandler();
				}
				//Asset 추가시 이벤트 발생
				else if(LGEEventConstans.RVJOB_ADD_ASSET_ID.equals(eventId))   
				{
					//eventHandler = new AddAssetsToSecurityPolicyHandler();
					eventHandler = new AddAssetsToPolicyHandler();
					
				}
				//rvjob 삭제시 이벤트 발생
				else if(LGEEventConstans.RVJOB_DELETED_ID.equals(eventId)) 
				{
					eventHandler = new DeleteJobHandler();
				}
				//rvjob 생성시 이벤트 발생
				else if(LGEEventConstans.RVJOB_CREATED_ID.equals(eventId)) 
				{
					eventHandler = new CreateRvJobHandler();
				}
				//rvjob 완료시 이벤트 발생
				else if(LGEEventConstans.RVJOB_COMPLETE_ID.equals(eventId)) 
				{
				 	eventHandler = new CompletedJobHandler();
				}
				//rvjob 재오픈시 이벤트 발생
				else if(LGEEventConstans.RVJOB_REOPEN_ID.equals(eventId))
				{
					eventHandler = new ReOpenJobHandler();
				}
				//rvjob 사용자 추가시 이벤트 발생
				else if(LGEEventConstans.RVJOB_ADD_USER_ID.equals(eventId))
				{
					eventHandler = new AddMemberHandler();
				}
				//rvjob 사용자 삭제시 이벤트 발생
				else if(LGEEventConstans.RVJOB_DELETE_USER_ID.equals(eventId))
				{
					eventHandler = new RvJobRemoveUserHandler();
				}
				//rvjob Asset 삭제시 이벤트 발생
				else if(LGEEventConstans.RVJOB_ASSET_REMOVE_ID.equals(eventId)) {
					eventHandler = new RemoveAssetHandler();
				}
				//teams에서 Asset 삭제시 이벤트 발생
				else if(LGEEventConstans.DELETE_ASSET_ID.equals(eventId)) {
					eventHandler = new DeleteAssetHandler();
				}
				else if(LGEEventConstans.ASSET_CHECK_IN.equals(eventId)) {
					eventHandler = new AssetToCheckInHandler();
				}
				else if(LGEEventConstans.USER_DELETE_ID.equals(eventId)) {
					eventHandler = new DeleteUserHandler();
				}
				eventHandler.handleEvent(event, securitySession);
			}			
			try 
			{
				if (securitySession != null){
					LOGGER.info("Logging out admin user session");
					AuthenticationServices.getInstance().logout(securitySession);
				}
//				if (securitySession != null){
//					LOGGER.info("Logging out admin user session");
//					AuthenticationServices.getInstance().logout(securitySession);
//				}
			} 
			catch (BaseTeamsException e){ LOGGER.error("An error occured while removing the sesison, Logout failed in LGEEventHandler."); } 						
		}		
	}
	
	public static SecuritySession getEventUserSession(UserIdentifier userId, SecuritySession securitySession) throws BaseTeamsException {
		
		SecuritySession newSession = null;
		UserServices userServices = UserServices.getInstance();
		TeamsUser retrievedTeamsUser = userServices.retrieveTeamsUser(userId, securitySession);
		LOGGER.info("Event User ID : " + userId);
		LOGGER.info("Event User LoginName: " + retrievedTeamsUser.getLoginName());

		newSession = getLocalSession(retrievedTeamsUser.getLoginName());
		return newSession;
	}
	
	public static SecuritySession getLocalSession(String userId)
	{
		SecuritySession localSession = null;
		try 
		{
			localSession = LocalAuthenticationServices.getInstance().createLocalSession(userId);
		} 
		catch (BaseTeamsException e) 
		{
			LOGGER.error("An exception occured while trying to get the login session", e);
			return null;
		}
		return localSession;
	}
}
