package eventHandler;


import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.Asset;
import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.security.services.AssetSecurityServices;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.entity.TeamsNumberIdentifier;
import com.artesia.event.Event;
import com.artesia.reviewjob.ReviewJob;
import com.artesia.security.SecurityPolicy;
import com.artesia.security.SecuritySession;

import common.EventListenerUtils;
import contants.LGEConstatns;

public class AssetToCheckInHandler extends AbstractEventHandler{

	private static final Log LOGGER = LogFactory.getLog(AssetToCheckInHandler.class);
	
	
	@Override
	void handleEvent(Event event, SecuritySession securitySession) {
		
		LOGGER.info("========================== AssetToCheckInHandler ==========================");
		try {
			Set<TeamsIdentifier> policyIds = new HashSet<>();
			Asset asset = EventListenerUtils.getAssetInfo(new AssetIdentifier(event.getObjectId()), securitySession);
			List<ReviewJob> rvjobList = EventListenerUtils.getRvJobId(asset, securitySession);
			
			LOGGER.info("===== rvjob size" + rvjobList.size());
			
			boolean completedFlag = true;
			//해당 Asset job정보가 있다면 job에서 생성된걸로 간주
			if(rvjobList.size() !=0) {
				
				for(int i = 0; i< rvjobList.size(); i++)
				{
					if(rvjobList.get(i).getStatus().getId() != 3)
					{
						completedFlag = false;
						break;
					}
				}
				//job 완료여부 완료되면 dynamic 정책이 사라지므로, publish, allow To policy 정책삭제하면 안됨.
				if(completedFlag)
				{
					//완료여부 확인
					for(SecurityPolicy policy : asset.getSecurityPolicyList()) {
						if(policy.getName().contains("Publish") || policy.getName().contains(LGEConstatns.DYNAMIC_SCURITY_ALLOW_TO_PREFIX) || policy.getName().contains(LGEConstatns.LG_COM5_WCMS_SECURITY_POLICY)) {
							policyIds.add(policy.getId());
						}
					}			
					System.out.println("==== policyIds.size() : " + policyIds.size());
					for(TeamsIdentifier id : policyIds)
					{
						System.out.println("policyIds id information : " + id.getId());
					}
					try {
						AssetServices.getInstance().unlockAsset(new AssetIdentifier(event.getObjectId()), securitySession);
						AssetServices.getInstance().lockAsset(new AssetIdentifier(event.getObjectId()), securitySession);
						AssetSecurityServices.getInstance().unassignSecurityPoliciesFromAssets(new AssetIdentifier [] {new AssetIdentifier(event.getObjectId())}, (TeamsNumberIdentifier[]) policyIds.toArray(new TeamsNumberIdentifier[policyIds.size()]), securitySession);
						AssetServices.getInstance().unlockAsset(new AssetIdentifier(event.getObjectId()), securitySession);
					}finally {
						AssetServices.getInstance().unlockAsset(new AssetIdentifier(event.getObjectId()), securitySession);
					}					
				}
			}			
		} catch (BaseTeamsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		LOGGER.info("========================== AssetToCheckInHandler END ==========================");
	}
}
