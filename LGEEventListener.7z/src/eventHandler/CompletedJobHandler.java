package eventHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.asset.Asset;
import com.artesia.asset.AssetIdentifier;
import com.artesia.asset.services.AssetServices;
import com.artesia.common.exception.BaseTeamsException;
import com.artesia.container.Container;
import com.artesia.container.ContainerPosition;
import com.artesia.container.ListOperationResult;
import com.artesia.container.services.ContainerServices;
import com.artesia.entity.TeamsIdentifier;
import com.artesia.event.Event;
import com.artesia.export.AssetExportURLGeneratorImpl;
import com.artesia.export.interfaces.AssetURLGenerator;
import com.artesia.export.services.ExportServices;
import com.artesia.export.templates.DeliveryTemplate;
import com.artesia.security.SecuritySession;
import com.artesia.transformer.TransformerInstanceValue;
import com.artesia.user.TeamsUser;
import com.artesia.user.UserIdentifier;
import com.artesia.user.services.UserServices;

import common.EventListenerUtils;
import contants.LGEConstatns;
import ttsg_teams.admin.db.DBMgr;
import ttsg_teams.common.common.TeamsException;
import utils.Utils;
/*
* ---------------------------------------------------------------------------------------
* PROJ    :   New Marketing Product Information_LGE
* NAME    :   CompletedJobHandler.java
* DESC    :   ReviewJob Completed 이벤트
* Author  :   양창덕
* VER     :   v1.0
* Copyright 2019 LG CNS All right reserved
* ---------------------------------------------------------------------------------------
*                       변             경           사          항
* ---------------------------------------------------------------------------------------
*       DATE       AUTHOR                                  DESCRIPTION
*  ------------ -----------  ------------------------------------------------------------
*   2019.08.20    양창덕            다이나믹정책 삭제 방지
*   2019.12.31    양창덕            Completed job 이벤트 시 분기별 폴더에서 년도별 폴더로 변경
*   2019.12.31    양창덕            Completed job 이벤트 시 폴더 Move -> Copy형태로 변경
* ---------------------------------------------------------------------------------------
*/
public class CompletedJobHandler extends AbstractEventHandler  
{
	
	private static Log logger = LogFactory.getLog(CompletedJobHandler.class);
	int year  = Calendar.getInstance().get(Calendar.YEAR);
	int month = 0;
	int quarter = 0;
	String toDay = null;
	


	@Override
	void handleEvent(Event event, SecuritySession securitySession) {
		
		if(year == 2019)
		{
			month = Calendar.getInstance().get( Calendar.MONTH ) + 1;
			quarter = month % 3 == 0?  (month / 3): ( month / 3)+1;
			toDay =  year+"_"+quarter+"Q";
		}
    	List<AssetIdentifier> assets = new ArrayList<AssetIdentifier>();
    	List<TeamsIdentifier> assetList = new ArrayList<TeamsIdentifier>();
		//rvjob정보에  Asset정보 조회
		assets = EventListenerUtils.getRvjobToAssets(new TeamsIdentifier(event.getObjectId()), securitySession);
		
		//Asset 메타데이터에 생성자 정보 저장
		//EventListenerUtils.setAssetToMetadataField(assets, securitySession);

		//이동될 폴더이름 정의		
		String folderNm = EventListenerUtils.getJobFolderName(event.getObjectId());		
		String newContainerName = (folderNm != null) ? folderNm : event.getObjectName();		
		String folderId = "";	
		try 
		{
			try {
				String folderQuery = "SELECT FOLDER_ID FROM OTMM.LGE_MPIS_RVJOBS_CT WHERE ID = '"+event.getObjectId()+"'";
 				Connection connection1 = null;
 				PreparedStatement preparedStatement1 = null;	
 				ResultSet result1 = null;
 				try
 				{
 					DBMgr db = new DBMgr();
 					connection1 = db.openDatabase();
 					preparedStatement1 = connection1.prepareStatement(folderQuery);
 					result1 = preparedStatement1.executeQuery();	
 					while(result1.next())
 					{
 						folderId = result1.getString("folder_id");
 					}
 				}
 				finally
 				{
 					if(connection1 != null)  connection1.close();
 					if(preparedStatement1 != null) preparedStatement1.close();
 					if(result1 != null) result1.close();
 				}
 			} catch (SQLException | TeamsException e) {
 				// TODO Auto-generated catch block
 				e.printStackTrace();
 			}
			
			TeamsIdentifier parentId = new TeamsIdentifier(folderId);
			
			//job 완료시 폴더이동
			String folderName = (year == 2019) ? toDay+"/⊙/"+newContainerName : year+"/⊙/"+newContainerName;
			
			String [] data = folderName.split("/⊙/");
			for(AssetIdentifier asset : assets)
			{
				assetList.add(new TeamsIdentifier(asset.getId()));
			}			
			boolean moveResult = moveToAssets(event.getObjectId().toString(), parentId, data, assetList, event.getObjectName(), securitySession);
		
     		//Asset move 신규 생성 폴더
			if(moveResult)
			{
     			String userEmails = "";
     			try {
     				String query = "SELECT EMAIL FROM OTMM.LGE_MPIS_JOB_EMAIL_LIST_CT WHERE JOB_ID = '"+event.getObjectId()+"'";
     				System.out.println("EMAIL_QUERY ======" + query);
     				Connection connection = null;
     				PreparedStatement preparedStatement = null;	
     				ResultSet emailResult = null;
     				try
     				{
     					DBMgr db = new DBMgr();
     					connection = db.openDatabase();
     					preparedStatement = connection.prepareStatement(query);
     					emailResult = preparedStatement.executeQuery();	
     					while(emailResult.next())
     					{
     						if(userEmails.equals("")) {
         						userEmails = emailResult.getString("email");
         					}else {
         						userEmails += ";"+emailResult.getString("email");
         					}
     					}

     				}
     				finally
     				{
     					if(connection != null)  connection.close();
     					if(preparedStatement != null) preparedStatement.close();
     					if(emailResult != null) emailResult.close();
     				}
     			} catch (SQLException | TeamsException e) {
     				// TODO Auto-generated catch block
     				e.printStackTrace();
     			}

     			if(!userEmails.equals("")) {
     				TeamsUser userInfo = UserServices.getInstance().retrieveTeamsUser(new UserIdentifier(event.getUserId().toString()), securitySession);
     				List<TransformerInstanceValue> tList = new ArrayList<>();
         			TransformerInstanceValue transformerInstanceValue = new TransformerInstanceValue();
         			transformerInstanceValue.setValue(LGEConstatns.FROM_EMAIL);
         			transformerInstanceValue.setArgumentNumber(3);
         			tList.add(transformerInstanceValue);
         			
         			DeliveryTemplate deliveryTemplate = new DeliveryTemplate();     			
         			TeamsIdentifier defaultFileHandlingTemplate = new TeamsIdentifier("HIDE");
         			deliveryTemplate.setDefaultFileHandlingTemplate(defaultFileHandlingTemplate);
         			deliveryTemplate.setAttributeValues(tList);
         			deliveryTemplate.setId(new TeamsIdentifier("ARTESIA.DELIVERY.EMAILURL.DEFAULT"));
         			deliveryTemplate.setTransformerId(new TeamsIdentifier("ARTESIA.TRANSFORMER.PROFILE.E-MAILURL"));
         			deliveryTemplate.setDefaultFileHandlingTemplate(new TeamsIdentifier("HIDE"));
         			
         			
         			AssetURLGenerator assetURLGenerator = new AssetURLGenerator() {			
         				@Override
         				public String createURL() {
         					// TODO Auto-generated method stub
         					return new AssetExportURLGeneratorImpl().createURL();
         				}
         			};
     				
         			String url = null;
         			try {
         				url = ExportServices.getInstance().exportAsURL(deliveryTemplate, assets, false, assetURLGenerator, securitySession);
         			} catch (BaseTeamsException e1) {
         				// TODO Auto-generated catch block
         				e1.printStackTrace();
         			}
         			//메일발송
         			Map<String, String> map = new HashMap<>();
         			StringBuffer returnValue = new StringBuffer();

         			returnValue.append("Dears,");
         			returnValue.append("\n");
         			returnValue.append("\n");
         			returnValue.append("This is notifiacation for job manager.");
         			returnValue.append("\n");
         			returnValue.append("The job which you are managing has been completed.");         			
         			returnValue.append("\n");
         			returnValue.append("\n");
         			returnValue.append("You can see the details here: "+url);
         			returnValue.append("\n");
         			returnValue.append("\n");
         			returnValue.append("Thanks.");  
         			
         			map.put("fromAddress", 		userInfo.getEmailAddress());
         			map.put("toAddress", 		userEmails);
         			map.put("ccAddress", 		"");
         			map.put("replyToAddr", 		"");
         			map.put("subject", 			"[New MPIS] Job has been completed.");     			   			
         			map.put("body", 			returnValue.toString());
         			map.put("serverName", 		Utils.getSystemSetting("COMMON", "SERVER", "EMAIL_SERVER", securitySession));     			
         			mailUtils.sendMailApi.sendMail(map); 
     			} 
	     		     		     		    			    	     		
     		}
			else
			{
				logger.info("Create Completed job Folder Failed");
			}
		} 
		catch (BaseTeamsException e1) 
		{
			logger.info(e1.getMessage());
			e1.printStackTrace();
		}
		finally
		{
			//정책변경
			EventListenerUtils.defaultSecuritySetting(event, securitySession);
 			//다이나믹 외부, 내부 그룹 삭제 & 정책 삭제
 			//DynamicPolicy.getInstance().delete(event, securitySession);
		}
	}
	
	public boolean moveToAssets(String rvjobId, TeamsIdentifier parentId, String [] date,  List<TeamsIdentifier> assetList, String jobName, SecuritySession session) 
	{
		List<Container> containerList = new ArrayList<>();
		AssetIdentifier path = null;
		try {
			for(int i=0;i<date.length;i++) 
			{
				if(i == 0) 
				{
					path = EventListenerUtils.folderCheck(parentId, session, date[i].trim());				
				}
				else
				{
					path = EventListenerUtils.folderCheck(containerList.get(containerList.size()-1).getContainerId(), session, date[i].trim());
				}
				if(i == 0) 
				{
					if(path == null)
					{
						containerList.add(EventListenerUtils.createFolder(parentId , date[i].trim(), session));
					}
					else
					{
						containerList.add(EventListenerUtils.getFolder(new AssetIdentifier(path.getId()), session));
					}
				}
				else 
				{
					HashMap<String, String> folderChk = folderCheck(rvjobId);
					if(folderChk.size() > 0)
					{
						//예외처리  - 폴더내역 DB에 폴더가 저장되어 있으나, 실제 폴더가 삭제처리되어 UOIS DB에 데이터가 삭제된 경우  
						Asset folderAsset = EventListenerUtils.getAssetInfo(new AssetIdentifier(folderChk.get("folderId")), session);
						if(folderAsset != null)
						{
							//폴더이력관리
							AssetServices.getInstance().unlockAsset(new AssetIdentifier(folderChk.get("folderId")), session);
							AssetServices.getInstance().lockAsset(new AssetIdentifier(folderChk.get("folderId")), session);
							ContainerServices.getInstance().renameContainer(new AssetIdentifier(folderChk.get("folderId")), jobName, session);
							AssetServices.getInstance().unlockAsset(new AssetIdentifier(folderChk.get("folderId")), session);
							containerList.add(new Container(new AssetIdentifier(folderChk.get("folderId"))));
						}
						else
						{
							containerList.add(EventListenerUtils.createFolder(containerList.get(containerList.size()-1).getContainerId() , date[i].trim(), session));
						}
					}
					else
					{
						containerList.add(EventListenerUtils.createFolder(containerList.get(containerList.size()-1).getContainerId() , date[i].trim(), session));
					}
				}  
			}
			if(year == 2019)
			{
				//move 이벤트
				ContainerServices.getInstance().moveContainers(parentId, assetList, containerList.get(containerList.size()-1).getContainerId(), ContainerPosition.LAST, session);
			}
			else
			{				
				//완료 시 년도폴더 하위에 잡 명칭으로 폴더생성
				ContainerServices.getInstance().insertChildren(ContainerPosition.LAST, assetList, containerList.get(containerList.size()-1).getContainerId(), session);
				//사업부폴더에 등록된 에셋들 삭제
				ContainerServices.getInstance().detachChildren(parentId, assetList, session);				
			}
			
		} catch (BaseTeamsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}	
		finally
		{
			//폴더 생성 이력 저장
			try {
				String sql = "INSERT INTO OTMM.OTMM.LGE_MPIS_RVJOB_FOLDER_HISTORY (RVJOB_ID, FOLDER_ID, FOLDER_NAME, REG_DATE) VALUES(?,?,?, GETDATE())";
				String folderId = containerList.get(containerList.size()-1).getContainerId().toString();
				String folderName = date[date.length-1].trim();
 				Connection connection1 = null;
 				PreparedStatement preparedStatement1 = null;	
 				try
 				{
 					DBMgr db = new DBMgr();
 					connection1 = db.openDatabase();
 					preparedStatement1 = connection1.prepareStatement(sql);
 					preparedStatement1.setString(1, rvjobId);
 					preparedStatement1.setString(2, folderId);
 					preparedStatement1.setString(3, folderName);
 					preparedStatement1.executeUpdate();				
 				}
 				finally
 				{
 					if(connection1 != null)  connection1.close();
 					if(preparedStatement1 != null) preparedStatement1.close();
 				}
 			} catch (SQLException | TeamsException e) {
 				// TODO Auto-generated catch block
 				e.printStackTrace();
 			}
		}
		
		return true;
	}
	
	//폴더상태체크
	public HashMap<String, String> folderCheck(String jobId)
	{
		HashMap<String, String> resultMap = new HashMap<>();
		try {
			String sql = "SELECT TOP 1 FOLDER_ID, REG_DATE, FOLDER_NAME FROM OTMM.OTMM.LGE_MPIS_RVJOB_FOLDER_HISTORY WHERE RVJOB_ID = ? AND DATEPART(YYYY, REG_DATE) = ? ORDER BY REG_DATE DESC";
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			ResultSet result = null;
			try
			{
				DBMgr db = new DBMgr();
				connection = db.openDatabase();
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setString(1, jobId);
				preparedStatement.setString(2, Integer.toString(year));
				result = preparedStatement.executeQuery();
								
				while(result.next())
				{
					resultMap.put("folderId", result.getString("folder_id"));
					resultMap.put("regDate", result.getString("reg_Date"));
					resultMap.put("folderNm", result.getString("folder_name"));
				}
			}
			finally
			{
				if(connection != null)  connection.close();
				if(preparedStatement != null) preparedStatement.close();
				if(result != null) result.close();
			}
		} catch (SQLException | TeamsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return resultMap;
	}
}

