package eventHandler;

import com.artesia.common.exception.BaseTeamsException;
import com.artesia.event.Event;
import com.artesia.security.SecurityPolicy;
import com.artesia.security.SecuritySession;
import com.artesia.security.services.SecurityPolicyServices;

import common.EventListenerUtils;
import contants.LGEConstatns;
  
public class DeleteAssetHandler extends AbstractEventHandler{

	@Override
	void handleEvent(Event event, SecuritySession securitySession) {
		//Asset일 경우에만 
		if(event.getObjectType().equals("ASSET")) {
			SecurityPolicy [] embagoPolicy = null;
			try {
				//AllowTo 그룹이름을 통해 정책 조회
				//Embago 그룹이름을 통해 정책 조회
				embagoPolicy = SecurityPolicyServices.getInstance().retrieveSecurityPoliciesByName(LGEConstatns.DYNAMIC_SCURITY_EMBARGO_PREFIX+event.getObjectId(), securitySession);
				//Embago 정책이 존재하면,
				if(embagoPolicy.length != 0) 
				{
					//Embago 정책 삭제
					boolean result = EventListenerUtils.deleteSecurityPolicyToName(LGEConstatns.DYNAMIC_SCURITY_EMBARGO_PREFIX+event.getObjectId(), securitySession);
					if(result) {
						//Embago 내부 and 외부 그룹 삭제
						EventListenerUtils.deleteUserGroupToName(LGEConstatns.DYNAMIC_USER_GROUP_EXTERNAL_EMBARGO_PREFIX+event.getObjectId(), securitySession);
						EventListenerUtils.deleteUserGroupToName(LGEConstatns.DYNAMIC_USER_GROUP_INTERNAL_EMBARGO_PREFIX+event.getObjectId(), securitySession);
					}				
				}		
			} catch (BaseTeamsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
	}
}
