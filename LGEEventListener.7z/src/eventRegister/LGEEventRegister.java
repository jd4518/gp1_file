package eventRegister;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.artesia.common.exception.BaseTeamsException;
import com.artesia.event.services.EventServices;
import com.artesia.security.SecuritySession;
import com.artesia.security.session.services.AuthenticationServices;

import contants.LGEEventConstans;
import eventHandler.LGEEventHandler;
import utils.Utils;

public class LGEEventRegister implements ServletContextListener{
	
	private static final Log LOGGER = LogFactory.getLog(LGEEventRegister.class);
	
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void contextInitialized(ServletContextEvent event) 
	{
		SecuritySession securitySession = null;		
		try 
		{
			//tsuper session
			securitySession = Utils.getLocalSession2();
			EventServices.getInstance().removeEventListener(LGEEventConstans.CLIENT_ID, securitySession);
			//이벤트등록작업
			LGEEventHandler eventHanders = new LGEEventHandler(LGEEventConstans.METADATA_UPDATE_ID, LGEEventConstans.CREATE_USER_ID, LGEEventConstans.RVJOB_REOPEN_ID, LGEEventConstans.RVJOB_ADD_ASSET_ID, LGEEventConstans.RVJOB_ADD_USER_ID, LGEEventConstans.RVJOB_CREATED_ID, LGEEventConstans.RVJOB_COMPLETE_ID, LGEEventConstans.RVJOB_DELETED_ID, LGEEventConstans.RVJOB_DELETE_USER_ID, LGEEventConstans.RVJOB_ASSET_REMOVE_ID,LGEEventConstans.DELETE_ASSET_ID, LGEEventConstans.ASSET_CHECK_IN,  LGEEventConstans.USER_LOGIN_ID, LGEEventConstans.USER_DELETE_ID);
			EventServices.getInstance().addEventListener(LGEEventConstans.CLIENT_ID, eventHanders, securitySession);
		} 
		catch (BaseTeamsException e) 
		{
			LOGGER.error("An exception occured while processing while starting the applcation" , e);
		}
		finally
		{
			if (securitySession != null)
			{
				try 
				{
					AuthenticationServices.getInstance().logout(securitySession);
				} 
				catch (BaseTeamsException e) 
				{
					LOGGER.error("An error occured while removing the session in Event Register", e);
				}
			}
		
		}
	}
}
